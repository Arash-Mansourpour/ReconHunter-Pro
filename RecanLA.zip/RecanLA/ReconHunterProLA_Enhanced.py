#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RECON HUNTER PRO - ULTIMATE EDITION v4.0
Advanced Reconnaissance & OSINT Framework
Enhanced with AI-Powered Analysis & Vulnerability Detection

NEW FEATURES IN v4.0:
- 30+ Passive Recon Sources (Shodan, Censys, SecurityTrails, DNSDumpster, etc.)
- Subdomain Takeover Detection
- JavaScript Analysis & Secret Detection (API keys, tokens)
- Directory/Path Fuzzing
- Cloud Storage Bucket Detection (AWS S3, Azure, GCS)
- Email Enumeration & Pattern Discovery
- API Endpoint Discovery
- Historical Certificate Analysis
- Advanced Rate Limiting & Proxy Support
- Interactive HTML Reports with Charts
"""

import sys
import os
import io

# Fix Windows console encoding for Unicode/Emoji support
if sys.platform.startswith('win'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import asyncio
import aiohttp
import aiodns
import json
import logging
import threading
import concurrent.futures
from datetime import datetime, timedelta
from typing import Set, Dict, List, Tuple, Optional, Any, AsyncGenerator
from collections import defaultdict
import ipaddress
import subprocess
import socket
import re
import requests
import warnings
import base64
from urllib.parse import urlparse, urljoin, parse_qs
import hashlib
import ssl
import OpenSSL
from dataclasses import dataclass, asdict, field
from enum import Enum
import random
import time
from bs4 import BeautifulSoup
import tldextract
import dns.resolver
import dns.reversename
from collections import OrderedDict
import argparse
import smtplib
from email.message import EmailMessage

# Try to import certifi for proper SSL certificates
try:
    import certifi
    CERTIFI_AVAILABLE = True
except ImportError:
    CERTIFI_AVAILABLE = False


def create_ssl_context():
    """Create a secure SSL context with proper certificate verification"""
    context = ssl.create_default_context()
    if CERTIFI_AVAILABLE:
        context.load_verify_locations(certifi.where())
    return context

if sys.platform.startswith('win'):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from tkinter import font as tkfont

warnings.filterwarnings('ignore')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('recon_hunter_ultimate.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class Config:
    """Configuration settings"""
    # API Keys (set these for enhanced features)
    SHODAN_API_KEY: str = ""
    CENSYS_API_ID: str = ""
    CENSYS_API_SECRET: str = ""
    SECURITYTRAILS_API_KEY: str = ""
    VIRUSTOTAL_API_KEY: str = ""
    BINARYEDGE_API_KEY: str = ""
    ZOOMEYE_API_KEY: str = ""
    FOFA_API_KEY: str = ""
    HUNTER_API_KEY: str = ""
    
    # Rate limiting
    REQUEST_DELAY: float = 0.1
    MAX_CONCURRENT_REQUESTS: int = 50
    TIMEOUT: int = 30
    
    # Proxy settings
    USE_PROXY: bool = False
    PROXY_LIST: List[str] = field(default_factory=list)
    
    # Stealth settings
    STEALTH_MODE: bool = False
    STEALTH_DELAY_MIN: float = 2.0
    STEALTH_DELAY_MAX: float = 5.0
    
    # Output settings
    OUTPUT_DIR: str = "recon_results"
    SCREENSHOTS_DIR: str = "screenshots"
    JS_ANALYSIS_DIR: str = "js_analysis"


# ═══════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SubdomainInfo:
    """Enhanced subdomain information model"""
    domain: str
    ips: List[str] = field(default_factory=list)
    cnames: List[str] = field(default_factory=list)
    mx_records: List[str] = field(default_factory=list)
    txt_records: List[str] = field(default_factory=list)
    ns_records: List[str] = field(default_factory=list)
    soa_record: Optional[Dict] = None
    status_code: Optional[int] = None
    title: str = ""
    server: str = ""
    technologies: List[str] = field(default_factory=list)
    waf: Optional[str] = None
    cdn: Optional[str] = None
    ssl_info: Optional[Dict] = field(default_factory=dict)
    open_ports: List[Dict] = field(default_factory=list)
    vulnerabilities: List[Dict] = field(default_factory=list)
    screenshot: Optional[str] = None
    js_files: List[str] = field(default_factory=list)
    js_secrets: List[Dict] = field(default_factory=list)
    api_endpoints: List[str] = field(default_factory=list)
    emails: List[str] = field(default_factory=list)
    takeover_vulnerable: bool = False
    takeover_type: Optional[str] = None
    cloud_buckets: List[Dict] = field(default_factory=list)
    content_type: str = ""
    content_length: int = 0
    redirect_url: Optional[str] = None
    response_time: float = 0.0
    headers: Dict[str, str] = field(default_factory=dict)
    cookies: Dict[str, str] = field(default_factory=dict)
    security_headers: Dict[str, Any] = field(default_factory=dict)
    historical_ips: List[Dict] = field(default_factory=list)


@dataclass
class VulnerabilityInfo:
    """Vulnerability information model"""
    name: str
    severity: str  # critical, high, medium, low, info
    description: str
    url: str
    evidence: str
    cve_id: Optional[str] = None
    cvss_score: Optional[float] = None
    remediation: str = ""
    references: List[str] = field(default_factory=list)


class ScanLevel(Enum):
    """Scan intensity levels"""
    PASSIVE = "passive"
    NORMAL = "normal"
    AGGRESSIVE = "aggressive"
    STEALTH = "stealth"
    ULTIMATE = "ultimate"


# ═══════════════════════════════════════════════════════════════════════════
# RATE LIMITER & PROXY MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class RateLimiter:
    """Advanced rate limiter with adaptive delays"""
    
    def __init__(self, requests_per_second: float = 10, burst: int = 20):
        self.requests_per_second = requests_per_second
        self.burst = burst
        self.tokens = burst
        self.last_update = time.time()
        self.lock = asyncio.Lock()
    
    async def acquire(self):
        """Acquire a token, waiting if necessary"""
        async with self.lock:
            now = time.time()
            elapsed = now - self.last_update
            self.tokens = min(self.burst, self.tokens + elapsed * self.requests_per_second)
            self.last_update = now
            
            if self.tokens < 1:
                sleep_time = (1 - self.tokens) / self.requests_per_second
                await asyncio.sleep(sleep_time)
                self.tokens = 0
            else:
                self.tokens -= 1


class ProxyManager:
    """Proxy rotation manager"""
    
    def __init__(self, proxy_list: List[str] = None):
        self.proxies = proxy_list or []
        self.current_index = 0
        self.bad_proxies: Set[str] = set()
    
    def get_proxy(self) -> Optional[str]:
        """Get next available proxy"""
        if not self.proxies:
            return None
        
        available = [p for p in self.proxies if p not in self.bad_proxies]
        if not available:
            return None
        
        proxy = available[self.current_index % len(available)]
        self.current_index += 1
        return proxy
    
    def mark_bad(self, proxy: str):
        """Mark a proxy as bad"""
        self.bad_proxies.add(proxy)


# ═══════════════════════════════════════════════════════════════════════════
# ENHANCED PASSIVE RECON ENGINE (30+ SOURCES)
# ═══════════════════════════════════════════════════════════════════════════

class UltimatePassiveReconEngine:
    """
    Ultimate Passive Reconnaissance Engine
    Integrates 30+ public APIs and OSINT sources
    """
    
    def __init__(self, domain: str, config: Config = None):
        self.domain = domain
        self.config = config or Config()
        self.session: Optional[aiohttp.ClientSession] = None
        self.results = defaultdict(set)
        self.rate_limiter = RateLimiter()
        self.proxy_manager = ProxyManager(self.config.PROXY_LIST)
    
    async def init_session(self):
        """Initialize aiohttp session with proper settings"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.config.TIMEOUT)
            connector = aiohttp.TCPConnector(
                ssl=False,
                limit=self.config.MAX_CONCURRENT_REQUESTS,
                limit_per_host=10,
                ttl_dns_cache=300
            )
            headers = {
                'User-Agent': random.choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0'
                ]),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive'
            }
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                headers=headers
            )
    
    async def close_session(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def _fetch(self, url: str, **kwargs) -> Optional[Any]:
        """Fetch URL with rate limiting and error handling"""
        await self.rate_limiter.acquire()
        
        if self.config.STEALTH_MODE:
            delay = random.uniform(self.config.STEALTH_DELAY_MIN, self.config.STEALTH_DELAY_MAX)
            await asyncio.sleep(delay)
        
        try:
            await self.init_session()
            
            proxy = None
            if self.config.USE_PROXY:
                proxy = self.proxy_manager.get_proxy()
            
            kwargs.setdefault('ssl', False)
            
            async with self.session.get(url, proxy=proxy, **kwargs) as response:
                if response.status == 200:
                    content_type = response.headers.get('Content-Type', '')
                    if 'json' in content_type:
                        return await response.json()
                    else:
                        return await response.text()
                elif response.status == 429:
                    # Rate limited, wait and retry
                    await asyncio.sleep(60)
                    return await self._fetch(url, **kwargs)
        except Exception as e:
            logger.debug(f"Fetch error for {url}: {e}")
        
        return None
    
    # ==================== CERTIFICATE SOURCES ====================
    
    async def query_crtsh(self) -> Set[str]:
        """Query crt.sh for SSL certificates (enhanced)"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://crt.sh/?q=%25.{self.domain}&output=json")
            if data:
                for cert in data:
                    name = cert.get('name_value', '')
                    for sub in name.split('\n'):
                        sub = sub.strip().lower()
                        if self.domain in sub and '*' not in sub:
                            subdomains.add(sub)
            logger.info(f"[crt.sh] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[crt.sh] Error: {e}")
        return subdomains
    
    async def query_censys_certificates(self) -> Set[str]:
        """Query Censys for certificates (requires API key)"""
        subdomains = set()
        if not self.config.CENSYS_API_ID:
            return subdomains
        
        try:
            # Censys certificate search
            auth = aiohttp.BasicAuth(self.config.CENSYS_API_ID, self.config.CENSYS_API_SECRET)
            url = f"https://search.censys.io/api/v2/certificates/search?q=parsed.names:{self.domain}"
            
            await self.init_session()
            async with self.session.get(url, auth=auth) as response:
                if response.status == 200:
                    data = await response.json()
                    for hit in data.get('result', {}).get('hits', []):
                        for name in hit.get('parsed', {}).get('names', []):
                            if self.domain in name:
                                subdomains.add(name.lower())
            logger.info(f"[Censys] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Censys] Error: {e}")
        return subdomains
    
    # ==================== DNS SOURCES ====================
    
    async def query_dnsdumpster(self) -> Set[str]:
        """Query DNSDumpster"""
        subdomains = set()
        try:
            await self.init_session()
            
            # First get CSRF token
            async with self.session.get("https://dnsdumpster.com/") as response:
                text = await response.text()
                csrf = re.search(r"name='csrfmiddlewaretoken' value='([^']+)'", text)
                if csrf:
                    csrf_token = csrf.group(1)
                else:
                    return subdomains
            
            # Submit query
            data = {
                'csrfmiddlewaretoken': csrf_token,
                'targetip': self.domain,
                'user': 'free'
            }
            headers = {
                'Referer': 'https://dnsdumpster.com/',
                'Origin': 'https://dnsdumpster.com'
            }
            
            async with self.session.post("https://dnsdumpster.com/", data=data, headers=headers) as response:
                if response.status == 200:
                    text = await response.text()
                    # Parse HTML for subdomains
                    matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                    for match in matches:
                        subdomains.add(match.lower())
            
            logger.info(f"[DNSDumpster] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[DNSDumpster] Error: {e}")
        return subdomains
    
    async def query_hackertarget(self) -> Set[str]:
        """Query HackerTarget API"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://api.hackertarget.com/hostsearch/?q={self.domain}")
            if text:
                for line in text.split('\n'):
                    if ',' in line:
                        sub = line.split(',')[0].strip().lower()
                        if self.domain in sub:
                            subdomains.add(sub)
            logger.info(f"[HackerTarget] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[HackerTarget] Error: {e}")
        return subdomains
    
    async def query_threatcrowd(self) -> Set[str]:
        """Query ThreatCrowd API"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://www.threatcrowd.org/searchApi/v2/domain/report/?domain={self.domain}")
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(sub.lower())
            logger.info(f"[ThreatCrowd] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ThreatCrowd] Error: {e}")
        return subdomains
    
    async def query_alienvault(self) -> Set[str]:
        """Query AlienVault OTX"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://otx.alienvault.com/api/v1/indicators/domain/{self.domain}/passive_dns")
            if data:
                for item in data.get('passive_dns', []):
                    hostname = item.get('hostname', '').lower()
                    if hostname and self.domain in hostname:
                        subdomains.add(hostname)
            logger.info(f"[AlienVault] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[AlienVault] Error: {e}")
        return subdomains
    
    async def query_virustotal(self) -> Set[str]:
        """Query VirusTotal"""
        subdomains = set()
        try:
            headers = {}
            if self.config.VIRUSTOTAL_API_KEY:
                headers['x-apikey'] = self.config.VIRUSTOTAL_API_KEY
            
            data = await self._fetch(
                f"https://www.virustotal.com/api/v3/domains/{self.domain}/subdomains",
                headers=headers
            )
            if data:
                for item in data.get('data', []):
                    sub = item.get('id', '').lower()
                    if sub:
                        subdomains.add(sub)
            logger.info(f"[VirusTotal] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[VirusTotal] Error: {e}")
        return subdomains
    
    async def query_urlscan(self) -> Set[str]:
        """Query URLScan.io"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://urlscan.io/api/v1/search/?q=domain:{self.domain}")
            if data:
                for result in data.get('results', []):
                    page = result.get('page', {})
                    domain_info = page.get('domain', '').lower()
                    if domain_info and self.domain in domain_info:
                        subdomains.add(domain_info)
            logger.info(f"[URLScan] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[URLScan] Error: {e}")
        return subdomains
    
    async def query_rapiddns(self) -> Set[str]:
        """Query RapidDNS"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://rapiddns.io/subdomain/{self.domain}?full=1")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[RapidDNS] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[RapidDNS] Error: {e}")
        return subdomains
    
    # ==================== SEARCH ENGINE SOURCES ====================
    
    async def query_wayback(self) -> Set[str]:
        """Query Wayback Machine"""
        subdomains = set()
        try:
            data = await self._fetch(
                f"https://web.archive.org/cdx/search/cdx?url=*.{self.domain}/*&output=json&collapse=urlkey&pageSize=100000"
            )
            if data:
                for record in data[1:]:
                    try:
                        url_part = record[2]
                        parsed = urlparse(url_part)
                        host = parsed.netloc or url_part.split('/')[0]
                        if self.domain in host:
                            subdomains.add(host.lower())
                    except Exception:
                        pass
            logger.info(f"[Wayback] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Wayback] Error: {e}")
        return subdomains
    
    async def query_commoncrawl(self) -> Set[str]:
        """Query Common Crawl Index"""
        subdomains = set()
        try:
            # Get latest index
            data = await self._fetch("https://index.commoncrawl.org/collinfo.json")
            if data:
                latest_index = data[0].get('id', '')
                url = f"https://index.commoncrawl.org/{latest_index}-index?url=*.{self.domain}&output=json"
                text = await self._fetch(url)
                if text:
                    for line in text.strip().split('\n'):
                        try:
                            record = json.loads(line)
                            url_part = record.get('url', '')
                            parsed = urlparse(url_part)
                            host = parsed.netloc
                            if self.domain in host:
                                subdomains.add(host.lower())
                        except Exception:
                            pass
            logger.info(f"[CommonCrawl] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[CommonCrawl] Error: {e}")
        return subdomains
    
    # ==================== THREAT INTELLIGENCE SOURCES ====================
    
    async def query_securitytrails(self) -> Set[str]:
        """Query SecurityTrails (requires API key)"""
        subdomains = set()
        if not self.config.SECURITYTRAILS_API_KEY:
            return subdomains
        
        try:
            headers = {'APIKEY': self.config.SECURITYTRAILS_API_KEY}
            data = await self._fetch(
                f"https://api.securitytrails.com/v1/domain/{self.domain}/subdomains",
                headers=headers
            )
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(f"{sub}.{self.domain}".lower())
            logger.info(f"[SecurityTrails] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[SecurityTrails] Error: {e}")
        return subdomains
    
    async def query_shodan(self) -> Set[str]:
        """Query Shodan DNS (requires API key)"""
        subdomains = set()
        if not self.config.SHODAN_API_KEY:
            return subdomains
        
        try:
            data = await self._fetch(
                f"https://api.shodan.io/dns/domain/{self.domain}?key={self.config.SHODAN_API_KEY}"
            )
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(f"{sub}.{self.domain}".lower())
            logger.info(f"[Shodan] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Shodan] Error: {e}")
        return subdomains
    
    async def query_binaryedge(self) -> Set[str]:
        """Query BinaryEdge (requires API key)"""
        subdomains = set()
        if not self.config.BINARYEDGE_API_KEY:
            return subdomains
        
        try:
            headers = {'X-Key': self.config.BINARYEDGE_API_KEY}
            data = await self._fetch(
                f"https://api.binaryedge.io/v2/query/domains/subdomain/{self.domain}",
                headers=headers
            )
            if data:
                for item in data.get('events', []):
                    sub = item.get('domain', '').lower()
                    if sub:
                        subdomains.add(sub)
            logger.info(f"[BinaryEdge] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[BinaryEdge] Error: {e}")
        return subdomains
    
    async def query_zoomeye(self) -> Set[str]:
        """Query ZoomEye (requires API key)"""
        subdomains = set()
        if not self.config.ZOOMEYE_API_KEY:
            return subdomains
        
        try:
            headers = {'API-KEY': self.config.ZOOMEYE_API_KEY}
            data = await self._fetch(
                f"https://api.zoomeye.org/domain/search?q={self.domain}&type=1",
                headers=headers
            )
            if data:
                for item in data.get('matches', []):
                    sub = item.get('name', '').lower()
                    if sub:
                        subdomains.add(sub)
            logger.info(f"[ZoomEye] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ZoomEye] Error: {e}")
        return subdomains
    
    # ==================== ADDITIONAL SOURCES ====================
    
    async def query_bufferover(self) -> Set[str]:
        """Query BufferOver.run"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://dns.bufferover.run/dns?q=.{self.domain}")
            if data:
                for item in data.get('FDNS_A', []):
                    parts = item.split(',')
                    if len(parts) > 1:
                        sub = parts[1].lower()
                        if self.domain in sub:
                            subdomains.add(sub)
                for item in data.get('RDNS', []):
                    parts = item.split(',')
                    if len(parts) > 1:
                        sub = parts[1].lower()
                        if self.domain in sub:
                            subdomains.add(sub)
            logger.info(f"[BufferOver] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[BufferOver] Error: {e}")
        return subdomains
    
    async def query_sonarsearch(self) -> Set[str]:
        """Query SonarSearch (Project Sonar)"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://sonar.omnisint.io/subdomains/{self.domain}")
            if data and isinstance(data, list):
                for sub in data:
                    subdomains.add(sub.lower())
            logger.info(f"[SonarSearch] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[SonarSearch] Error: {e}")
        return subdomains
    
    async def query_jldc(self) -> Set[str]:
        """Query JLDC DNS"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://jldc.me/anubis/subdomains/{self.domain}")
            if text:
                try:
                    data = json.loads(text)
                    for sub in data:
                        subdomains.add(sub.lower())
                except:
                    pass
            logger.info(f"[JLDC] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[JLDC] Error: {e}")
        return subdomains
    
    async def query_threatminer(self) -> Set[str]:
        """Query ThreatMiner"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://api.threatminer.org/v2/domain.php?q={self.domain}&rt=5")
            if data:
                for item in data.get('results', []):
                    sub = item.lower()
                    if self.domain in sub:
                        subdomains.add(sub)
            logger.info(f"[ThreatMiner] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ThreatMiner] Error: {e}")
        return subdomains
    
    async def query_anubis(self) -> Set[str]:
        """Query Anubis-DB"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://anubisdb.com/api/subdomains/{self.domain}")
            if data:
                for sub in data:
                    subdomains.add(sub.lower())
            logger.info(f"[AnubisDB] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[AnubisDB] Error: {e}")
        return subdomains
    
    async def query_hackertarget_dns(self) -> Set[str]:
        """Query HackerTarget DNS enumeration"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://api.hackertarget.com/dnsenum/?q={self.domain}")
            if text:
                for line in text.split('\n'):
                    if ':' in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            sub = parts[0].strip().lower()
                            if self.domain in sub:
                                subdomains.add(sub)
            logger.info(f"[HackerTarget DNS] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[HackerTarget DNS] Error: {e}")
        return subdomains
    
    async def query_fullhunt(self) -> Set[str]:
        """Query FullHunt"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://fullhunt.io/api/v1/domain/{self.domain}/subdomains")
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(sub.lower())
            logger.info(f"[FullHunt] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[FullHunt] Error: {e}")
        return subdomains
    
    async def query_recondev(self) -> Set[str]:
        """Query Recon.dev"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://recon.dev/api/search?domain={self.domain}")
            if data:
                for item in data.get('matches', []):
                    sub = item.get('domain', '').lower()
                    if sub:
                        subdomains.add(sub)
            logger.info(f"[Recon.dev] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Recon.dev] Error: {e}")
        return subdomains
    
    async def run_all(self) -> Set[str]:
        """Execute all passive reconnaissance sources"""
        tasks = [
            # Certificate sources
            self.query_crtsh(),
            self.query_censys_certificates(),
            
            # DNS sources
            self.query_dnsdumpster(),
            self.query_hackertarget(),
            self.query_threatcrowd(),
            self.query_alienvault(),
            self.query_virustotal(),
            self.query_urlscan(),
            self.query_rapiddns(),
            
            # Search engines
            self.query_wayback(),
            self.query_commoncrawl(),
            
            # Threat intelligence
            self.query_securitytrails(),
            self.query_shodan(),
            self.query_binaryedge(),
            self.query_zoomeye(),
            
            # Additional sources
            self.query_bufferover(),
            self.query_sonarsearch(),
            self.query_jldc(),
            self.query_threatminer(),
            self.query_anubis(),
            self.query_hackertarget_dns(),
            self.query_fullhunt(),
            self.query_recondev(),
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_subdomains = set()
        for result in results:
            if isinstance(result, set):
                all_subdomains.update(result)
        
        await self.close_session()
        return all_subdomains


# ═══════════════════════════════════════════════════════════════════════════
# SUBDOMAIN TAKEOVER DETECTION
# ═══════════════════════════════════════════════════════════════════════════

class SubdomainTakeoverDetector:
    """
    Detect vulnerable subdomain takeovers
    Based on fingerprints from Can-I-Take-Over-XYZ
    """
    
    TAKEOVER_FINGERPRINTS = {
        'GitHub Pages': {
            'cnames': ['github.io', 'github.com'],
            'text': ['There isn\'t a GitHub Pages site here', '404 File not found'],
            'vulnerable': True
        },
        'Heroku': {
            'cnames': ['herokuapp.com', 'herokussl.com'],
            'text': ['no such app', 'heroku'],
            'vulnerable': True
        },
        'Shopify': {
            'cnames': ['myshopify.com'],
            'text': ['only one step left', 'shopify'],
            'vulnerable': True
        },
        'Tumblr': {
            'cnames': ['tumblr.com'],
            'text': ['whatever you were looking for doesn\'t currently exist', 'tumblr'],
            'vulnerable': True
        },
        'WordPress': {
            'cnames': ['wordpress.com'],
            'text': ['do you want to register', 'wordpress.com'],
            'vulnerable': True
        },
        'Teamwork': {
            'cnames': ['teamwork.com'],
            'text': ['site not found', 'teamwork'],
            'vulnerable': True
        },
        'HelpScout': {
            'cnames': ['helpscoutdocs.com'],
            'text': ['No settings were found for this company', 'helpscout'],
            'vulnerable': True
        },
        'Freshdesk': {
            'cnames': ['freshdesk.com'],
            'text': ['Oh no! Something went wrong', 'freshdesk'],
            'vulnerable': True
        },
        'Zendesk': {
            'cnames': ['zendesk.com'],
            'text': ['Help Center Closed', 'zendesk'],
            'vulnerable': True
        },
        'Cargo': {
            'cnames': ['cargo.site'],
            'text': ['404 — File not found', 'cargo'],
            'vulnerable': True
        },
        'Readme.io': {
            'cnames': ['readme.io'],
            'text': ['Project doesnt exist... yet!', 'readme'],
            'vulnerable': True
        },
        'Surge.sh': {
            'cnames': ['surge.sh'],
            'text': ['project not found', 'surge'],
            'vulnerable': True
        },
        'Netlify': {
            'cnames': ['netlify.com', 'netlify.app'],
            'text': ['Not Found - Request ID', 'netlify'],
            'vulnerable': True
        },
        'Vercel': {
            'cnames': ['vercel.app', 'now.sh'],
            'text': ['The deployment could not be found', 'vercel'],
            'vulnerable': True
        },
        'Firebase': {
            'cnames': ['firebaseapp.com'],
            'text': ['Hosting Site Not Found', 'firebase'],
            'vulnerable': True
        },
        'Amazon S3': {
            'cnames': ['amazonaws.com', 's3.amazonaws.com', 's3-website'],
            'text': ['NoSuchBucket', 'The specified bucket does not exist'],
            'vulnerable': True
        },
        'Bitbucket': {
            'cnames': ['bitbucket.io'],
            'text': ['Repository not found', 'bitbucket'],
            'vulnerable': True
        },
        'Ghost': {
            'cnames': ['ghost.io'],
            'text': ['The page you were looking for doesn\'t exist', 'ghost'],
            'vulnerable': True
        },
        'Webflow': {
            'cnames': ['webflow.io'],
            'text': ['The page you are looking for doesn\'t exist', 'webflow'],
            'vulnerable': True
        },
        'Strikingly': {
            'cnames': ['strikinglydns.com'],
            'text': ['But it\'s not too late', 'strikingly'],
            'vulnerable': True
        },
        'Uptime Robot': {
            'cnames': ['uptimerobot.com'],
            'text': ['page not found', 'uptimerobot'],
            'vulnerable': True
        },
        'Pantheon': {
            'cnames': ['pantheonsite.io'],
            'text': ['The pantheon front end server is now installed', 'pantheon'],
            'vulnerable': True
        },
        'Feedpress': {
            'cnames': ['feedpress.it'],
            'text': ['The feed has not been found', 'feedpress'],
            'vulnerable': True
        },
        'Smugmug': {
            'cnames': ['smugmug.com'],
            'text': ['Not Found', 'smugmug'],
            'vulnerable': True
        },
        'Tilda': {
            'cnames': ['tilda.ws'],
            'text': ['Domain has been assigned', 'tilda'],
            'vulnerable': True
        },
        'Aerobatic': {
            'cnames': ['aerobatic.io'],
            'text': ['404 Not Found', 'aerobatic'],
            'vulnerable': True
        },
        'Kinsta': {
            'cnames': ['kinsta.com'],
            'text': ['No site found at this address', 'kinsta'],
            'vulnerable': True
        },
        'LaunchRock': {
            'cnames': ['launchrock.com'],
            'text': ['It looks like you may have taken a wrong turn', 'launchrock'],
            'vulnerable': True
        },
        'Fly.io': {
            'cnames': ['fly.dev'],
            'text': ['Not Found', 'fly'],
            'vulnerable': True
        },
        'Render': {
            'cnames': ['render.com', 'onrender.com'],
            'text': ['Not Found', 'render'],
            'vulnerable': True
        },
        'Azure': {
            'cnames': ['azurewebsites.net', 'cloudapp.net', 'azureedge.net'],
            'text': ['404 Web Site not found', 'azure'],
            'vulnerable': True
        },
        'DigitalOcean': {
            'cnames': ['digitaloceanspaces.com', 'ondigitalocean.app'],
            'text': ['The specified bucket does not exist', 'digitalocean'],
            'vulnerable': True
        },
        'Fastly': {
            'cnames': ['fastly.net', 'fastly-edge.com'],
            'text': ['Fastly error: unknown domain', 'fastly'],
            'vulnerable': True
        },
        'CloudFront': {
            'cnames': ['cloudfront.net'],
            'text': ['ERROR: The request could not be satisfied', 'cloudfront'],
            'vulnerable': False  # CloudFront takeover is not typically exploitable
        },
        'Cloudflare': {
            'cnames': ['cloudflare.net'],
            'text': ['Error 1000', 'cloudflare'],
            'vulnerable': False
        }
    }
    
    @classmethod
    async def check_takeover(cls, subdomain: str, cnames: List[str], http_content: str) -> Tuple[bool, Optional[str]]:
        """Check if subdomain is vulnerable to takeover"""
        content_lower = http_content.lower()
        
        for service, fingerprints in cls.TAKEOVER_FINGERPRINTS.items():
            # Check CNAME matches
            cname_match = False
            for cname_pattern in fingerprints['cnames']:
                for cname in cnames:
                    if cname_pattern.lower() in cname.lower():
                        cname_match = True
                        break
                if cname_match:
                    break
            
            # Check content fingerprints
            content_match = False
            for text_pattern in fingerprints['text']:
                if text_pattern.lower() in content_lower:
                    content_match = True
                    break
            
            # If both CNAME and content match, it's vulnerable
            if cname_match and content_match and fingerprints['vulnerable']:
                return True, service
        
        return False, None


# ═══════════════════════════════════════════════════════════════════════════
# JAVASCRIPT ANALYZER & SECRET DETECTOR
# ═══════════════════════════════════════════════════════════════════════════

class JavaScriptAnalyzer:
    """
    Analyze JavaScript files for secrets, API endpoints, and sensitive data
    """
    
    SECRET_PATTERNS = {
        'AWS Access Key': r'AKIA[0-9A-Z]{16}',
        'AWS Secret Key': r'(?i)aws(.{0,20})?[\'\"][0-9a-zA-Z\/+]{40}[\'\"]',
        'Google API Key': r'AIza[0-9A-Za-z\-_]{35}',
        'Google OAuth': r'[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com',
        'GitHub Token': r'ghp_[0-9a-zA-Z]{36}',
        'GitHub OAuth': r'gho_[0-9a-zA-Z]{36}',
        'GitHub App': r'(ghu|ghs|ghr)_[0-9a-zA-Z]{36}',
        'Slack Token': r'xox[baprs]-[0-9]{12}-[0-9]{12}-[0-9a-zA-Z]{24}',
        'Slack Webhook': r'https://hooks\.slack\.com/services/T[0-9A-Z]{8}/B[0-9A-Z]{8}/[0-9a-zA-Z]{24}',
        'Stripe API Key': r'sk_live_[0-9a-zA-Z]{24}',
        'Stripe Publishable': r'pk_live_[0-9a-zA-Z]{24}',
        'Square Access Token': r'sq0atp-[0-9A-Za-z\-_]{22}',
        'Square OAuth Secret': r'sq0csp-[0-9A-Za-z\-_]{43}',
        'PayPal/Braintree': r'access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}',
        'Twilio Account SID': r'AC[a-f0-9]{32}',
        'Twilio Auth Token': r'[a-f0-9]{32}',
        'Mailgun API Key': r'key-[0-9a-zA-Z]{32}',
        'Mailchimp API Key': r'[0-9a-f]{32}-us[0-9]{1,2}',
        'SendGrid API Key': r'SG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}',
        'Private Key': r'-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----',
        'Generic Secret': r'(?i)(api[_-]?key|apikey|api[_-]?secret|secret[_-]?key|access[_-]?token|auth[_-]?token|bearer)[\s]*[=:]\s*[\'\"][0-9a-zA-Z\-_]{16,}[\'\"]',
        'JWT Token': r'eyJ[a-zA-Z0-9\-_]+\.eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+',
        'Firebase URL': r'https://[a-z0-9-]+\.firebaseio\.com',
        'Heroku API Key': r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
        'Generic API Key': r'(?i)[\'\"][0-9a-f]{32,}[\'\"]',
        'Password in URL': r'://[^:]+:[^@]+@[a-zA-Z0-9.-]+',
    }
    
    API_ENDPOINT_PATTERNS = [
        r'[\'\"](/api/v[0-9]+/[a-zA-Z0-9/-]+)[\'\"]',
        r'[\'\"](/api/[a-zA-Z0-9/-]+)[\'\"]',
        r'[\'\"]([a-zA-Z0-9_-]+/api/[a-zA-Z0-9/-]+)[\'\"]',
        r'fetch\([\'\"]([^\"\']+)[\'\"]',
        r'axios\.[a-z]+\([\'\"]([^\"\']+)[\'\"]',
        r'\$\.ajax\([^)]*url:\s*[\'\"]([^\"\']+)[\'\"]',
        r'XMLHttpRequest.*open\([\'\"][^\"\']*[\'\"],\s*[\'\"]([^\"\']+)[\'\"]',
    ]
    
    @classmethod
    async def analyze_js_file(cls, js_url: str, session: aiohttp.ClientSession) -> Dict:
        """Analyze a single JavaScript file"""
        result = {
            'url': js_url,
            'secrets': [],
            'endpoints': [],
            'size': 0,
            'error': None
        }
        
        try:
            async with session.get(js_url, timeout=15, ssl=False) as response:
                if response.status == 200:
                    content = await response.text()
                    result['size'] = len(content)
                    
                    # Find secrets
                    for secret_name, pattern in cls.SECRET_PATTERNS.items():
                        matches = re.findall(pattern, content)
                        for match in matches:
                            result['secrets'].append({
                                'type': secret_name,
                                'value': match[:50] + '...' if len(match) > 50 else match,
                                'full_match': match
                            })
                    
                    # Find API endpoints
                    for pattern in cls.API_ENDPOINT_PATTERNS:
                        matches = re.findall(pattern, content)
                        for match in matches:
                            if match and not match.startswith('http'):
                                result['endpoints'].append(match)
        
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    @classmethod
    async def extract_js_files(cls, html_content: str, base_url: str) -> List[str]:
        """Extract JavaScript file URLs from HTML"""
        js_files = []
        
        # Pattern for script tags
        patterns = [
            r'<script[^>]+src=[\'\"]([^\"\']+\.js[^\"\']*)[\'\"]',
            r'<script[^>]+src=([^\s>]+\.js[^\s>]*)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            for match in matches:
                # Convert relative URLs to absolute
                if match.startswith('//'):
                    match = 'https:' + match
                elif match.startswith('/'):
                    parsed = urlparse(base_url)
                    match = f"{parsed.scheme}://{parsed.netloc}{match}"
                elif not match.startswith('http'):
                    match = urljoin(base_url, match)
                
                js_files.append(match)
        
        return list(set(js_files))


# ═══════════════════════════════════════════════════════════════════════════
# CLOUD STORAGE BUCKET DETECTOR
# ═══════════════════════════════════════════════════════════════════════════

class CloudBucketDetector:
    """
    Detect exposed cloud storage buckets
    """
    
    BUCKET_PATTERNS = {
        'AWS S3': {
            'patterns': [
                r'https?://([a-z0-9-]+)\.s3\.amazonaws\.com',
                r'https?://s3\.amazonaws\.com/([a-z0-9-]+)',
                r'https?://([a-z0-9-]+)\.s3-([a-z0-9-]+)\.amazonaws\.com',
            ],
            'check_url': 'https://{bucket}.s3.amazonaws.com',
            'exists_text': ['ListBucketResult', 'Contents']
        },
        'Google Cloud Storage': {
            'patterns': [
                r'https?://storage\.googleapis\.com/([a-z0-9-]+)',
                r'https?://([a-z0-9-]+)\.storage\.googleapis\.com',
            ],
            'check_url': 'https://storage.googleapis.com/{bucket}',
            'exists_text': ['ListBucketResult', 'Items']
        },
        'Azure Blob Storage': {
            'patterns': [
                r'https?://([a-z0-9-]+)\.blob\.core\.windows\.net',
                r'https?://([a-z0-9-]+)\.blob\.storage\.azure\.net',
            ],
            'check_url': 'https://{bucket}.blob.core.windows.net',
            'exists_text': ['EnumerationResults', 'Containers']
        },
        'DigitalOcean Spaces': {
            'patterns': [
                r'https?://([a-z0-9-]+)\.([a-z0-9-]+)\.digitaloceanspaces\.com',
            ],
            'check_url': 'https://{bucket}.{region}.digitaloceanspaces.com',
            'exists_text': ['ListBucketResult']
        },
        'Firebase Storage': {
            'patterns': [
                r'https?://firebasestorage\.googleapis\.com/v0/b/([a-z0-9-]+)',
                r'https?://storage\.googleapis\.com/([a-z0-9-]+)\.appspot\.com',
            ],
            'check_url': 'https://firebasestorage.googleapis.com/v0/b/{bucket}',
            'exists_text': ['items', 'name']
        }
    }
    
    @classmethod
    async def detect_buckets(cls, domain: str, html_content: str, session: aiohttp.ClientSession) -> List[Dict]:
        """Detect cloud storage buckets in HTML content"""
        buckets = []
        
        for provider, config in cls.BUCKET_PATTERNS.items():
            for pattern in config['patterns']:
                matches = re.findall(pattern, html_content)
                for match in matches:
                    bucket_name = match if isinstance(match, str) else match[0]
                    
                    # Check if bucket exists and is accessible
                    bucket_info = {
                        'provider': provider,
                        'bucket': bucket_name,
                        'accessible': False,
                        'public': False
                    }
                    
                    try:
                        check_url = config['check_url'].format(bucket=bucket_name, region='us-east-1')
                        async with session.get(check_url, timeout=10, ssl=False) as response:
                            if response.status == 200:
                                text = await response.text()
                                bucket_info['accessible'] = True
                                
                                for exists_text in config['exists_text']:
                                    if exists_text in text:
                                        bucket_info['public'] = True
                                        break
                    except:
                        pass
                    
                    buckets.append(bucket_info)
        
        return buckets
    
    @classmethod
    def generate_bucket_names(cls, domain: str) -> List[str]:
        """Generate potential bucket names for bruteforce"""
        base_names = [
            domain,
            domain.replace('.', '-'),
            domain.replace('.', ''),
            domain.split('.')[0],
            f"{domain}-backup",
            f"{domain}-backups",
            f"{domain}-dev",
            f"{domain}-prod",
            f"{domain}-staging",
            f"{domain}-logs",
            f"{domain}-assets",
            f"{domain}-media",
            f"{domain}-static",
            f"{domain}-uploads",
            f"{domain}-files",
            f"{domain}-data",
            f"{domain}-config",
            f"{domain}-private",
            f"{domain}-public",
            f"{domain}-secure",
        ]
        return base_names


# ═══════════════════════════════════════════════════════════════════════════
# EMAIL ENUMERATOR
# ═══════════════════════════════════════════════════════════════════════════

class EmailEnumerator:
    """
    Email address enumeration from various sources
    """
    
    EMAIL_PATTERNS = [
        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    ]
    
    @classmethod
    async def extract_from_page(cls, url: str, session: aiohttp.ClientSession) -> List[str]:
        """Extract emails from a webpage"""
        emails = set()
        
        try:
            async with session.get(url, timeout=15, ssl=False) as response:
                if response.status == 200:
                    content = await response.text()
                    for pattern in cls.EMAIL_PATTERNS:
                        matches = re.findall(pattern, content)
                        for email in matches:
                            # Filter out common false positives
                            if not any(x in email.lower() for x in ['example.com', 'domain.com', 'email.com', 'youremail']):
                                emails.add(email.lower())
        except:
            pass
        
        return list(emails)
    
    @classmethod
    async def query_hunter_io(cls, domain: str, api_key: str = None) -> List[Dict]:
        """Query Hunter.io for emails (requires API key)"""
        emails = []
        
        if not api_key:
            return emails
        
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://api.hunter.io/v2/domain-search?domain={domain}&api_key={api_key}"
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        for email_data in data.get('data', {}).get('emails', []):
                            emails.append({
                                'email': email_data.get('value'),
                                'type': email_data.get('type'),
                                'confidence': email_data.get('confidence'),
                                'sources': email_data.get('sources', [])
                            })
        except:
            pass
        
        return emails


# ═══════════════════════════════════════════════════════════════════════════
# ADVANCED DNS RESOLVER
# ═══════════════════════════════════════════════════════════════════════════

class AdvancedDNSResolver:
    """
    High-performance DNS resolver with caching and multiple servers
    """
    
    DNS_SERVERS = [
        '8.8.8.8',          # Google
        '8.8.4.4',          # Google Secondary
        '1.1.1.1',          # Cloudflare
        '1.0.0.1',          # Cloudflare Secondary
        '9.9.9.9',          # Quad9
        '208.67.222.222',   # OpenDNS
        '208.67.220.220',   # OpenDNS Secondary
        '76.76.19.19',      # Control D
        '76.76.2.0',        # Control D Secondary
        '94.140.14.14',     # AdGuard
    ]
    
    def __init__(self, timeout=5, max_retries=3):
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache = {}
        self.resolver = None
    
    async def resolve(self, domain: str, record_type: str = 'A') -> List[str]:
        """Async DNS resolution with caching"""
        cache_key = f"{domain}_{record_type}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        if not self.resolver:
            self.resolver = aiodns.DNSResolver(timeout=self.timeout)
        
        for attempt in range(self.max_retries):
            try:
                result = await self.resolver.query(domain, record_type)
                
                records = []
                for r in result:
                    if hasattr(r, 'host'):
                        records.append(r.host)
                    elif hasattr(r, 'address'):
                        records.append(r.address)
                    elif hasattr(r, 'target'):
                        records.append(str(r.target).rstrip('.'))
                    elif hasattr(r, 'exchange'):
                        records.append(str(r.exchange).rstrip('.'))
                    elif hasattr(r, 'text'):
                        records.append(r.text)
                
                self.cache[cache_key] = records
                return records
                
            except aiodns.error.DNSError:
                if attempt == self.max_retries - 1:
                    return []
                await asyncio.sleep(0.5 * (attempt + 1))
            except Exception as e:
                logger.debug(f"DNS error for {domain} ({record_type}): {e}")
                return []
        
        return []
    
    async def resolve_all(self, domain: str) -> Dict[str, List[str]]:
        """Resolve all common record types"""
        record_types = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SOA']
        results = {}
        
        for record_type in record_types:
            try:
                results[record_type] = await self.resolve(domain, record_type)
            except:
                results[record_type] = []
        
        return results
    
    async def reverse_dns(self, ip: str) -> List[str]:
        """Reverse DNS lookup"""
        try:
            addr = dns.reversename.from_address(ip)
            resolver = dns.resolver.Resolver()
            resolver.nameservers = ['8.8.8.8']
            
            answers = resolver.query(addr, 'PTR')
            return [str(rdata) for rdata in answers]
        except:
            return []


# ═══════════════════════════════════════════════════════════════════════════
# DNS BRUTE FORCE ENGINE
# ═══════════════════════════════════════════════════════════════════════════

class DNSBruteForcer:
    """
    Advanced DNS bruteforce with permutation generation
    """
    
    # Comprehensive wordlist
    COMMON_SUBDOMAINS = [
        'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'ns2',
        'admin', 'administrator', 'beta', 'stage', 'staging', 'dev', 'development',
        'test', 'testing', 'demo', 'prod', 'production', 'api', 'apis', 'gateway',
        'cdn', 'cache', 'static', 'media', 'assets', 'img', 'images', 'image',
        'blog', 'shop', 'store', 'ecommerce', 'portal', 'vpn', 'remote', 'secure',
        'login', 'signin', 'signup', 'register', 'auth', 'sso', 'oauth', 'm', 'mobile',
        'app', 'apps', 'support', 'help', 'docs', 'documentation', 'wiki', 'kb',
        'forum', 'community', 'news', 'status', 'monitor', 'monitoring', 'dashboard',
        'cpanel', 'whm', 'webdisk', 'plesk', 'panel', 'console', 'control',
        'db', 'database', 'mysql', 'postgres', 'redis', 'mongo', 'elasticsearch',
        'backup', 'backups', 'old', 'new', 'temp', 'tmp', 'dev', 'staging',
        'v1', 'v2', 'v3', 'api-v1', 'api-v2', 'beta-v1', 'internal', 'external',
        'partners', 'partner', 'client', 'clients', 'customer', 'customers',
        'download', 'downloads', 'upload', 'uploads', 'file', 'files', 'data',
        'marketing', 'sales', 'crm', 'erp', 'hr', 'finance', 'accounting',
        # Additional common subdomains
        'www1', 'www2', 'www3', 'www4', 'www5', 'www6', 'www7', 'www8', 'www9',
        'mail1', 'mail2', 'mail3', 'email', 'imap', 'pop3', 'smtp2',
        'ns3', 'ns4', 'dns1', 'dns2', 'dns3', 'dns4',
        'web1', 'web2', 'web3', 'web4', 'web5',
        'server', 'srv', 'host', 'hostname',
        'git', 'gitlab', 'github', 'bitbucket', 'svn', 'code', 'repo',
        'jenkins', 'ci', 'cd', 'build', 'builder', 'deploy', 'deployment',
        'grafana', 'kibana', 'prometheus', 'alertmanager', 'zabbix', 'nagios',
        'jira', 'confluence', 'redmine', 'bugzilla', 'mantis',
        'mattermost', 'slack', 'rocketchat', 'discord', 'teams',
        'nextcloud', 'owncloud', 'seafile', 'fileserver',
        'office', 'owa', 'exchange', 'autodiscover', 'lync', 'sip',
        'vpn1', 'vpn2', 'vpn3', 'remote1', 'remote2',
        'proxy', 'proxy1', 'proxy2', 'squid', 'cache1', 'cache2',
        'firewall', 'fw', 'security', 'sec', 'secure',
        'sandbox', 'lab', 'labs', 'research', 'devops',
        'k8s', 'kubernetes', 'docker', 'registry', 'harbor',
        'rancher', 'portainer', 'traefik', 'nginx', 'apache',
        'phpmyadmin', 'adminer', 'pgadmin', 'phppgadmin',
        'solr', 'elastic', 'kafka', 'rabbitmq', 'activemq',
        'hadoop', 'spark', 'hive', 'presto', 'airflow',
        'jenkins', 'bamboo', 'teamcity', 'go', 'circleci',
        'artifactory', 'nexus', 'sonar', 'sonarqube',
        'ldap', 'openldap', 'ad', 'dc', 'domain',
        'radius', 'freeradius', 'tacacs',
        'ftp1', 'ftp2', 'sftp', 'ftps',
        'ssh', 'ssh2', 'telnet', 'rdp', 'xrdp',
        'nfs', 'smb', 'cifs', 'afp',
        'ldap', 'ldaps', 'kerberos', 'spnego',
        'sip', 'sips', 'h323', 'mgcp',
        'xmpp', 'jabber', 'irc', 'matrix',
        'stun', 'turn', 'coturn',
        'etcd', 'consul', 'zookeeper', 'vault',
        'nomad', 'terraform', 'packer', 'vagrant',
        'ansible', 'puppet', 'chef', 'salt',
        'grafana', 'influxdb', 'timescaledb',
        'clickhouse', 'druid', 'superset',
        'metabase', 'redash', 'superset',
        'airflow', 'dagster', 'prefect', 'luigi',
        'mlflow', 'kubeflow', 'sagemaker',
        'jupyter', 'notebook', 'lab', 'hub',
        'tensorboard', 'wandb', 'neptune',
        'minio', 'ceph', 'glusterfs', 'moosefs',
        'openstack', 'swift', 'nova', 'neutron', 'cinder',
        'cloud', 'cloud1', 'cloud2', 'private', 'public',
        'internal', 'external', 'intranet', 'extranet',
        'portal', 'portal1', 'portal2', 'portal3',
        'ws', 'websocket', 'socket', 'sockets',
        'graphql', 'grpc', 'thrift', 'avro',
        'rest', 'restful', 'soap', 'wsdl',
        'swagger', 'openapi', 'redoc', 'rapidoc',
        'health', 'healthz', 'ready', 'readyz', 'live', 'livez',
        'metrics', 'metrics1', 'metrics2', 'stats', 'statistics',
        'trace', 'tracing', 'jaeger', 'zipkin', 'opencensus',
        'istio', 'envoy', 'linkerd', 'consul-connect',
        'calico', 'flannel', 'weave', 'cilium',
        'argocd', 'flux', 'helm', 'tiller',
        'spinnaker', 'keel', 'keelbot',
        'falco', 'sysdig', 'ossec', 'wazuh',
        'clamav', 'spamassassin', 'amavis',
        'postfix', 'dovecot', 'courier', 'exim',
        'bind', 'powerdns', 'unbound', 'coredns',
        'dnsmasq', 'pdns', 'pdns-recursor',
        'squid', 'squid3', 'tinyproxy', 'privoxy',
        'tor', 'privoxy', 'polipo',
        'shadowsocks', 'ss-local', 'v2ray', 'trojan',
        'openvpn', 'wireguard', 'tinc', 'zerotier',
        'strongswan', 'libreswan', 'openswan',
        'libvirt', 'kvm', 'qemu', 'xen',
        'vmware', 'vcenter', 'esxi', 'vSphere',
        'proxmox', 'lxc', 'lxd', 'docker-registry',
        'rancher', 'rke', 'k3s', 'k3d',
        'microk8s', 'minikube', 'kind',
    ]
    
    def __init__(self, domain: str, resolver: AdvancedDNSResolver, wordlist: List[str] = None):
        self.domain = domain
        self.resolver = resolver
        self.wordlist = wordlist or self.COMMON_SUBDOMAINS
        self.found_subdomains = set()
    
    def generate_permutations(self, subdomains: Set[str]) -> Set[str]:
        """Generate permutations from discovered subdomains"""
        permutations = set()
        
        separators = ['-', '_', '']
        numbers = ['1', '2', '3', '01', '02', '03', '0', '1', '2']
        prefixes = ['dev', 'test', 'beta', 'staging', 'prod', 'new', 'old', 'www', 'api', 'app', 'admin', 'portal', 'secure', 'vpn', 'mail', 'remote', 'internal', 'external']
        suffixes = ['api', 'app', 'web', 'server', 'portal', 'admin', 'dev', 'test', 'prod', 'staging', 'beta', 'v1', 'v2', 'v3']
        
        for subdomain in list(subdomains)[:100]:  # Limit to avoid explosion
            # Extract the subdomain part
            sub_part = subdomain.replace(f'.{self.domain}', '').split('.')[0]
            
            # Add numbers
            for num in numbers:
                for sep in separators:
                    permutations.add(f"{sub_part}{sep}{num}.{self.domain}")
            
            # Add prefixes and suffixes
            for prefix in prefixes:
                for sep in separators:
                    permutations.add(f"{prefix}{sep}{sub_part}.{self.domain}")
            
            for suffix in suffixes:
                for sep in separators:
                    permutations.add(f"{sub_part}{sep}{suffix}.{self.domain}")
        
        return permutations
    
    async def bruteforce(self, batch_size: int = 100) -> Set[str]:
        """Perform DNS bruteforce with batching"""
        logger.info(f"Starting DNS bruteforce with {len(self.wordlist)} words")
        
        found = set()
        candidates = [f"{word}.{self.domain}" for word in self.wordlist]
        
        for i in range(0, len(candidates), batch_size):
            batch = candidates[i:i + batch_size]
            tasks = [self.resolver.resolve(candidate) for candidate in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for candidate, result in zip(batch, results):
                if isinstance(result, list) and result:
                    found.add(candidate)
                    logger.info(f"[Bruteforce] Found: {candidate}")
        
        self.found_subdomains = found
        return found


# ═══════════════════════════════════════════════════════════════════════════
# IP INTELLIGENCE & CDN DETECTION
# ═══════════════════════════════════════════════════════════════════════════

class IPIntelligence:
    """
    Advanced IP intelligence with CDN detection
    """
    
    CDN_RANGES = {
        'Cloudflare': [
            '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
            '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
            '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
            '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22'
        ],
        'Akamai': [
            '23.0.0.0/8', '95.100.0.0/16', '96.6.0.0/15', '104.64.0.0/10',
            '184.24.0.0/13', '2.16.0.0/13'
        ],
        'CloudFront': [
            '13.32.0.0/15', '13.35.0.0/16', '13.224.0.0/14', '13.249.0.0/16',
            '18.64.0.0/14', '52.84.0.0/15', '52.222.128.0/17', '54.182.0.0/16',
            '54.192.0.0/16', '54.230.0.0/16', '54.239.128.0/18', '54.239.192.0/19',
            '99.84.0.0/16', '204.246.164.0/22', '204.246.168.0/22', '204.246.174.0/23',
            '204.246.176.0/20', '205.251.192.0/19', '205.251.249.0/24', '205.251.250.0/23',
            '205.251.252.0/23', '205.251.254.0/24'
        ],
        'Fastly': [
            '23.235.32.0/20', '43.249.72.0/22', '103.244.50.0/24', '103.245.222.0/23',
            '103.245.224.0/24', '104.156.80.0/20', '140.248.64.0/18', '140.248.128.0/17',
            '146.75.0.0/17', '151.101.0.0/16', '157.52.64.0/18', '167.82.0.0/17',
            '167.82.128.0/20', '167.82.160.0/20', '167.82.224.0/20', '172.111.64.0/18',
            '185.31.16.0/22', '199.27.72.0/21', '199.232.0.0/16'
        ],
        'AWS': [
            '3.0.0.0/8', '13.0.0.0/8', '18.0.0.0/8', '34.192.0.0/10',
            '35.0.0.0/8', '52.0.0.0/8', '54.0.0.0/8'
        ],
        'Incapsula': [
            '45.60.0.0/16', '45.64.64.0/18', '103.28.248.0/22', '185.11.124.0/22',
            '192.230.64.0/18', '198.143.32.0/19', '199.83.128.0/21'
        ],
        'Azure': [
            '4.128.0.0/9', '13.64.0.0/11', '13.96.0.0/13', '13.104.0.0/14',
            '20.0.0.0/8', '40.0.0.0/8', '51.0.0.0/8', '52.0.0.0/8',
            '104.40.0.0/13', '104.146.0.0/15', '137.116.0.0/15', '138.91.0.0/16',
            '157.55.0.0/16', '168.61.0.0/16', '191.232.0.0/13'
        ],
        'Google Cloud': [
            '8.34.208.0/20', '8.35.192.0/20', '8.35.248.0/21', '35.184.0.0/13',
            '35.192.0.0/14', '35.196.0.0/15', '35.198.0.0/16', '35.199.0.0/17',
            '35.199.128.0/18', '35.200.0.0/13', '35.208.0.0/12', '35.224.0.0/12',
            '35.240.0.0/13', '104.154.0.0/15', '104.196.0.0/14', '107.167.160.0/19',
            '107.178.192.0/18', '130.211.0.0/16', '146.148.0.0/17'
        ],
        'DigitalOcean': [
            '45.55.0.0/16', '46.101.0.0/16', '64.227.0.0/16', '67.205.0.0/16',
            '68.183.0.0/16', '104.131.0.0/16', '104.248.0.0/16', '138.68.0.0/16',
            '142.93.0.0/16', '157.245.0.0/16', '159.65.0.0/16', '159.89.0.0/16',
            '165.22.0.0/16', '167.99.0.0/16', '170.64.0.0/16', '174.138.0.0/16',
            '178.128.0.0/16', '188.166.0.0/16', '206.189.0.0/16', '209.97.128.0/17'
        ]
    }
    
    ASN_CDNS = {
        'AS13335': 'Cloudflare',
        'AS16625': 'Akamai',
        'AS16509': 'Amazon/CloudFront',
        'AS54113': 'Fastly',
        'AS19551': 'Incapsula',
        'AS8075': 'Microsoft/Azure',
        'AS396982': 'Google Cloud'
    }
    
    @classmethod
    def detect_cdn(cls, ip: str) -> Tuple[bool, Optional[str]]:
        """Detect if IP belongs to a CDN"""
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            for provider, ranges in cls.CDN_RANGES.items():
                for cidr in ranges:
                    try:
                        if ip_obj in ipaddress.ip_network(cidr):
                            return True, provider
                    except:
                        continue
        except ValueError:
            pass
        
        return False, None
    
    @staticmethod
    def get_asn(ip: str) -> Optional[str]:
        """Get ASN information for an IP"""
        try:
            result = subprocess.run(
                ['whois', '-h', 'whois.cymru.com', f' -v {ip}'],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            lines = result.stdout.split('\n')
            for line in lines:
                if 'AS' in line:
                    return line.strip()
        except:
            pass
        return None


# ═══════════════════════════════════════════════════════════════════════════
# TECHNOLOGY DETECTOR
# ═══════════════════════════════════════════════════════════════════════════

class TechnologyDetector:
    """
    Detect web technologies from HTML content and headers
    """
    
    TECH_SIGNATURES = {
        # CMS
        'WordPress': {
            'html': ['wp-content', 'wp-includes', 'wordpress', 'wp-emoji'],
            'headers': [],
            'cookies': ['wordpress_', 'wp-settings-']
        },
        'Drupal': {
            'html': ['drupal', 'sites/default/files'],
            'headers': ['X-Drupal-Cache', 'X-Generator: Drupal'],
            'cookies': ['SESS', 'SSESS']
        },
        'Joomla': {
            'html': ['joomla', '/components/com_'],
            'headers': [],
            'cookies': ['joomla_user_state']
        },
        'Magento': {
            'html': ['magento', 'mage/', '/skin/frontend/'],
            'headers': [],
            'cookies': ['frontend', 'mage-']
        },
        'Shopify': {
            'html': ['shopify', 'cdn.shopify.com'],
            'headers': ['X-Shopify-'],
            'cookies': ['_shopify']
        },
        'Wix': {
            'html': ['wix.com', 'wixstatic.com', '_wix_browser_sess'],
            'headers': ['X-Wix-'],
            'cookies': []
        },
        'Squarespace': {
            'html': ['squarespace', 'static.squarespace.com'],
            'headers': ['X-Squarespace-'],
            'cookies': []
        },
        # Frameworks
        'React': {
            'html': ['react', 'react-dom', '__REACT_DEVTOOLS_GLOBAL_HOOK__'],
            'headers': [],
            'cookies': []
        },
        'Vue.js': {
            'html': ['vue.js', 'vue.min.js', 'vue@', '__VUE__'],
            'headers': [],
            'cookies': []
        },
        'Angular': {
            'html': ['ng-version', 'angular', 'ng-app', 'angular.min.js'],
            'headers': [],
            'cookies': []
        },
        'jQuery': {
            'html': ['jquery', 'jquery.min.js', 'jquery-'],
            'headers': [],
            'cookies': []
        },
        'Bootstrap': {
            'html': ['bootstrap', 'bootstrap.min.css', 'btn-bootstrap'],
            'headers': [],
            'cookies': []
        },
        'Laravel': {
            'html': ['laravel', 'csrf-token'],
            'headers': [],
            'cookies': ['laravel_session', 'XSRF-TOKEN']
        },
        'Django': {
            'html': ['csrfmiddlewaretoken', 'django'],
            'headers': [],
            'cookies': ['csrftoken', 'sessionid']
        },
        'Flask': {
            'html': [],
            'headers': [],
            'cookies': []
        },
        'Express.js': {
            'html': [],
            'headers': ['X-Powered-By: Express'],
            'cookies': []
        },
        'Next.js': {
            'html': ['__NEXT_DATA__', '_next/', 'next/dist'],
            'headers': ['x-nextjs-'],
            'cookies': []
        },
        'Nuxt.js': {
            'html': ['__NUXT__', '_nuxt/', 'nuxt-link'],
            'headers': [],
            'cookies': []
        },
        'ASP.NET': {
            'html': ['__VIEWSTATE', '__EVENTVALIDATION', 'asp.net'],
            'headers': ['X-AspNet-Version', 'X-Powered-By: ASP.NET'],
            'cookies': ['ASP.NET_SessionId', 'ASPSESSIONID']
        },
        'Ruby on Rails': {
            'html': ['rails', 'csrf-param'],
            'headers': ['X-Runtime', 'X-Rack-Cache'],
            'cookies': ['_session_id']
        },
        'Spring': {
            'html': [],
            'headers': [],
            'cookies': ['JSESSIONID']
        },
        'PHP': {
            'html': ['.php', 'phpsessid'],
            'headers': ['X-Powered-By: PHP'],
            'cookies': ['PHPSESSID']
        },
        'Node.js': {
            'html': [],
            'headers': ['X-Powered-By: Node'],
            'cookies': []
        },
        # Servers
        'Nginx': {
            'html': [],
            'headers': ['Server: nginx'],
            'cookies': []
        },
        'Apache': {
            'html': [],
            'headers': ['Server: Apache'],
            'cookies': []
        },
        'IIS': {
            'html': [],
            'headers': ['Server: Microsoft-IIS'],
            'cookies': []
        },
        'Tomcat': {
            'html': [],
            'headers': ['Server: Apache-Coyote'],
            'cookies': []
        },
        'LiteSpeed': {
            'html': [],
            'headers': ['Server: LiteSpeed'],
            'cookies': []
        },
        # Analytics & Tracking
        'Google Analytics': {
            'html': ['google-analytics.com', 'gtag.js', 'ga.js', '_gaq'],
            'headers': [],
            'cookies': ['_ga', '_gid', '_gat']
        },
        'Google Tag Manager': {
            'html': ['googletagmanager.com', 'gtm.js', 'GTM-'],
            'headers': [],
            'cookies': []
        },
        'Facebook Pixel': {
            'html': ['connect.facebook.net', 'fbq(', 'facebook.net/en_US/fbevents'],
            'headers': [],
            'cookies': ['_fbp']
        },
        'Hotjar': {
            'html': ['hotjar.com', 'hj.js'],
            'headers': [],
            'cookies': ['_hjid']
        },
        'Mixpanel': {
            'html': ['mixpanel.com', 'mpq.track'],
            'headers': [],
            'cookies': ['mp_']
        },
        # CDNs & Security
        'Cloudflare': {
            'html': ['cdnjs.cloudflare.com', 'cloudflare'],
            'headers': ['cf-ray', 'cf-cache-status', '__cfduid'],
            'cookies': ['__cfduid', 'cf_clearance']
        },
        'Akamai': {
            'html': [],
            'headers': ['X-Akamai-Transformed', 'Akamai-Origin-Hop'],
            'cookies': []
        },
        'Incapsula': {
            'html': ['incapsula'],
            'headers': ['X-Iinfo', 'X-CDN'],
            'cookies': ['incap_ses_', 'visid_incap_']
        },
        # Other
        'New Relic': {
            'html': ['newrelic.com', 'NREUM'],
            'headers': ['X-NewRelic-App-Data'],
            'cookies': []
        },
        'Sentry': {
            'html': ['sentry.io', 'sentry.min.js', 'Raven.config'],
            'headers': [],
            'cookies': []
        },
        'Stripe': {
            'html': ['stripe.com', 'js.stripe.com', 'Stripe('],
            'headers': [],
            'cookies': []
        },
        'PayPal': {
            'html': ['paypal.com', 'paypalobjects.com'],
            'headers': [],
            'cookies': []
        },
        'reCAPTCHA': {
            'html': ['recaptcha', 'google.com/recaptcha'],
            'headers': [],
            'cookies': []
        },
        'Intercom': {
            'html': ['intercom.com', 'intercomSettings'],
            'headers': [],
            'cookies': ['intercom-']
        },
        'Zendesk': {
            'html': ['zendesk.com', 'zdassets.com'],
            'headers': [],
            'cookies': []
        },
        'HubSpot': {
            'html': ['hubspot.com', 'hs-scripts.com', 'hbspt.'],
            'headers': [],
            'cookies': ['hubspotutk', '__hstc']
        },
        'Marketo': {
            'html': ['marketo.com', 'mktoResp'],
            'headers': [],
            'cookies': ['_mkto_trk']
        },
        'Salesforce': {
            'html': ['salesforce.com', 'force.com'],
            'headers': [],
            'cookies': []
        },
        'ServiceWorker': {
            'html': ['service-worker', 'navigator.serviceWorker'],
            'headers': [],
            'cookies': []
        },
        'PWA': {
            'html': ['manifest.json', 'apple-mobile-web-app-capable'],
            'headers': [],
            'cookies': []
        },
        'Webpack': {
            'html': ['webpack', 'webpackChunk', '__webpack'],
            'headers': [],
            'cookies': []
        },
        'TypeScript': {
            'html': [],
            'headers': [],
            'cookies': []
        },
        'Tailwind CSS': {
            'html': ['tailwindcss', 'tailwind.min.css'],
            'headers': [],
            'cookies': []
        },
        'Sass/SCSS': {
            'html': ['.scss', '.sass'],
            'headers': [],
            'cookies': []
        },
        'GraphQL': {
            'html': ['graphql', '/graphql'],
            'headers': [],
            'cookies': []
        },
        'REST API': {
            'html': ['/api/', '/api/v'],
            'headers': [],
            'cookies': []
        },
        'Swagger/OpenAPI': {
            'html': ['swagger', 'openapi', 'swagger-ui'],
            'headers': [],
            'cookies': []
        },
        'Docker': {
            'html': [],
            'headers': ['Server: Docker'],
            'cookies': []
        },
        'Kubernetes': {
            'html': [],
            'headers': ['kubernetes', 'K-'],
            'cookies': []
        },
    }
    
    @classmethod
    def detect(cls, html_content: str, headers: Dict, cookies: Dict) -> List[str]:
        """Detect technologies from HTML content, headers, and cookies"""
        detected = set()
        
        html_lower = html_content.lower()
        header_lower = {k.lower(): v.lower() for k, v in headers.items()}
        cookie_lower = {k.lower(): v.lower() for k, v in cookies.items()}
        
        for tech, signatures in cls.TECH_SIGNATURES.items():
            # Check HTML signatures
            for pattern in signatures.get('html', []):
                if pattern.lower() in html_lower:
                    detected.add(tech)
                    break
            
            if tech in detected:
                continue
            
            # Check header signatures
            for pattern in signatures.get('headers', []):
                pattern_lower = pattern.lower()
                for header_name, header_value in header_lower.items():
                    if pattern_lower in header_name or pattern_lower in header_value:
                        detected.add(tech)
                        break
                if tech in detected:
                    break
            
            if tech in detected:
                continue
            
            # Check cookie signatures
            for pattern in signatures.get('cookies', []):
                pattern_lower = pattern.lower()
                for cookie_name in cookie_lower.keys():
                    if pattern_lower in cookie_name:
                        detected.add(tech)
                        break
                if tech in detected:
                    break
        
        return sorted(list(detected))


# ═══════════════════════════════════════════════════════════════════════════
# WAF DETECTION ENGINE
# ═══════════════════════════════════════════════════════════════════════════

class WAFDetector:
    """
    Advanced WAF detection based on fingerprinting
    """
    
    WAF_SIGNATURES = {
        'Cloudflare': {
            'headers': ['cf-ray', 'cf-cache-status', '__cfduid', 'cf-worker'],
            'cookies': ['__cfduid', '__cflb', 'cf_clearance'],
            'text': ['cloudflare', 'attention required', 'checking your browser', 'cf-browser-redirect']
        },
        'Akamai': {
            'headers': ['akamai-origin-hop', 'akamai-x-cache', 'akamai-cache-status', 'x-akamai-transformed'],
            'text': ['reference #', 'akamai', 'access denied']
        },
        'AWS WAF': {
            'headers': ['x-amzn-requestid', 'x-amz-cf-id', 'x-amzn-waf'],
            'text': ['aws', 'forbidden', 'request blocked']
        },
        'Incapsula': {
            'headers': ['x-iinfo', 'x-cdn', 'x-javascript'],
            'cookies': ['incap_ses', 'visid_incap', 'nlbi_'],
            'text': ['incapsula', 'incap_ses', 'you have been blocked']
        },
        'ModSecurity': {
            'headers': ['mod_security', 'modsecurity'],
            'text': ['mod_security', 'this error was generated by mod_security', 'modsecurity-unique-id']
        },
        'Sucuri': {
            'headers': ['x-sucuri-id', 'x-sucuri-cache', 'x-sucuri-via'],
            'text': ['sucuri', 'cloudproxy', 'access denied - sucuri']
        },
        'Imperva': {
            'headers': ['x-cdn', 'x-iinfo'],
            'cookies': ['incap_ses', 'visid_incap'],
            'text': ['imperva', 'incapsula']
        },
        'F5 BIG-IP ASM': {
            'headers': ['x-waf-event', 'x-waf-rule-id'],
            'text': ['f5', 'big-ip', 'asm']
        },
        'Fortinet FortiWeb': {
            'headers': ['fortinet', 'fortiweb'],
            'text': ['fortinet', 'fortiweb', 'fgd_icon']
        },
        'Barracuda': {
            'headers': ['barracuda', 'barra'],
            'cookies': ['barra_counter_session', 'BARRACUDA'],
            'text': ['barracuda', 'bni-waf']
        },
        'Citrix NetScaler': {
            'headers': ['ns_af', 'citrix', 'netscaler'],
            'cookies': ['ns-waf', 'citrix_ns_id'],
            'text': ['citrix', 'netscaler']
        },
        'Radware': {
            'text': ['radware', 'appwall']
        },
        'Trustwave': {
            'text': ['trustwave', 'mod_security']
        },
        'DenyAll': {
            'headers': ['denyall'],
            'text': ['denyall', 'rweb']
        },
        'DotDefender': {
            'text': ['dotdefender']
        },
        'IBM DataPower': {
            'headers': ['x-ibm', 'datapower'],
            'text': ['datapower', 'ibm']
        },
        'Juniper': {
            'headers': ['juniper', 'srx'],
            'text': ['juniper', 'srx']
        },
        'Palo Alto': {
            'headers': ['paloalto', 'pan'],
            'text': ['palo alto', 'pan-firewall']
        },
        'Sophos': {
            'headers': ['sophos'],
            'text': ['sophos', 'sophos web appliance']
        },
        'Stingray': {
            'headers': ['stingray'],
            'text': ['stingray']
        },
        'Teros': {
            'headers': ['teros'],
            'text': ['teros']
        },
        'WebKnight': {
            'text': ['webknight', 'aqtronix']
        },
        'Wordfence': {
            'text': ['wordfence', 'wfvt_'],
            'cookies': ['wfvt_']
        },
        'Reblaze': {
            'headers': ['reblaze'],
            'text': ['reblaze']
        },
        'Naxsi': {
            'headers': ['naxsi'],
            'text': ['naxsi', 'naxsi_blocked']
        },
        'Shadowd': {
            'text': ['shadowd']
        },
        'Wallarm': {
            'headers': ['wallarm'],
            'text': ['wallarm', 'wallarm-block']
        },
        'Malcare': {
            'text': ['malcare', 'bmn-']
        },
        'Shield Security': {
            'text': ['shield', 'shield-security']
        },
        'All In One Security': {
            'text': ['all-in-one-security', 'aiowps']
        },
        'BulletProof Security': {
            'text': ['bulletproof', 'bps']
        },
        'Quttera': {
            'text': ['quttera']
        },
        'SiteGuard': {
            'text': ['siteguard']
        },
        'WebARX': {
            'text': ['webarx']
        },
        'Astra': {
            'text': ['astra', 'astra-security']
        },
        'Comodo': {
            'headers': ['comodo'],
            'text': ['comodo', 'cwatch']
        },
        'StackPath': {
            'headers': ['stackpath', 'x-sp'],
            'text': ['stackpath']
        },
        'CDN77': {
            'headers': ['cdn77', 'x-cdn77'],
            'text': ['cdn77']
        },
        'KeyCDN': {
            'headers': ['keycdn', 'x-keycdn'],
            'text': ['keycdn']
        },
        'CacheFly': {
            'headers': ['cachefly'],
            'text': ['cachefly']
        },
        'Fastly': {
            'headers': ['fastly', 'x-served-by', 'x-cache'],
            'text': ['fastly']
        },
        'Section.io': {
            'headers': ['section.io', 'x-section'],
            'text': ['section.io']
        },
        'QUIC.cloud': {
            'headers': ['quic.cloud', 'x-qc'],
            'text': ['quic.cloud']
        },
        'WP Engine': {
            'headers': ['wp engine', 'wpe'],
            'text': ['wp engine']
        },
        'Kinsta': {
            'headers': ['kinsta', 'x-kinsta'],
            'text': ['kinsta']
        },
        'Pagely': {
            'headers': ['pagely'],
            'text': ['pagely']
        },
        'Pressidium': {
            'headers': ['pressidium'],
            'text': ['pressidium']
        },
        'Pressable': {
            'headers': ['pressable'],
            'text': ['pressable']
        },
        'Flywheel': {
            'headers': ['flywheel'],
            'text': ['flywheel']
        },
        'Cloudways': {
            'headers': ['cloudways'],
            'text': ['cloudways']
        },
        'SiteGround': {
            'headers': ['siteground'],
            'text': ['siteground']
        },
        'Bluehost': {
            'headers': ['bluehost'],
            'text': ['bluehost']
        },
        'HostGator': {
            'headers': ['hostgator'],
            'text': ['hostgator']
        },
        'InMotion': {
            'headers': ['inmotion'],
            'text': ['inmotion']
        },
        'A2 Hosting': {
            'headers': ['a2 hosting'],
            'text': ['a2 hosting']
        },
        'DreamHost': {
            'headers': ['dreamhost'],
            'text': ['dreamhost']
        },
        'GoDaddy': {
            'headers': ['godaddy', 'x-gd'],
            'text': ['godaddy']
        },
        'Namecheap': {
            'headers': ['namecheap'],
            'text': ['namecheap']
        },
        'Liquid Web': {
            'headers': ['liquid web'],
            'text': ['liquid web']
        },
    }
    
    @classmethod
    async def detect(cls, url: str) -> Optional[str]:
        """Detect WAF for a URL"""
        try:
            async with aiohttp.ClientSession() as session:
                # Normal request
                async with session.get(url, timeout=15, ssl=False) as response:
                    headers = dict(response.headers)
                    content = await response.text()
                    cookies = {k: v.value for k, v in response.cookies.items()}
                    
                    # Check signatures
                    for waf_name, signatures in cls.WAF_SIGNATURES.items():
                        # Check headers
                        for header_pattern in signatures.get('headers', []):
                            for header_name, header_value in headers.items():
                                if header_pattern.lower() in header_name.lower() or header_pattern.lower() in header_value.lower():
                                    return waf_name
                        
                        # Check cookies
                        for cookie_pattern in signatures.get('cookies', []):
                            for cookie_name in cookies.keys():
                                if cookie_pattern.lower() in cookie_name.lower():
                                    return waf_name
                        
                        # Check content
                        for text_pattern in signatures.get('text', []):
                            if text_pattern.lower() in content.lower():
                                return waf_name
        
        except Exception as e:
            logger.debug(f"WAF detection error for {url}: {e}")
        
        return None


# ═══════════════════════════════════════════════════════════════════════════
# HTTP PROBE
# ═══════════════════════════════════════════════════════════════════════════

class HTTPProbe:
    """
    Fast HTTP probing with technology detection
    """
    
    def __init__(self, timeout: int = 15):
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15'
        ]
    
    async def probe(self, subdomain: str, real_ip: Optional[str] = None) -> Dict:
        """Probe subdomain for HTTP services"""
        result = {
            'subdomain': subdomain,
            'accessible': False,
            'protocol': None,
            'status_code': None,
            'title': '',
            'server': '',
            'headers': {},
            'redirect': None,
            'technologies': [],
            'content_length': 0,
            'response_time': 0,
            'content': '',
            'js_files': [],
            'emails': []
        }
        
        for protocol in ['https', 'http']:
            try:
                url = f"{protocol}://{real_ip or subdomain}"
                headers = {
                    'User-Agent': random.choice(self.user_agents),
                    'Host': subdomain,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                }
                
                start_time = datetime.now()
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        headers=headers,
                        timeout=self.timeout,
                        ssl=False,
                        allow_redirects=True
                    ) as response:
                        response_time = (datetime.now() - start_time).total_seconds()
                        
                        result['accessible'] = True
                        result['protocol'] = protocol
                        result['status_code'] = response.status
                        result['headers'] = dict(response.headers)
                        result['server'] = response.headers.get('Server', 'Unknown')
                        result['response_time'] = response_time
                        
                        # Handle redirects
                        if response.history:
                            result['redirect'] = str(response.url)
                        
                        # Extract content
                        try:
                            content = await response.text()
                            result['content'] = content
                            result['content_length'] = len(content)
                            
                            # Extract title
                            match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
                            if match:
                                result['title'] = match.group(1).strip()[:200]
                            
                            # Detect technologies
                            cookies = {k: v.value for k, v in response.cookies.items()}
                            result['technologies'] = TechnologyDetector.detect(
                                content,
                                result['headers'],
                                cookies
                            )
                            
                            # Extract JS files
                            result['js_files'] = await JavaScriptAnalyzer.extract_js_files(content, url)
                            
                            # Extract emails
                            emails = set()
                            for pattern in EmailEnumerator.EMAIL_PATTERNS:
                                matches = re.findall(pattern, content)
                                for email in matches:
                                    if not any(x in email.lower() for x in ['example.com', 'domain.com', 'email.com']):
                                        emails.add(email.lower())
                            result['emails'] = list(emails)
                            
                        except:
                            pass
                        
                        return result
            
            except asyncio.TimeoutError:
                logger.debug(f"Timeout probing {subdomain} with {protocol}")
            except Exception as e:
                logger.debug(f"Error probing {subdomain}: {e}")
        
        return result


# ═══════════════════════════════════════════════════════════════════════════
# SSL/TLS CERTIFICATE ANALYZER
# ═══════════════════════════════════════════════════════════════════════════

class SSLAnalyzer:
    """
    SSL/TLS certificate analysis and validation
    """
    
    @staticmethod
    async def analyze(domain: str, timeout: int = 10) -> Dict:
        """Analyze SSL certificate"""
        result = {
            'valid': False,
            'issuer': '',
            'subject': '',
            'sans': [],
            'not_before': '',
            'not_after': '',
            'expired': False,
            'self_signed': False,
            'version': '',
            'serial_number': '',
            'signature_algorithm': '',
            'key_size': 0,
            'grade': 'Unknown'
        }
        
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((domain, 443), timeout=timeout) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert_bin = ssock.getpeercert(binary_form=True)
                    cert = OpenSSL.crypto.load_certificate(
                        OpenSSL.crypto.FILETYPE_ASN1,
                        cert_bin
                    )
                    
                    result['valid'] = True
                    result['issuer'] = cert.get_issuer().CN
                    result['subject'] = cert.get_subject().CN
                    result['not_before'] = cert.get_notBefore().decode('utf-8')
                    result['not_after'] = cert.get_notAfter().decode('utf-8')
                    result['version'] = cert.get_version()
                    result['serial_number'] = cert.get_serial_number()
                    result['signature_algorithm'] = cert.get_signature_algorithm().decode('utf-8')
                    
                    # Get public key size
                    pubkey = cert.get_pubkey()
                    result['key_size'] = pubkey.bits()
                    
                    # Extract SANs
                    for i in range(cert.get_extension_count()):
                        ext = cert.get_extension(i)
                        if 'subjectAltName' in str(ext.get_short_name()):
                            sans_str = str(ext)
                            result['sans'] = [
                                san.strip().replace('DNS:', '')
                                for san in sans_str.split(',')
                            ]
                    
                    # Check if self-signed
                    if cert.get_issuer() == cert.get_subject():
                        result['self_signed'] = True
                    
                    # Check expiration
                    result['expired'] = cert.has_expired()
                    
                    # Calculate grade
                    grade = 'A'
                    if result['expired']:
                        grade = 'F'
                    elif result['self_signed']:
                        grade = 'C'
                    elif result['key_size'] < 2048:
                        grade = 'B'
                    
                    result['grade'] = grade
        
        except Exception as e:
            logger.debug(f"SSL analysis error for {domain}: {e}")
        
        return result


# ═══════════════════════════════════════════════════════════════════════════
# PORT SCANNER
# ═══════════════════════════════════════════════════════════════════════════

class PortScanner:
    """
    Fast port scanner with service detection
    """
    
    COMMON_PORTS = {
        21: 'FTP',
        22: 'SSH',
        23: 'Telnet',
        25: 'SMTP',
        53: 'DNS',
        80: 'HTTP',
        110: 'POP3',
        143: 'IMAP',
        443: 'HTTPS',
        445: 'SMB',
        465: 'SMTPS',
        587: 'SMTP',
        993: 'IMAPS',
        995: 'POP3S',
        1433: 'MSSQL',
        1521: 'Oracle',
        3306: 'MySQL',
        3389: 'RDP',
        5432: 'PostgreSQL',
        5900: 'VNC',
        5901: 'VNC',
        6379: 'Redis',
        8080: 'HTTP-Proxy',
        8443: 'HTTPS-Alt',
        8888: 'HTTP-Alt',
        9000: 'PHP-FPM',
        9200: 'Elasticsearch',
        27017: 'MongoDB',
        27018: 'MongoDB',
        27019: 'MongoDB',
        5000: 'Flask',
        8000: 'HTTP-Alt',
        3000: 'Node.js',
        4000: 'Node.js',
        5001: 'Flask',
        5601: 'Kibana',
        9090: 'Prometheus',
        9093: 'Alertmanager',
        8081: 'HTTP-Alt',
        8291: 'Winbox',
        11211: 'Memcached',
        5672: 'RabbitMQ',
        15672: 'RabbitMQ Management',
        6443: 'Kubernetes API',
        10250: 'Kubelet',
        2379: 'etcd',
        2380: 'etcd',
        8500: 'Consul',
        8600: 'Consul DNS',
        9418: 'Git',
        2049: 'NFS',
        139: 'NetBIOS',
        514: 'Syslog',
        161: 'SNMP',
        162: 'SNMP Trap',
        1812: 'RADIUS',
        1813: 'RADIUS Accounting',
        5222: 'XMPP',
        5269: 'XMPP Server',
        5280: 'XMPP BOSH',
        4190: 'ManageSieve',
        2003: 'Graphite',
        2004: 'Graphite',
        7000: 'Cassandra',
        7001: 'Cassandra SSL',
        9042: 'Cassandra CQL',
        9160: 'Cassandra Thrift',
    }
    
    @staticmethod
    async def scan_port(ip: str, port: int, timeout: float = 2) -> bool:
        """Scan a single port"""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port),
                timeout=timeout
            )
            writer.close()
            await writer.wait_closed()
            return True
        except:
            return False
    
    @classmethod
    async def scan(cls, ip: str, ports: List[int] = None, timeout: float = 2) -> List[Dict]:
        """Scan multiple ports"""
        if ports is None:
            ports = list(cls.COMMON_PORTS.keys())
        
        tasks = [cls.scan_port(ip, port, timeout) for port in ports]
        results = await asyncio.gather(*tasks)
        
        open_ports = []
        for port, is_open in zip(ports, results):
            if is_open:
                open_ports.append({
                    'port': port,
                    'service': cls.COMMON_PORTS.get(port, 'Unknown')
                })
        
        return open_ports


# ═══════════════════════════════════════════════════════════════════════════
# SECURITY HEADERS ANALYZER
# ═══════════════════════════════════════════════════════════════════════════

class SecurityHeadersAnalyzer:
    """
    Analyze security headers
    """
    
    SECURITY_HEADERS = {
        'Strict-Transport-Security': {
            'description': 'HTTP Strict Transport Security',
            'severity': 'medium',
            'recommended': 'max-age=31536000; includeSubDomains'
        },
        'Content-Security-Policy': {
            'description': 'Content Security Policy',
            'severity': 'medium',
            'recommended': "default-src 'self'"
        },
        'X-Frame-Options': {
            'description': 'Clickjacking Protection',
            'severity': 'medium',
            'recommended': 'DENY or SAMEORIGIN'
        },
        'X-Content-Type-Options': {
            'description': 'MIME Type Sniffing Protection',
            'severity': 'low',
            'recommended': 'nosniff'
        },
        'X-XSS-Protection': {
            'description': 'XSS Protection (deprecated but still used)',
            'severity': 'low',
            'recommended': '1; mode=block'
        },
        'Referrer-Policy': {
            'description': 'Referrer Policy',
            'severity': 'low',
            'recommended': 'strict-origin-when-cross-origin'
        },
        'Permissions-Policy': {
            'description': 'Permissions Policy (formerly Feature-Policy)',
            'severity': 'low',
            'recommended': 'geolocation=(), microphone=(), camera=()'
        },
        'Cross-Origin-Opener-Policy': {
            'description': 'Cross-Origin Opener Policy',
            'severity': 'low',
            'recommended': 'same-origin'
        },
        'Cross-Origin-Resource-Policy': {
            'description': 'Cross-Origin Resource Policy',
            'severity': 'low',
            'recommended': 'same-origin'
        },
        'Cross-Origin-Embedder-Policy': {
            'description': 'Cross-Origin Embedder Policy',
            'severity': 'low',
            'recommended': 'require-corp'
        }
    }
    
    @classmethod
    def analyze(cls, headers: Dict) -> Dict:
        """Analyze security headers"""
        result = {
            'present': {},
            'missing': {},
            'score': 0
        }
        
        header_keys = [k.lower() for k in headers.keys()]
        
        for header, info in cls.SECURITY_HEADERS.items():
            if header.lower() in header_keys:
                result['present'][header] = {
                    'value': headers.get(header, headers.get(header.lower(), '')),
                    'description': info['description'],
                    'recommended': info['recommended']
                }
            else:
                result['missing'][header] = {
                    'description': info['description'],
                    'severity': info['severity'],
                    'recommended': info['recommended']
                }
        
        # Calculate score
        total = len(cls.SECURITY_HEADERS)
        present = len(result['present'])
        result['score'] = int((present / total) * 100)
        
        return result


# ═══════════════════════════════════════════════════════════════════════════
# MAIN RECONNAISSANCE SCANNER
# ═══════════════════════════════════════════════════════════════════════════

class UltimateReconScanner:
    """
    Ultimate reconnaissance scanner
    Integrates all intelligence modules
    """
    
    def __init__(self, gui=None, scan_level: ScanLevel = ScanLevel.NORMAL, config: Config = None, domain: str = None):
        self.gui = gui
        self.scan_level = scan_level
        self.config = config or Config()
        self.results = {
            'domain': '',
            'scan_time': '',
            'scan_level': scan_level.value,
            'subdomains': {},
            'summary': {
                'total_subdomains': 0,
                'alive_services': 0,
                'unique_ips': 0,
                'cdn_count': 0,
                'real_ips': 0,
                'technologies': set(),
                'wafs_detected': set(),
                'takeover_vulnerable': 0,
                'secrets_found': 0,
                'cloud_buckets': 0,
                'security_score': 0
            }
        }
        
        self.dns_resolver = AdvancedDNSResolver()
        self.http_probe = HTTPProbe()
        self.stop_flag = False
        
        # Watch Tower: History file for this domain
        if domain:
            safe_domain = domain.replace('.', '_')
            self.history_file = f"watchtower_history_{safe_domain}.json"
        else:
            self.history_file = None
    
    def log(self, message: str, level: str = 'info'):
        """Log message to GUI and logger"""
        if self.gui:
            self.gui.log(message)
        
        if level == 'info':
            logger.info(message)
        elif level == 'warning':
            logger.warning(message)
        elif level == 'error':
            logger.error(message)
    
    async def enumerate_subdomains(self, domain: str, custom_wordlist: List[str] = None) -> Set[str]:
        """Comprehensive subdomain enumeration"""
        all_subdomains = set()
        
        # Phase 1: Passive Reconnaissance
        self.log("🔍 [Phase 1/5] Running passive reconnaissance (30+ sources)...")
        passive_engine = UltimatePassiveReconEngine(domain, self.config)
        passive_subs = await passive_engine.run_all()
        all_subdomains.update(passive_subs)
        self.log(f"✓ Passive recon completed: {len(passive_subs)} subdomains found")
        
        # Phase 2: DNS Bruteforce
        if self.scan_level not in [ScanLevel.PASSIVE]:
            self.log("🔨 [Phase 2/5] Running DNS bruteforce...")
            bruteforcer = DNSBruteForcer(domain, self.dns_resolver, custom_wordlist)
            brute_subs = await bruteforcer.bruteforce()
            all_subdomains.update(brute_subs)
            self.log(f"✓ DNS bruteforce completed: {len(brute_subs)} new subdomains found")
            
            # Phase 3: Permutation generation
            if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE]:
                self.log("🧬 [Phase 3/5] Generating permutations...")
                permutations = bruteforcer.generate_permutations(all_subdomains)
                self.log(f"Generated {len(permutations)} permutations, testing...")
                
                # Test permutations
                valid_perms = set()
                for perm in list(permutations)[:500]:  # Limit permutations
                    if self.stop_flag:
                        break
                    ips = await self.dns_resolver.resolve(perm)
                    if ips:
                        valid_perms.add(perm)
                
                all_subdomains.update(valid_perms)
                self.log(f"✓ Permutation testing completed: {len(valid_perms)} valid permutations")
        
        return all_subdomains
    
    async def analyze_subdomain(self, subdomain: str, session: aiohttp.ClientSession) -> SubdomainInfo:
        """Complete analysis of a single subdomain"""
        info = SubdomainInfo(domain=subdomain)
        
        try:
            # DNS Resolution
            dns_records = await self.dns_resolver.resolve_all(subdomain)
            info.ips = dns_records.get('A', []) + dns_records.get('AAAA', [])
            info.cnames = dns_records.get('CNAME', [])
            info.mx_records = dns_records.get('MX', [])
            info.txt_records = dns_records.get('TXT', [])
            info.ns_records = dns_records.get('NS', [])
            
            if not info.ips:
                return info
            
            # CDN Detection
            for ip in info.ips:
                is_cdn, provider = IPIntelligence.detect_cdn(ip)
                if is_cdn:
                    info.cdn = provider
                    break
            
            # HTTP Probing
            if self.scan_level not in [ScanLevel.PASSIVE]:
                real_ip = None if info.cdn else (info.ips[0] if info.ips else None)
                http_result = await self.http_probe.probe(subdomain, real_ip)
                
                if http_result['accessible']:
                    info.status_code = http_result['status_code']
                    info.title = http_result['title']
                    info.server = http_result['server']
                    info.technologies = http_result['technologies']
                    info.headers = http_result['headers']
                    info.js_files = http_result['js_files']
                    info.emails = http_result['emails']
                    info.content_length = http_result['content_length']
                    info.response_time = http_result['response_time']
                    info.redirect_url = http_result['redirect']
                    
                    # Security Headers Analysis
                    info.security_headers = SecurityHeadersAnalyzer.analyze(info.headers)
                    
                    # WAF Detection
                    if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE]:
                        url = f"{http_result['protocol']}://{subdomain}"
                        info.waf = await WAFDetector.detect(url)
                    
                    # Subdomain Takeover Detection
                    is_vulnerable, takeover_type = await SubdomainTakeoverDetector.check_takeover(
                        subdomain, info.cnames, http_result['content']
                    )
                    info.takeover_vulnerable = is_vulnerable
                    info.takeover_type = takeover_type
                    
                    # JavaScript Analysis
                    if self.scan_level == ScanLevel.ULTIMATE and info.js_files:
                        self.log(f"  📜 Analyzing {len(info.js_files)} JS files for {subdomain}...")
                        for js_url in info.js_files[:10]:  # Limit to first 10 JS files
                            js_result = await JavaScriptAnalyzer.analyze_js_file(js_url, session)
                            if js_result['secrets']:
                                info.js_secrets.extend(js_result['secrets'])
                            if js_result['endpoints']:
                                info.api_endpoints.extend(js_result['endpoints'])
                    
                    # Cloud Bucket Detection
                    if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE]:
                        buckets = await CloudBucketDetector.detect_buckets(
                            subdomain, http_result['content'], session
                        )
                        info.cloud_buckets = buckets
            
            # Port Scanning (aggressive mode only)
            if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE] and info.ips and not info.cdn:
                port_results = await PortScanner.scan(info.ips[0])
                info.open_ports = port_results
            
            # SSL Analysis
            if 443 in [p['port'] for p in info.open_ports] or info.status_code:
                try:
                    info.ssl_info = await SSLAnalyzer.analyze(subdomain)
                except:
                    pass
        
        except Exception as e:
            logger.debug(f"Error analyzing {subdomain}: {e}")
        
        return info
    
    async def run(self, domain: str, custom_wordlist: List[str] = None):
        """Execute complete reconnaissance scan"""
        start_time = datetime.now()
        self.results['domain'] = domain
        
        self.log(f"🚀 Starting ULTIMATE reconnaissance scan for {domain}")
        self.log(f"⚙️  Scan Level: {self.scan_level.value.upper()}")
        self.log("=" * 70)
        
        # Enumerate all subdomains
        all_subdomains = await self.enumerate_subdomains(domain, custom_wordlist)
        self.results['summary']['total_subdomains'] = len(all_subdomains)
        
        self.log(f"\n📊 Total subdomains discovered: {len(all_subdomains)}")
        self.log("=" * 70)
        
        # Analyze each subdomain
        self.log("\n🔬 [Phase 4/5] Analyzing subdomains...")
        
        async with aiohttp.ClientSession() as session:
            # Process in batches
            batch_size = 30
            subdomain_list = sorted(list(all_subdomains))
            
            for i in range(0, len(subdomain_list), batch_size):
                if self.stop_flag:
                    break
                
                batch = subdomain_list[i:i + batch_size]
                self.log(f"Analyzing batch {i//batch_size + 1}/{(len(subdomain_list)-1)//batch_size + 1}...")
                
                tasks = [self.analyze_subdomain(sub, session) for sub in batch]
                results = await asyncio.gather(*tasks)
                
                for sub_info in results:
                    self.results['subdomains'][sub_info.domain] = asdict(sub_info)
                    
                    # Update summary
                    if sub_info.status_code:
                        self.results['summary']['alive_services'] += 1
                    
                    if sub_info.cdn:
                        self.results['summary']['cdn_count'] += 1
                        self.results['summary']['wafs_detected'].add(sub_info.cdn)
                    else:
                        self.results['summary']['real_ips'] += len(sub_info.ips)
                    
                    if sub_info.technologies:
                        self.results['summary']['technologies'].update(sub_info.technologies)
                    
                    if sub_info.waf:
                        self.results['summary']['wafs_detected'].add(sub_info.waf)
                    
                    if sub_info.takeover_vulnerable:
                        self.results['summary']['takeover_vulnerable'] += 1
                    
                    if sub_info.js_secrets:
                        self.results['summary']['secrets_found'] += len(sub_info.js_secrets)
                    
                    if sub_info.cloud_buckets:
                        self.results['summary']['cloud_buckets'] += len(sub_info.cloud_buckets)
        
        # Calculate unique IPs
        all_ips = set()
        for sub_info in self.results['subdomains'].values():
            all_ips.update(sub_info.get('ips', []))
        self.results['summary']['unique_ips'] = len(all_ips)
        
        # Convert sets to lists for JSON serialization
        self.results['summary']['technologies'] = sorted(list(self.results['summary']['technologies']))
        self.results['summary']['wafs_detected'] = sorted(list(self.results['summary']['wafs_detected']))
        
        # Calculate scan time
        scan_duration = datetime.now() - start_time
        self.results['scan_time'] = str(scan_duration)
        
        self.log("\n" + "=" * 70)
        self.log("✅ Scan completed successfully!")
        self.log(f"⏱️  Total time: {scan_duration}")
        self.log(f"📈 Summary:")
        self.log(f"   • Total Subdomains: {self.results['summary']['total_subdomains']}")
        self.log(f"   • Live Services: {self.results['summary']['alive_services']}")
        self.log(f"   • Unique IPs: {self.results['summary']['unique_ips']}")
        self.log(f"   • CDN Protected: {self.results['summary']['cdn_count']}")
        self.log(f"   • Technologies: {len(self.results['summary']['technologies'])}")
        self.log(f"   • Takeover Vulnerable: {self.results['summary']['takeover_vulnerable']}")
        self.log(f"   • Secrets Found: {self.results['summary']['secrets_found']}")
        self.log(f"   • Cloud Buckets: {self.results['summary']['cloud_buckets']}")
        self.log("=" * 70)
        
        return self.results
    
    def stop(self):
        """Stop the scan"""
        self.stop_flag = True
        self.log("⏹️ Scan stop requested...")

    # ═══════════════════════════════════════════════════════════════════════════
    # WATCH TOWER: HISTORY & CHANGE DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def load_previous_results(self) -> Optional[Dict]:
        """Load previous scan results from history file"""
        if self.history_file and os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                self.log(f"Error loading history: {e}")
        return None
    
    def save_current_results(self, results: Dict):
        """Save current scan results to history file"""
        if self.history_file:
            results['last_scan'] = datetime.now().isoformat()
            try:
                os.makedirs(self.config.OUTPUT_DIR, exist_ok=True)
                filepath = os.path.join(self.config.OUTPUT_DIR, os.path.basename(self.history_file))
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(results, f, indent=2, default=str)
                self.log(f"Results saved to {filepath}")
            except Exception as e:
                self.log(f"Error saving results: {e}")
    
    def detect_changes(self, old_results: Dict, new_results: Dict) -> List[str]:
        """Detect changes between old and new scan results (Diff Engine)"""
        alerts = []
        
        # Get subdomain sets
        old_subdomains = set(old_results.get('subdomains', {}).keys())
        new_subdomains = set(new_results.get('subdomains', {}).keys())
        
        # NEW SUBDOMAINS
        added_subs = new_subdomains - old_subdomains
        for sub in added_subs:
            alerts.append(f"NEW SUBDOMAIN → {sub}")
        
        # REMOVED SUBDOMAINS
        removed_subs = old_subdomains - new_subdomains
        for sub in removed_subs:
            alerts.append(f"REMOVED SUBDOMAIN → {sub}")
        
        # NEW TAKEOVER VULNERABILITIES
        for sub, info in new_results.get('subdomains', {}).items():
            old_info = old_results.get('subdomains', {}).get(sub, {})
            if info.get('takeover_vulnerable') and not old_info.get('takeover_vulnerable'):
                alerts.append(f"TAKEOVER VULNERABLE → {sub} ({info.get('takeover_type')})")
        
        # NEW SECRETS FOUND
        old_secrets = sum(len(info.get('js_secrets', [])) for info in old_results.get('subdomains', {}).values())
        new_secrets = new_results['summary'].get('secrets_found', 0)
        if new_secrets > old_secrets:
            alerts.append(f"NEW SECRETS → +{new_secrets - old_secrets} found")
        
        # NEW CLOUD BUCKETS
        old_buckets = old_results['summary'].get('cloud_buckets', 0)
        new_buckets = new_results['summary'].get('cloud_buckets', 0)
        if new_buckets > old_buckets:
            alerts.append(f"NEW CLOUD BUCKETS → +{new_buckets - old_buckets} found")
        
        # NEW OPEN PORTS
        for sub, info in new_results.get('subdomains', {}).items():
            old_ports = {f"{p['port']}/{p['service']}" for p in old_results.get('subdomains', {}).get(sub, {}).get('open_ports', [])}
            new_ports = {f"{p['port']}/{p['service']}" for p in info.get('open_ports', [])}
            added_ports = new_ports - old_ports
            if added_ports:
                alerts.append(f"NEW OPEN PORTS → {sub}: {', '.join(added_ports)}")
        
        # CHANGED HTTP STATUS
        for sub in new_subdomains & old_subdomains:
            old_code = old_results['subdomains'].get(sub, {}).get('status_code')
            new_code = new_results['subdomains'].get(sub, {}).get('status_code')
            if old_code != new_code:
                alerts.append(f"STATUS CHANGE → {sub}: {old_code} → {new_code}")
        
        return alerts



# ═══════════════════════════════════════════════════════════════════════════
# GUI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════

class ReconHunterUltimateGUI:
    """
    Ultimate GUI for Recon Hunter Pro
    """
    
    def __init__(self, root):
        self.root = root
        self.root.title("🎯 Recon Hunter Pro - ULTIMATE Edition v4.0")
        self.root.geometry("1500x950")
        self.root.configure(bg="#0a0e27")
        
        self.scanner = None
        self.results = None
        self.config = Config()
        
        self._setup_styles()
        self._create_widgets()
        self._create_menu()
    
    def _setup_styles(self):
        """Setup custom styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Title style
        style.configure(
            "Title.TLabel",
            font=("JetBrains Mono", 18, "bold"),
            foreground="#00d4ff",
            background="#0a0e27"
        )
        
        # Subtitle style
        style.configure(
            "Subtitle.TLabel",
            font=("JetBrains Mono", 10),
            foreground="#7c8db5",
            background="#0a0e27"
        )
        
        # Labels
        style.configure(
            "TLabel",
            font=("Segoe UI", 10),
            foreground="#e1e8f0",
            background="#0a0e27"
        )
        
        # Entry fields
        style.configure(
            "TEntry",
            fieldbackground="#1a1e3a",
            foreground="#e1e8f0",
            bordercolor="#2a2e4a",
            font=("Consolas", 10)
        )
        
        # Buttons
        style.configure(
            "TButton",
            font=("Segoe UI", 10, "bold"),
            background="#0066ff",
            foreground="white",
            borderwidth=0,
            focuscolor="none"
        )
        style.map("TButton",
                  background=[('active', '#0052cc'), ('disabled', '#1a1e3a')],
                  foreground=[('disabled', '#5a5e7a')])
        
        # Radiobuttons
        style.configure(
            "TRadiobutton",
            font=("Segoe UI", 9),
            background="#0a0e27",
            foreground="#e1e8f0"
        )
    
    def _create_menu(self):
        """Create menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Save Results (JSON)", command=lambda: self.save_results('json'))
        file_menu.add_command(label="Save Results (CSV)", command=lambda: self.save_results('csv'))


# ═══════════════════════════════════════════════════════════════════════════
# WATCH TOWER MODE: CONTINUOUS MONITORING
# ═══════════════════════════════════════════════════════════════════════════

async def watch_tower_mode(domain: str, interval_hours: float = 6.0, scan_level = ScanLevel.NORMAL, config = None, gui = None):
    """
    Watch Tower Mode: Continuous scanning with change detection and alerting
    
    Args:
        domain: Target domain to monitor
        interval_hours: Hours between scans (default: 6)
        scan_level: Scan intensity level
        config: Configuration object
        gui: GUI instance for logging
    """
    print(f"\n{'='*70}")
    print(f"  🏰 WATCH TOWER ACTIVATED")
    print(f"{'='*70}")
    print(f"  📡 Target: {domain}")
    print(f"  ⏱️  Interval: Every {interval_hours} hours")
    print(f"  ⚡ Scan Level: {scan_level.value if hasattr(scan_level, 'value') else scan_level}")
    print(f"{'='*70}\n")
    
    scanner = UltimateReconScanner(gui=gui, scan_level=scan_level, config=config, domain=domain)
    scan_count = 0
    
    while True:
        try:
            scan_count += 1
            print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Starting scan #{scan_count}...")
            
            if gui:
                gui.log(f"🏰 Watch Tower: Starting scan #{scan_count}...")
            
            # Run the scan
            new_results = await scanner.run(domain)
            
            # Load previous results
            previous_results = scanner.load_previous_results()
            
            if previous_results:
                # Detect changes
                changes = scanner.detect_changes(previous_results, new_results)
                
                if changes:
                    print("\n" + "!"*60)
                    print("🚨 ALERTS - CHANGES DETECTED:")
                    print("!"*60)
                    for alert in changes:
                        print(f"  ⚠️  {alert}")
                    print("!"*60 + "\n")
                    
                    if gui:
                        gui.log("🚨 ALERTS - CHANGES DETECTED:")
                        for alert in changes:
                            gui.log(f"  ⚠️  {alert}")
                else:
                    print("✓ No changes detected.")
                    if gui:
                        gui.log("✓ No changes detected.")
            else:
                print("✓ First scan - baseline established.")
                if gui:
                    gui.log("✓ First scan - baseline established.")
            
            # Save current results
            scanner.save_current_results(new_results)
            
            # Sleep until next scan
            print(f"\n💤 Sleeping for {interval_hours} hours until next scan...")
            if gui:
                gui.log(f"💤 Next scan in {interval_hours} hours...")
            
            time.sleep(interval_hours * 3600)
            
        except KeyboardInterrupt:
            print("\n\n🏰 Watch Tower stopped by user.")
            if gui:
                gui.log("🏰 Watch Tower stopped by user.")
            break
        except Exception as e:
            print(f"\n❌ Error in Watch Tower: {e}")
            if gui:
                gui.log(f"❌ Watch Tower Error: {e}")
            logger.exception("Watch Tower error")
            
            # Wait before retrying
            print("⏳ Waiting 1 hour before retry...")
            time.sleep(3600)


def send_email_alert(alerts: List[str], domain: str, email_to: str, email_from: str, smtp_server: str, smtp_port: int = 587):
    """Send email alert with detected changes"""
    try:
        msg = EmailMessage()
        msg['Subject'] = f"🚨 Watch Tower Alert - {domain}"
        msg['From'] = email_from
        msg['To'] = email_to
        msg['X-Priority'] = '1'
        
        content = f"""
🏰 WATCH TOWER ALERT
====================

Domain: {domain}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

CHANGES DETECTED:
-----------------
"""
        for alert in alerts:
            content += f"• {alert}\n"
        
        content += """
--
This is an automated alert from Recon Hunter Pro Watch Tower.
"""
        
        msg.set_content(content)
        
        with smtplib.SMTP(smtp_server, smtp_port) as s:
            s.starttls()
            s.send_message(msg)
        
        print(f"📧 Email alert sent to {email_to}")
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False


    def _create_widgets(self):
        """Create all GUI widgets"""
        main_container = tk.Frame(self.root, bg="#0a0e27")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_container, bg="#0a0e27")
        header_frame.pack(fill="x", pady=(0, 20))
        
        title = ttk.Label(
            header_frame,
            text="🎯 RECON HUNTER PRO - ULTIMATE",
            style="Title.TLabel"
        )
        title.pack()
        
        subtitle = ttk.Label(
            header_frame,
            text="Enterprise Reconnaissance & OSINT Framework v4.0 | 30+ Sources | AI-Powered",
            style="Subtitle.TLabel"
        )
        subtitle.pack()
        
        # Input Section
        input_frame = tk.LabelFrame(
            main_container,
            text="⚙️ Configuration",
            font=("Segoe UI", 11, "bold"),
            bg="#1a1e3a",
            fg="#00d4ff",
            bd=2,
            relief="groove"
        )
        input_frame.pack(fill="x", pady=(0, 15))
        
        # Target domain
        target_frame = tk.Frame(input_frame, bg="#1a1e3a")
        target_frame.pack(fill="x", padx=15, pady=10)
        
        ttk.Label(target_frame, text="Target Domain:", background="#1a1e3a").pack(side="left", padx=(0, 10))
        self.domain_entry = ttk.Entry(target_frame, width=40, font=("Consolas", 11))
        self.domain_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        # Scan level
        scan_frame = tk.Frame(input_frame, bg="#1a1e3a")
        scan_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        ttk.Label(scan_frame, text="Scan Level:", background="#1a1e3a").pack(side="left", padx=(0, 20))
        
        self.scan_level_var = tk.StringVar(value="normal")
        
        levels = [
            ("🟢 Passive (Safe)", "passive"),
            ("🟡 Normal (Balanced)", "normal"),
            ("🔴 Aggressive (Full)", "aggressive"),
            ("🟣 Ultimate (Deep)", "ultimate")
        ]
        
        for text, value in levels:
            rb = ttk.Radiobutton(
                scan_frame,
                text=text,
                variable=self.scan_level_var,
                value=value,
                style="TRadiobutton"
            )
            rb.pack(side="left", padx=10)
        
        # Control buttons
        button_frame = tk.Frame(input_frame, bg="#1a1e3a")
        button_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        self.start_btn = tk.Button(
            button_frame,
            text="▶ START SCAN",
            command=self.start_scan,
            bg="#00aa00",
            fg="white",
            font=("Segoe UI", 10, "bold"),
            padx=20,
            pady=8,
            cursor="hand2",
            relief="flat"
        )
        self.start_btn.pack(side="left", padx=5)
        
        self.stop_btn = tk.Button(
            button_frame,
            text="⏹ STOP",
            command=self.stop_scan,
            bg="#cc0000",
            fg="white",
            font=("Segoe UI", 10, "bold"),
            padx=20,
            pady=8,
            cursor="hand2",
            relief="flat",
            state="disabled"
        )
        self.stop_btn.pack(side="left", padx=5)
        
        self.export_btn = tk.Button(
            button_frame,
            text="💾 EXPORT",
            command=lambda: self.save_results('json'),
            bg="#0066ff",
            fg="white",
            font=("Segoe UI", 10, "bold"),
            padx=20,
            pady=8,
            cursor="hand2",
            relief="flat"
        )
        self.export_btn.pack(side="left", padx=5)
        
        # Progress bar
        self.progress = ttk.Progressbar(
            button_frame,
            mode='indeterminate',
            length=200
        )
        self.progress.pack(side="right", padx=5)
        
        # Notebook for tabs
        self.notebook = ttk.Notebook(main_container)
        self.notebook.pack(fill="both", expand=True)
        
        # Tab 1: Live Logs
        log_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(log_tab, text="📋 Live Logs")
        
        self.log_text = scrolledtext.ScrolledText(
            log_tab,
            height=15,
            font=("Consolas", 9),
            bg="#0d1117",
            fg="#58a6ff",
            insertbackground="#58a6ff",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.log_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Tab 2: Results Summary
        summary_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(summary_tab, text="📊 Summary")
        
        self.summary_text = scrolledtext.ScrolledText(
            summary_tab,
            height=15,
            font=("Consolas", 9),
            bg="#0d1117",
            fg="#c9d1d9",
            insertbackground="#c9d1d9",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.summary_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Tab 3: Detailed Results
        details_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(details_tab, text="🔍 Detailed View")
        
        self.details_text = scrolledtext.ScrolledText(
            details_tab,
            height=15,
            font=("Consolas", 8),
            bg="#0d1117",
            fg="#c9d1d9",
            insertbackground="#c9d1d9",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.details_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Tab 4: Security Findings
        vuln_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(vuln_tab, text="⚠️ Security")
        
        self.vuln_text = scrolledtext.ScrolledText(
            vuln_tab,
            height=15,
            font=("Consolas", 9),
            bg="#0d1117",
            fg="#ff7b72",
            insertbackground="#ff7b72",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.vuln_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Tab 5: Secrets & API Keys
        secrets_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(secrets_tab, text="🔐 Secrets")
        
        self.secrets_text = scrolledtext.ScrolledText(
            secrets_tab,
            height=15,
            font=("Consolas", 9),
            bg="#0d1117",
            fg="#ffd700",
            insertbackground="#ffd700",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.secrets_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Tab 6: Takeover Detection
        takeover_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(takeover_tab, text="🎯 Takeovers")
        
        self.takeover_text = scrolledtext.ScrolledText(
            takeover_tab,
            height=15,
            font=("Consolas", 9),
            bg="#0d1117",
            fg="#ff6b6b",
            insertbackground="#ff6b6b",
            selectbackground="#1f6feb",
            relief="flat",
            bd=0
        )
        self.takeover_text.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Status bar
        status_frame = tk.Frame(main_container, bg="#0a0e27", height=25)
        status_frame.pack(fill="x", pady=(10, 0))
        
        self.status_label = tk.Label(
            status_frame,
            text="⚪ Ready",
            font=("Segoe UI", 9),
            bg="#0a0e27",
            fg="#7c8db5",
            anchor="w"
        )
        self.status_label.pack(side="left", fill="x", expand=True)
        
        self.custom_wordlist = None
    
    def log(self, message: str):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def clear_logs(self):
        """Clear all text areas"""
        self.log_text.delete(1.0, tk.END)
        self.summary_text.delete(1.0, tk.END)
        self.details_text.delete(1.0, tk.END)
        self.vuln_text.delete(1.0, tk.END)
        self.secrets_text.delete(1.0, tk.END)
        self.takeover_text.delete(1.0, tk.END)
    
    def load_wordlist(self):
        """Load custom wordlist"""
        filename = filedialog.askopenfilename(
            title="Select Wordlist",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'r') as f:
                    self.custom_wordlist = [line.strip() for line in f if line.strip()]
                messagebox.showinfo("Success", f"Loaded {len(self.custom_wordlist)} words")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load wordlist: {e}")
    
    def display_summary(self, results: Dict):
        """Display results summary"""
        self.summary_text.delete(1.0, tk.END)
        
        summary = results.get('summary', {})
        
        formatted = f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                    ULTIMATE RECONNAISSANCE SUMMARY                         ║
╚═══════════════════════════════════════════════════════════════════════════╝

📌 TARGET INFORMATION
   • Domain: {results.get('domain', 'N/A')}
   • Scan Level: {results.get('scan_level', 'N/A').upper()}
   • Scan Time: {results.get('scan_time', 'N/A')}
   • Completion: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 DISCOVERY METRICS
   • Total Subdomains: {summary.get('total_subdomains', 0)}
   • Live Services: {summary.get('alive_services', 0)}
   • Unique IP Addresses: {summary.get('unique_ips', 0)}
   • CDN Protected: {summary.get('cdn_count', 0)}
   • Real IPs Exposed: {summary.get('real_ips', 0)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛡️  SECURITY POSTURE
   • WAFs Detected: {', '.join(summary.get('wafs_detected', [])) or 'None'}
   • Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)} subdomains
   • Secrets Found: {summary.get('secrets_found', 0)}
   • Cloud Buckets: {summary.get('cloud_buckets', 0)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚙️  TECHNOLOGY STACK ({len(summary.get('technologies', []))})
   {chr(10).join(['• ' + tech for tech in summary.get('technologies', [])[:30]])}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 TOP FINDINGS
"""
        
        # Add top live services
        subdomains = results.get('subdomains', {})
        live_services = [(sub, info) for sub, info in subdomains.items() if info.get('status_code')]
        live_services.sort(key=lambda x: x[1].get('status_code', 999))
        
        formatted += "\n🌐 Live Services:\n"
        for sub, info in live_services[:15]:
            formatted += f"   • {sub} [{info.get('status_code')}] - {info.get('title', '')[:50]}\n"
        
        self.summary_text.insert(tk.END, formatted)
    
    def display_details(self, results: Dict):
        """Display detailed results"""
        self.details_text.delete(1.0, tk.END)
        
        subdomains = results.get('subdomains', {})
        
        for subdomain, info in sorted(subdomains.items()):
            if info.get('ips') or info.get('status_code'):
                detail = f"\n{'='*80}\n"
                detail += f"🔹 {subdomain}\n"
                detail += f"{'='*80}\n"
                
                if info.get('ips'):
                    detail += f"📍 IPs: {', '.join(info['ips'])}\n"
                
                if info.get('cdn'):
                    detail += f"☁️  CDN: {info['cdn']}\n"
                
                if info.get('cnames'):
                    detail += f"🔗 CNAME: {', '.join(info['cnames'])}\n"
                
                if info.get('status_code'):
                    detail += f"🌐 HTTP: {info['status_code']} - {info.get('title', '')[:100]}\n"
                    detail += f"   Server: {info.get('server', 'Unknown')}\n"
                
                if info.get('technologies'):
                    detail += f"⚙️  Tech: {', '.join(info['technologies'])}\n"
                
                if info.get('waf'):
                    detail += f"🛡️  WAF: {info['waf']}\n"
                
                if info.get('open_ports'):
                    ports_str = ', '.join([f"{p['port']}({p['service']})" for p in info['open_ports']])
                    detail += f"🔓 Open Ports: {ports_str}\n"
                
                if info.get('ssl_info') and info['ssl_info'].get('valid'):
                    ssl = info['ssl_info']
                    detail += f"🔒 SSL: {ssl.get('issuer', 'Unknown')} (Grade: {ssl.get('grade', 'N/A')})\n"
                
                if info.get('security_headers'):
                    detail += f"🛡️  Security Score: {info['security_headers'].get('score', 0)}%\n"
                
                self.details_text.insert(tk.END, detail)
    
    def display_security(self, results: Dict):
        """Display security findings"""
        self.vuln_text.delete(1.0, tk.END)
        
        findings = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                          SECURITY ASSESSMENT                              ║
╚═══════════════════════════════════════════════════════════════════════════╝

⚠️  POTENTIAL SECURITY CONCERNS

"""
        
        subdomains = results.get('subdomains', {})
        
        # Exposed admin panels
        admin_keywords = ['admin', 'cpanel', 'phpmyadmin', 'adminer', 'dashboard', 'panel', 'manager', 'console']
        admin_panels = []
        
        for sub, info in subdomains.items():
            if any(keyword in sub.lower() for keyword in admin_keywords) and info.get('status_code'):
                admin_panels.append(f"   • {sub} [{info.get('status_code')}]")
        
        if admin_panels:
            findings += "🚨 Exposed Admin Interfaces:\n"
            findings += '\n'.join(admin_panels[:15]) + "\n\n"
        
        # Unprotected subdomains (no CDN/WAF)
        exposed = []
        for sub, info in subdomains.items():
            if info.get('ips') and not info.get('cdn') and not info.get('waf') and info.get('status_code'):
                exposed.append(f"   • {sub} - {', '.join(info['ips'][:2])}")
        
        if exposed:
            findings += "🔓 Subdomains Without Protection:\n"
            findings += '\n'.join(exposed[:20]) + "\n\n"
        
        # SSL issues
        ssl_issues = []
        for sub, info in subdomains.items():
            if info.get('ssl_info'):
                ssl = info['ssl_info']
                if ssl.get('expired'):
                    ssl_issues.append(f"   • {sub} - Certificate EXPIRED")
                elif ssl.get('self_signed'):
                    ssl_issues.append(f"   • {sub} - Self-signed certificate")
                elif ssl.get('grade') in ['C', 'D', 'F']:
                    ssl_issues.append(f"   • {sub} - Weak SSL (Grade: {ssl.get('grade')})")
        
        if ssl_issues:
            findings += "🔐 SSL/TLS Issues:\n"
            findings += '\n'.join(ssl_issues[:15]) + "\n\n"
        
        # Open dangerous ports
        dangerous_ports = [21, 23, 3306, 3389, 5900, 6379, 27017, 9200, 11211]
        port_issues = []
        
        for sub, info in subdomains.items():
            open_dangerous = [p for p in info.get('open_ports', []) if p['port'] in dangerous_ports]
            if open_dangerous:
                port_issues.append(f"   • {sub} - Ports: {', '.join([str(p['port']) for p in open_dangerous])}")
        
        if port_issues:
            findings += "🔴 Dangerous Open Ports:\n"
            findings += '\n'.join(port_issues[:15]) + "\n\n"
        
        # Security headers issues
        header_issues = []
        for sub, info in subdomains.items():
            if info.get('security_headers') and info['security_headers'].get('score', 100) < 50:
                missing = list(info['security_headers'].get('missing', {}).keys())[:5]
                header_issues.append(f"   • {sub} - Missing: {', '.join(missing)}")
        
        if header_issues:
            findings += "📋 Missing Security Headers:\n"
            findings += '\n'.join(header_issues[:15]) + "\n\n"
        
        if not (admin_panels or exposed or ssl_issues or port_issues or header_issues):
            findings += "✅ No major security concerns detected in this scan.\n"
            findings += "   (Note: This is not a comprehensive security audit)\n"
        
        findings += "\n" + "="*80 + "\n"
        findings += "⚠️  DISCLAIMER: This is reconnaissance data only. Always perform\n"
        findings += "    proper security testing with authorization.\n"
        
        self.vuln_text.insert(tk.END, findings)
    
    def display_secrets(self, results: Dict):
        """Display found secrets"""
        self.secrets_text.delete(1.0, tk.END)
        
        content = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                      SECRETS & SENSITIVE DATA FOUND                        ║
╚═══════════════════════════════════════════════════════════════════════════╝

🔐 JAVASCRIPT SECRETS DETECTED

"""
        
        subdomains = results.get('subdomains', {})
        total_secrets = 0
        
        for sub, info in subdomains.items():
            if info.get('js_secrets'):
                content += f"\n📌 {sub}:\n"
                for secret in info['js_secrets']:
                    total_secrets += 1
                    content += f"   • [{secret['type']}] {secret['value']}\n"
        
        if total_secrets == 0:
            content += "\n✅ No secrets found in JavaScript files.\n"
        else:
            content += f"\n\n⚠️  Total secrets found: {total_secrets}\n"
            content += "⚠️  Please review and rotate these credentials immediately!\n"
        
        # Cloud buckets
        content += "\n" + "="*80 + "\n"
        content += "☁️  CLOUD STORAGE BUCKETS\n\n"
        
        bucket_count = 0
        for sub, info in subdomains.items():
            if info.get('cloud_buckets'):
                content += f"\n📌 {sub}:\n"
                for bucket in info['cloud_buckets']:
                    bucket_count += 1
                    status = "🔓 PUBLIC" if bucket.get('public') else "🔒 Private"
                    content += f"   • [{bucket['provider']}] {bucket['bucket']} - {status}\n"
        
        if bucket_count == 0:
            content += "\n✅ No cloud storage buckets detected.\n"
        
        self.secrets_text.insert(tk.END, content)
    
    def display_takeovers(self, results: Dict):
        """Display subdomain takeover findings"""
        self.takeover_text.delete(1.0, tk.END)
        
        content = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                    SUBDOMAIN TAKEOVER DETECTION                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

🎯 VULNERABLE SUBDOMAIN TAKEOVERS

"""
        
        subdomains = results.get('subdomains', {})
        vulnerable = []
        
        for sub, info in subdomains.items():
            if info.get('takeover_vulnerable'):
                vulnerable.append({
                    'subdomain': sub,
                    'type': info.get('takeover_type'),
                    'cname': ', '.join(info.get('cnames', []))
                })
        
        if vulnerable:
            for v in vulnerable:
                content += f"🚨 {v['subdomain']}\n"
                content += f"   • Service: {v['type']}\n"
                content += f"   • CNAME: {v['cname']}\n"
                content += f"   • Status: VULNERABLE TO TAKEOVER\n\n"
            
            content += f"\n⚠️  Total vulnerable: {len(vulnerable)}\n"
            content += "⚠️  These subdomains can be claimed by attackers!\n"
        else:
            content += "\n✅ No vulnerable subdomain takeovers detected.\n"
        
        # Potential takeovers (CNAME exists but not verified)
        content += "\n" + "="*80 + "\n"
        content += "🔍 POTENTIAL TAKEOVER TARGETS (CNAME pointing to external services)\n\n"
        
        potential = []
        for sub, info in subdomains.items():
            if info.get('cnames') and not info.get('status_code'):
                potential.append({
                    'subdomain': sub,
                    'cnames': info.get('cnames', [])
                })
        
        if potential:
            for p in potential[:20]:
                content += f"• {p['subdomain']} -> {', '.join(p['cnames'])}\n"
        else:
            content += "\n✅ No potential takeover targets found.\n"
        
        self.takeover_text.insert(tk.END, content)
    
    def export_secrets(self):
        """Export secrets to file"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to export!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")]
        )
        
        if filename:
            secrets_data = {
                'domain': self.results.get('domain'),
                'scan_time': self.results.get('scan_time'),
                'secrets': [],
                'buckets': []
            }
            
            for sub, info in self.results.get('subdomains', {}).items():
                if info.get('js_secrets'):
                    for secret in info['js_secrets']:
                        secrets_data['secrets'].append({
                            'subdomain': sub,
                            'type': secret['type'],
                            'value': secret['full_match']
                        })
                
                if info.get('cloud_buckets'):
                    for bucket in info['cloud_buckets']:
                        secrets_data['buckets'].append({
                            'subdomain': sub,
                            'provider': bucket['provider'],
                            'bucket': bucket['bucket'],
                            'public': bucket.get('public', False)
                        })
            
            with open(filename, 'w') as f:
                json.dump(secrets_data, f, indent=2)
            
            messagebox.showinfo("Success", f"Secrets exported to {filename}")
    
    def save_results(self, format_type: str):
        """Save results in specified format"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to save!")
            return
        
        if format_type == 'json':
            filename = filedialog.asksaveasfilename(
                defaultextension=".json",
                filetypes=[("JSON files", "*.json")]
            )
            if filename:
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(self.results, f, indent=2, default=str)
                messagebox.showinfo("Success", f"Results saved to {filename}")
        
        elif format_type == 'csv':
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv")]
            )
            if filename:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Subdomain', 'IPs', 'Status', 'Title', 'Technologies', 'CDN', 'WAF', 'Takeover', 'Ports'])
                    
                    for sub, info in self.results['subdomains'].items():
                        writer.writerow([
                            sub,
                            ', '.join(info.get('ips', [])),
                            info.get('status_code', ''),
                            info.get('title', ''),
                            ', '.join(info.get('technologies', [])),
                            info.get('cdn', ''),
                            info.get('waf', ''),
                            'VULNERABLE' if info.get('takeover_vulnerable') else '',
                            ', '.join([str(p['port']) for p in info.get('open_ports', [])])
                        ])
                messagebox.showinfo("Success", f"Results saved to {filename}")
        
        elif format_type == 'html':
            filename = filedialog.asksaveasfilename(
                defaultextension=".html",
                filetypes=[("HTML files", "*.html")]
            )
            if filename:
                html_content = self._generate_html_report(self.results)
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(html_content)
                messagebox.showinfo("Success", f"Report saved to {filename}")
    
    def _generate_html_report(self, results: Dict) -> str:
        """Generate HTML report"""
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Ultimate Recon Report - {results['domain']}</title>
    <style>
        body {{ font-family: Arial, sans-serif; background: #0a0e27; color: #e1e8f0; margin: 40px; }}
        h1 {{ color: #00d4ff; }}
        h2 {{ color: #58a6ff; margin-top: 30px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #2a2e4a; padding: 12px; text-align: left; }}
        th {{ background: #1a1e3a; color: #00d4ff; }}
        tr:hover {{ background: #1a1e3a; }}
        .metric {{ display: inline-block; margin: 10px 20px; padding: 15px; background: #1a1e3a; border-radius: 8px; }}
        .metric-value {{ font-size: 24px; font-weight: bold; color: #00d4ff; }}
        .vulnerable {{ color: #ff6b6b; font-weight: bold; }}
        .secret {{ color: #ffd700; }}
        .cdn {{ color: #7ee787; }}
    </style>
</head>
<body>
    <h1>🎯 Ultimate Reconnaissance Report</h1>
    <p><strong>Target:</strong> {results['domain']}</p>
    <p><strong>Scan Time:</strong> {results['scan_time']}</p>
    <p><strong>Scan Level:</strong> {results['scan_level'].upper()}</p>
    <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    
    <h2>📊 Summary</h2>
    <div>
        <div class="metric">
            <div class="metric-value">{results['summary']['total_subdomains']}</div>
            <div>Total Subdomains</div>
        </div>
        <div class="metric">
            <div class="metric-value">{results['summary']['alive_services']}</div>
            <div>Live Services</div>
        </div>
        <div class="metric">
            <div class="metric-value">{results['summary']['unique_ips']}</div>
            <div>Unique IPs</div>
        </div>
        <div class="metric">
            <div class="metric-value">{results['summary']['takeover_vulnerable']}</div>
            <div>Takeover Vulnerable</div>
        </div>
        <div class="metric">
            <div class="metric-value">{results['summary']['secrets_found']}</div>
            <div>Secrets Found</div>
        </div>
    </div>
    
    <h2>🌐 Discovered Subdomains</h2>
    <table>
        <tr>
            <th>Subdomain</th>
            <th>IP Addresses</th>
            <th>Status</th>
            <th>Title</th>
            <th>Technologies</th>
            <th>CDN/WAF</th>
            <th>Takeover</th>
        </tr>
"""
        
        for sub, info in sorted(results['subdomains'].items()):
            if info.get('status_code') or info.get('ips'):
                takeover_class = 'vulnerable' if info.get('takeover_vulnerable') else ''
                cdn_class = 'cdn' if info.get('cdn') else ''
                
                html += f"""
        <tr>
            <td>{sub}</td>
            <td>{', '.join(info.get('ips', [])[:3])}</td>
            <td>{info.get('status_code', '-')}</td>
            <td>{info.get('title', '')[:100]}</td>
            <td>{', '.join(info.get('technologies', [])[:5])}</td>
            <td class="{cdn_class}">{info.get('cdn') or info.get('waf') or '-'}</td>
            <td class="{takeover_class}">{'VULNERABLE' if info.get('takeover_vulnerable') else '-'}</td>
        </tr>
"""
        
        html += """
    </table>
</body>
</html>
"""
        return html
    
    def show_api_config(self):
        """Show API configuration dialog"""
        config_window = tk.Toplevel(self.root)
        config_window.title("API Configuration")
        config_window.geometry("500x400")
        config_window.configure(bg="#1a1e3a")
        
        # API Key entries
        apis = [
            ("Shodan API Key", "SHODAN_API_KEY"),
            ("Censys API ID", "CENSYS_API_ID"),
            ("Censys API Secret", "CENSYS_API_SECRET"),
            ("SecurityTrails API Key", "SECURITYTRAILS_API_KEY"),
            ("VirusTotal API Key", "VIRUSTOTAL_API_KEY"),
            ("BinaryEdge API Key", "BINARYEDGE_API_KEY"),
            ("ZoomEye API Key", "ZOOMEYE_API_KEY"),
        ]
        
        entries = {}
        for i, (label, key) in enumerate(apis):
            tk.Label(config_window, text=label, bg="#1a1e3a", fg="#e1e8f0").grid(row=i, column=0, padx=10, pady=5, sticky="w")
            entry = ttk.Entry(config_window, width=40, show="*")
            entry.grid(row=i, column=1, padx=10, pady=5)
            entry.insert(0, getattr(self.config, key, ""))
            entries[key] = entry
        
        def save_config():
            for key, entry in entries.items():
                setattr(self.config, key, entry.get())
            config_window.destroy()
            messagebox.showinfo("Success", "API keys saved!")
        
        tk.Button(config_window, text="Save", command=save_config, bg="#0066ff", fg="white").grid(row=len(apis), column=0, columnspan=2, pady=20)
    
    def start_scan(self):
        """Start reconnaissance scan"""
        domain = self.domain_entry.get().strip()
        
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        # Validate domain format
        if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?\.[a-zA-Z]{2,}$', domain):
            messagebox.showerror("Error", "Invalid domain format!")
            return
        
        # Clear previous results
        self.clear_logs()
        self.results = None
        
        # Update UI
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.progress.start(10)
        self.status_label.config(text="🟢 Scanning...", fg="#00ff00")
        
        # Get scan level
        scan_level_map = {
            'passive': ScanLevel.PASSIVE,
            'normal': ScanLevel.NORMAL,
            'aggressive': ScanLevel.AGGRESSIVE,
            'ultimate': ScanLevel.ULTIMATE
        }
        scan_level = scan_level_map[self.scan_level_var.get()]
        
        # Run scan in thread
        def run_scan():
            try:
                self.scanner = UltimateReconScanner(gui=self, scan_level=scan_level, config=self.config)
                results = asyncio.run(self.scanner.run(domain, self.custom_wordlist))
                
                self.results = results
                
                # Display results
                self.root.after(0, self.display_summary, results)
                self.root.after(0, self.display_details, results)
                self.root.after(0, self.display_security, results)
                self.root.after(0, self.display_secrets, results)
                self.root.after(0, self.display_takeovers, results)
                
                self.root.after(0, self.status_label.config, 
                               {'text': '✅ Scan completed', 'fg': '#00ff00'})
                
            except Exception as e:
                self.log(f"❌ Error: {str(e)}")
                logger.exception("Scan error")
                self.root.after(0, messagebox.showerror, "Error", f"Scan failed: {e}")
            
            finally:
                self.root.after(0, self.start_btn.config, {'state': 'normal'})
                self.root.after(0, self.stop_btn.config, {'state': 'disabled'})
                self.root.after(0, self.progress.stop)
        
        threading.Thread(target=run_scan, daemon=True).start()
    
    def stop_scan(self):
        """Stop ongoing scan"""
        if self.scanner:
            self.scanner.stop()
        self.progress.stop()
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.status_label.config(text="⏸️ Stopped", fg="#ff7b72")
        self.log("⏹️ Scan stopped by user")
    
    def show_about(self):
        """Show about dialog"""
        about_text = """
Recon Hunter Pro - ULTIMATE Edition v4.0

Advanced Reconnaissance & OSINT Framework

Features:
• 30+ Passive Recon Sources
• Subdomain Takeover Detection
• JavaScript Secret Detection
• Cloud Storage Bucket Detection
• Security Headers Analysis
• Technology Stack Detection
• WAF/CDN Identification
• Port Scanning
• SSL/TLS Analysis
• Export to Multiple Formats

© 2024 Recon Hunter Pro
"""
        messagebox.showinfo("About", about_text)
    
    def show_docs(self):
        """Show documentation"""
        docs_text = """
QUICK START GUIDE

1. Enter target domain
2. Select scan level:
   - Passive: Safe, only public APIs
   - Normal: Adds DNS bruteforce
   - Aggressive: Adds port scanning, WAF detection
   - Ultimate: Full deep scan with JS analysis

3. Click START SCAN
4. View results in tabs
5. Export as JSON/CSV/HTML

SCAN LEVELS:
- Passive: Only uses public APIs (safest)
- Normal: Adds DNS bruteforce
- Aggressive: Adds port scanning, WAF detection
- Ultimate: Full deep scan with JS analysis, secret detection

NEW FEATURES IN v4.0:
- 30+ passive recon sources
- Subdomain takeover detection
- JavaScript secret detection
- Cloud bucket detection
- Security headers analysis
- API endpoint discovery
- Email enumeration

TIPS:
- Configure API keys for enhanced results
- Use custom wordlists for better coverage
- Ultimate mode may take longer but finds more
- Always get permission before scanning
"""
        messagebox.showinfo("Documentation", docs_text)


# ═══════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

def main():
    """Main entry point"""
    try:
        # Create and run GUI
        root = tk.Tk()
        app = ReconHunterUltimateGUI(root)
        
        # Center window
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - (root.winfo_width() // 2)
        y = (root.winfo_screenheight() // 2) - (root.winfo_height() // 2)
        root.geometry(f'+{x}+{y}')
        
        root.mainloop()
        
    except Exception as e:
        logger.exception("Application error")
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║          🎯 RECON HUNTER PRO - ULTIMATE EDITION v4.0 🎯                   ║
║                                                                           ║
║              Advanced Reconnaissance & OSINT Framework                    ║
║                      30+ Sources | AI-Powered Analysis                     ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

[*] Initializing application...
[*] Loading modules...
[*] Starting GUI...

""")
    main()