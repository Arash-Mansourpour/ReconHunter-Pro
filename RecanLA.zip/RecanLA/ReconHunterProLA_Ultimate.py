
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔═══════════════════════════════════════════════════════════════════════════╗
║           RECON HUNTER PRO - ULTIMATE EDITION v5.0                        ║
║           AI-Powered Reconnaissance & OSINT Framework                     ║
║           With Continuous Monitoring, Nuclei Integration & Dashboard      ║
╚═══════════════════════════════════════════════════════════════════════════╝

NEW FEATURES IN v5.0:
✓ AI-Powered Subdomain Prediction (GPT-based)
✓ Continuous Monitoring & Change Detection
✓ Nuclei Integration for Vulnerability Scanning
✓ Dark Web & Paste Site Monitoring
✓ Interactive Dashboard (Web-based)
✓ Webhook Notifications (Slack, Discord, Telegram)
✓ BGP & WHOIS Analysis
✓ Social Media OSINT
✓ Cloud Security Assessment
✓ API Security Testing (GraphQL, REST)
✓ Distributed Scanning Support
✓ Database Backend (SQLite/PostgreSQL)
"""

import sys
import os
import asyncio
import aiohttp
import aiodns
import json
import logging
import threading
import concurrent.futures
from datetime import datetime, timedelta
from typing import Set, Dict, List, Tuple, Optional, Any, AsyncGenerator
from collections import defaultdict
import ipaddress
import subprocess
import socket
import re
import requests
import warnings
import base64
from urllib.parse import urlparse, urljoin, parse_qs
import hashlib
import ssl
import OpenSSL
from dataclasses import dataclass, asdict, field
from enum import Enum
import random
import time
from bs4 import BeautifulSoup
import tldextract
import dns.resolver
import dns.reversename
import sqlite3
import tempfile
import hashlib
import pickle

if sys.platform.startswith('win'):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from tkinter import font as tkfont

warnings.filterwarnings('ignore')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('recon_hunter_ultimate_v5.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class Config:
    """Configuration settings"""
    # API Keys
    SHODAN_API_KEY: str = ""
    CENSYS_API_ID: str = ""
    CENSYS_API_SECRET: str = ""
    SECURITYTRAILS_API_KEY: str = ""
    VIRUSTOTAL_API_KEY: str = ""
    BINARYEDGE_API_KEY: str = ""
    ZOOMEYE_API_KEY: str = ""
    FOFA_API_KEY: str = ""
    HUNTER_API_KEY: str = ""
    HAVEIBEENPWNED_API_KEY: str = ""
    DEHASHED_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    
    # Notification Webhooks
    SLACK_WEBHOOK_URL: str = ""
    DISCORD_WEBHOOK_URL: str = ""
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_CHAT_ID: str = ""
    CUSTOM_WEBHOOK_URL: str = ""
    
    # Rate limiting
    REQUEST_DELAY: float = 0.1
    MAX_CONCURRENT_REQUESTS: int = 50
    TIMEOUT: int = 30
    
    # Proxy settings
    USE_PROXY: bool = False
    PROXY_LIST: List[str] = field(default_factory=list)
    TOR_PROXY: str = "socks5h://127.0.0.1:9050"
    
    # Stealth settings
    STEALTH_MODE: bool = False
    STEALTH_DELAY_MIN: float = 2.0
    STEALTH_DELAY_MAX: float = 5.0
    
    # Monitoring settings
    MONITORING_INTERVAL_HOURS: int = 24
    ENABLE_CONTINUOUS_MONITORING: bool = False
    
    # Nuclei settings
    NUCLEI_TEMPLATES_DIR: str = "nuclei-templates"
    NUCLEI_SEVERITY: List[str] = field(default_factory=lambda: ['critical', 'high', 'medium'])
    
    # Database settings
    DATABASE_PATH: str = "recon_hunter.db"
    
    # Output settings
    OUTPUT_DIR: str = "recon_results"
    SCREENSHOTS_DIR: str = "screenshots"
    JS_ANALYSIS_DIR: str = "js_analysis"
    DASHBOARD_PORT: int = 8050


# ═══════════════════════════════════════════════════════════════════════════
# DATABASE MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class DatabaseManager:
    """
    SQLite database manager for storing scan results
    """
    
    def __init__(self, db_path: str = "recon_hunter.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Scans table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT NOT NULL,
                scan_level TEXT,
                scan_time TEXT,
                total_subdomains INTEGER,
                alive_services INTEGER,
                unique_ips INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                results_json TEXT
            )
        ''')
        
        # Subdomains table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subdomains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                subdomain TEXT NOT NULL,
                ips TEXT,
                status_code INTEGER,
                title TEXT,
                technologies TEXT,
                cdn TEXT,
                waf TEXT,
                takeover_vulnerable BOOLEAN,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (scan_id) REFERENCES scans(id)
            )
        ''')
        
        # Changes table for monitoring
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT NOT NULL,
                change_type TEXT,
                subdomain TEXT,
                details TEXT,
                severity TEXT,
                detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Secrets table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS secrets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                subdomain TEXT,
                secret_type TEXT,
                secret_value TEXT,
                url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (scan_id) REFERENCES scans(id)
            )
        ''')
        
        # Vulnerabilities table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                subdomain TEXT,
                vulnerability_type TEXT,
                severity TEXT,
                description TEXT,
                evidence TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (scan_id) REFERENCES scans(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_scan(self, results: Dict) -> int:
        """Save scan results to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO scans (domain, scan_level, scan_time, total_subdomains, 
                             alive_services, unique_ips, results_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            results.get('domain'),
            results.get('scan_level'),
            results.get('scan_time'),
            results.get('summary', {}).get('total_subdomains', 0),
            results.get('summary', {}).get('alive_services', 0),
            results.get('summary', {}).get('unique_ips', 0),
            json.dumps(results, default=str)
        ))
        
        scan_id = cursor.lastrowid
        
        # Save subdomains
        for subdomain, info in results.get('subdomains', {}).items():
            cursor.execute('''
                INSERT INTO subdomains (scan_id, subdomain, ips, status_code, title,
                                       technologies, cdn, waf, takeover_vulnerable)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                scan_id,
                subdomain,
                json.dumps(info.get('ips', [])),
                info.get('status_code'),
                info.get('title', ''),
                json.dumps(info.get('technologies', [])),
                info.get('cdn'),
                info.get('waf'),
                info.get('takeover_vulnerable', False)
            ))
        
        conn.commit()
        conn.close()
        return scan_id
    
    def get_last_scan(self, domain: str) -> Optional[Dict]:
        """Get the last scan for a domain"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT results_json FROM scans 
            WHERE domain = ? 
            ORDER BY created_at DESC 
            LIMIT 1
        ''', (domain,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return json.loads(result[0])
        return None
    
    def save_change(self, domain: str, change_type: str, subdomain: str, 
                   details: str, severity: str):
        """Save detected change"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO changes (domain, change_type, subdomain, details, severity)
            VALUES (?, ?, ?, ?, ?)
        ''', (domain, change_type, subdomain, details, severity))
        
        conn.commit()
        conn.close()
    
    def get_scan_history(self, domain: str, limit: int = 10) -> List[Dict]:
        """Get scan history for a domain"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, domain, scan_level, scan_time, total_subdomains, 
                   alive_services, created_at
            FROM scans 
            WHERE domain = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (domain, limit))
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'id': row[0],
                'domain': row[1],
                'scan_level': row[2],
                'scan_time': row[3],
                'total_subdomains': row[4],
                'alive_services': row[5],
                'created_at': row[6]
            })
        
        conn.close()
        return results


# ═══════════════════════════════════════════════════════════════════════════
# NOTIFICATION MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class NotificationManager:
    """
    Send notifications to various platforms
    """
    
    def __init__(self, config: Config):
        self.config = config
    
    async def send_notification(self, title: str, message: str, severity: str = "info"):
        """Send notification to all configured platforms"""
        tasks = []
        
        if self.config.SLACK_WEBHOOK_URL:
            tasks.append(self._send_slack(title, message, severity))
        
        if self.config.DISCORD_WEBHOOK_URL:
            tasks.append(self._send_discord(title, message, severity))
        
        if self.config.TELEGRAM_BOT_TOKEN and self.config.TELEGRAM_CHAT_ID:
            tasks.append(self._send_telegram(title, message))
        
        if self.config.CUSTOM_WEBHOOK_URL:
            tasks.append(self._send_custom_webhook(title, message, severity))
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _send_slack(self, title: str, message: str, severity: str):
        """Send Slack notification"""
        colors = {
            'critical': '#FF0000',
            'high': '#FF6600',
            'medium': '#FFCC00',
            'low': '#00CC00',
            'info': '#0066FF'
        }
        
        payload = {
            "attachments": [{
                "color": colors.get(severity, '#0066FF'),
                "title": title,
                "text": message,
                "footer": "Recon Hunter Pro v5.0",
                "ts": int(time.time())
            }]
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.config.SLACK_WEBHOOK_URL, 
                                       json=payload) as response:
                    if response.status != 200:
                        logger.warning(f"Slack notification failed: {response.status}")
        except Exception as e:
            logger.warning(f"Slack notification error: {e}")
    
    async def _send_discord(self, title: str, message: str, severity: str):
        """Send Discord notification"""
        colors = {
            'critical': 0xFF0000,
            'high': 0xFF6600,
            'medium': 0xFFCC00,
            'low': 0x00CC00,
            'info': 0x0066FF
        }
        
        payload = {
            "embeds": [{
                "title": title,
                "description": message,
                "color": colors.get(severity, 0x0066FF),
                "footer": {"text": "Recon Hunter Pro v5.0"},
                "timestamp": datetime.utcnow().isoformat()
            }]
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.config.DISCORD_WEBHOOK_URL, 
                                       json=payload) as response:
                    if response.status != 204:
                        logger.warning(f"Discord notification failed: {response.status}")
        except Exception as e:
            logger.warning(f"Discord notification error: {e}")
    
    async def _send_telegram(self, title: str, message: str):
        """Send Telegram notification"""
        url = f"https://api.telegram.org/bot{self.config.TELEGRAM_BOT_TOKEN}/sendMessage"
        
        text = f"*{title}*\n\n{message}"
        
        payload = {
            "chat_id": self.config.TELEGRAM_CHAT_ID,
            "text": text,
            "parse_mode": "Markdown"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as response:
                    if response.status != 200:
                        logger.warning(f"Telegram notification failed: {response.status}")
        except Exception as e:
            logger.warning(f"Telegram notification error: {e}")
    
    async def _send_custom_webhook(self, title: str, message: str, severity: str):
        """Send custom webhook notification"""
        payload = {
            "title": title,
            "message": message,
            "severity": severity,
            "source": "Recon Hunter Pro v5.0",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.config.CUSTOM_WEBHOOK_URL, 
                                       json=payload) as response:
                    if response.status != 200:
                        logger.warning(f"Custom webhook failed: {response.status}")
        except Exception as e:
            logger.warning(f"Custom webhook error: {e}")


# ═══════════════════════════════════════════════════════════════════════════
# AI-POWERED SUBDOMAIN PREDICTOR
# ═══════════════════════════════════════════════════════════════════════════

class AISubdomainPredictor:
    """
    AI-powered subdomain prediction using pattern analysis
    """
    
    def __init__(self, openai_api_key: str = None):
        self.api_key = openai_api_key
        self.patterns = {}
    
    def analyze_patterns(self, known_subdomains: List[str]) -> Dict:
        """Analyze patterns in known subdomains"""
        patterns = {
            'prefixes': defaultdict(int),
            'suffixes': defaultdict(int),
            'numbers': defaultdict(int),
            'environments': defaultdict(int),
            'services': defaultdict(int)
        }
        
        prefixes = ['www', 'mail', 'api', 'dev', 'staging', 'prod', 'test', 
                   'beta', 'admin', 'portal', 'app', 'cdn', 'static']
        environments = ['dev', 'development', 'staging', 'stage', 'prod', 
                       'production', 'test', 'testing', 'beta', 'demo', 'uat']
        services = ['api', 'apis', 'gateway', 'backend', 'frontend', 'admin',
                   'dashboard', 'panel', 'console', 'portal', 'app']
        
        for subdomain in known_subdomains:
            parts = subdomain.split('.')[0]
            
            # Check for prefixes
            for prefix in prefixes:
                if parts.startswith(prefix):
                    patterns['prefixes'][prefix] += 1
            
            # Check for suffixes
            for suffix in services:
                if parts.endswith(suffix):
                    patterns['suffixes'][suffix] += 1
            
            # Check for environments
            for env in environments:
                if env in parts.lower():
                    patterns['environments'][env] += 1
            
            # Check for numbers
            numbers = re.findall(r'\d+', parts)
            for num in numbers:
                patterns['numbers'][num] += 1
            
            # Check for services
            for service in services:
                if service in parts.lower():
                    patterns['services'][service] += 1
        
        self.patterns = patterns
        return patterns
    
    def generate_predictions(self, domain: str, known_subdomains: List[str], 
                           count: int = 100) -> List[str]:
        """Generate predicted subdomains based on patterns"""
        predictions = set()
        
        # Analyze patterns
        self.analyze_patterns(known_subdomains)
        
        # Common prefixes
        prefixes = ['www', 'mail', 'api', 'dev', 'staging', 'prod', 'test', 
                   'beta', 'admin', 'portal', 'app', 'cdn', 'static', 'assets',
                   'media', 'img', 'images', 'blog', 'shop', 'store', 'support',
                   'help', 'docs', 'wiki', 'forum', 'community', 'status',
                   'vpn', 'remote', 'secure', 'login', 'auth', 'sso', 'm',
                   'mobile', 'ws', 'socket', 'realtime', 'stream', 'video',
                   'audio', 'files', 'download', 'upload', 'backup', 'db',
                   'database', 'mysql', 'postgres', 'mongo', 'redis', 'cache']
        
        # Common suffixes
        suffixes = ['api', 'app', 'web', 'server', 'portal', 'admin', 'backend',
                   'frontend', 'service', 'internal', 'external', 'proxy']
        
        # Environments
        environments = ['dev', 'development', 'staging', 'stage', 'prod', 
                       'production', 'test', 'testing', 'beta', 'demo', 'uat']
        
        # Numbers
        numbers = ['1', '2', '3', '01', '02', '03', 'v1', 'v2', 'v3']
        
        # Separators
        separators = ['-', '_', '']
        
        # Generate based on prefixes
        for prefix in prefixes:
            predictions.add(f"{prefix}.{domain}")
        
        # Generate based on environments
        for env in environments:
            for prefix in prefixes[:20]:
                for sep in separators:
                    predictions.add(f"{prefix}{sep}{env}.{domain}")
                    predictions.add(f"{env}{sep}{prefix}.{domain}")
        
        # Generate based on numbers
        for num in numbers:
            for prefix in prefixes[:15]:
                for sep in separators:
                    predictions.add(f"{prefix}{sep}{num}.{domain}")
        
        # Generate based on suffixes
        for prefix in prefixes[:20]:
            for suffix in suffixes:
                for sep in separators:
                    predictions.add(f"{prefix}{sep}{suffix}.{domain}")
        
        # Extract base names from known subdomains and generate variations
        for subdomain in list(known_subdomains)[:30]:
            base = subdomain.split('.')[0]
            
            # Add environment variations
            for env in environments:
                for sep in separators:
                    predictions.add(f"{base}{sep}{env}.{domain}")
                    predictions.add(f"{env}{sep}{base}.{domain}")
            
            # Add number variations
            for num in numbers:
                for sep in separators:
                    predictions.add(f"{base}{sep}{num}.{domain}")
        
        # Remove already known subdomains
        known_set = set(known_subdomains)
        predictions = predictions - known_set
        
        return list(predictions)[:count]
    
    async def predict_with_openai(self, domain: str, known_subdomains: List[str]) -> List[str]:
        """Use OpenAI API for subdomain prediction (if API key available)"""
        if not self.api_key:
            return []
        
        try:
            import openai
            openai.api_key = self.api_key
            
            prompt = f"""Given the following known subdomains for {domain}:
{chr(10).join(known_subdomains[:20])}

Predict 20 additional likely subdomain names. Only output the subdomain names, one per line, without the domain suffix."""

            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.7
            )
            
            predictions = []
            for line in response.choices[0].message.content.strip().split('\n'):
                line = line.strip().lower()
                if line and domain not in line:
                    predictions.append(f"{line}.{domain}")
                elif line:
                    predictions.append(line)
            
            return predictions
        except Exception as e:
            logger.warning(f"OpenAI prediction error: {e}")
            return []


# ═══════════════════════════════════════════════════════════════════════════
# CONTINUOUS MONITOR
# ═══════════════════════════════════════════════════════════════════════════

class ContinuousMonitor:
    """
    Continuous monitoring and change detection
    """
    
    def __init__(self, domain: str, config: Config, db: DatabaseManager):
        self.domain = domain
        self.config = config
        self.db = db
        self.baseline = None
        self.notification_manager = NotificationManager(config)
        self.running = False
    
    async def start_monitoring(self, scanner):
        """Start continuous monitoring"""
        self.running = True
        logger.info(f"[Monitor] Starting continuous monitoring for {self.domain}")
        
        while self.running:
            try:
                # Run scan
                current_results = await scanner.run(self.domain)
                
                # Get baseline
                if not self.baseline:
                    self.baseline = self.db.get_last_scan(self.domain)
                
                if self.baseline:
                    # Detect changes
                    changes = self._detect_changes(self.baseline, current_results)
                    
                    if changes:
                        # Save changes
                        for change in changes:
                            self.db.save_change(
                                self.domain,
                                change['type'],
                                change.get('subdomain', ''),
                                json.dumps(change, default=str),
                                change.get('severity', 'info')
                            )
                        
                        # Send notifications
                        await self._notify_changes(changes)
                        
                        logger.warning(f"[Monitor] {len(changes)} changes detected!")
                
                # Save current results
                self.db.save_scan(current_results)
                self.baseline = current_results
                
            except Exception as e:
                logger.error(f"[Monitor] Error: {e}")
            
            # Wait for next scan
            await asyncio.sleep(self.config.MONITORING_INTERVAL_HOURS * 3600)
    
    def stop_monitoring(self):
        """Stop monitoring"""
        self.running = False
    
    def _detect_changes(self, baseline: Dict, current: Dict) -> List[Dict]:
        """Detect changes between scans"""
        changes = []
        
        baseline_subs = set(baseline.get('subdomains', {}).keys())
        current_subs = set(current.get('subdomains', {}).keys())
        
        # New subdomains
        new_subs = current_subs - baseline_subs
        for sub in new_subs:
            changes.append({
                'type': 'new_subdomain',
                'subdomain': sub,
                'severity': 'medium',
                'details': current['subdomains'].get(sub, {})
            })
        
        # Removed subdomains
        removed_subs = baseline_subs - current_subs
        for sub in removed_subs:
            changes.append({
                'type': 'removed_subdomain',
                'subdomain': sub,
                'severity': 'low'
            })
        
        # IP changes
        for sub in baseline_subs & current_subs:
            baseline_ips = set(baseline['subdomains'].get(sub, {}).get('ips', []))
            current_ips = set(current['subdomains'].get(sub, {}).get('ips', []))
            
            if baseline_ips != current_ips:
                changes.append({
                    'type': 'ip_change',
                    'subdomain': sub,
                    'severity': 'high',
                    'old_ips': list(baseline_ips),
                    'new_ips': list(current_ips)
                })
        
        # SSL certificate changes
        for sub in baseline_subs & current_subs:
            baseline_ssl = baseline['subdomains'].get(sub, {}).get('ssl_info', {})
            current_ssl = current['subdomains'].get(sub, {}).get('ssl_info', {})
            
            if (baseline_ssl.get('serial_number') != current_ssl.get('serial_number') 
                and baseline_ssl.get('serial_number')):
                changes.append({
                    'type': 'ssl_change',
                    'subdomain': sub,
                    'severity': 'medium',
                    'old_issuer': baseline_ssl.get('issuer'),
                    'new_issuer': current_ssl.get('issuer')
                })
        
        # New vulnerabilities
        for sub in current_subs:
            current_info = current['subdomains'].get(sub, {})
            if current_info.get('takeover_vulnerable'):
                baseline_info = baseline.get('subdomains', {}).get(sub, {})
                if not baseline_info.get('takeover_vulnerable'):
                    changes.append({
                        'type': 'new_takeover_vulnerability',
                        'subdomain': sub,
                        'severity': 'critical',
                        'takeover_type': current_info.get('takeover_type')
                    })
        
        return changes
    
    async def _notify_changes(self, changes: List[Dict]):
        """Send notifications for detected changes"""
        # Group by severity
        critical = [c for c in changes if c.get('severity') == 'critical']
        high = [c for c in changes if c.get('severity') == 'high']
        medium = [c for c in changes if c.get('severity') == 'medium']
        
        if critical:
            message = f"🚨 CRITICAL: {len(critical)} critical changes detected!\n"
            for c in critical[:5]:
                message += f"• {c['type']}: {c.get('subdomain', 'N/A')}\n"
            await self.notification_manager.send_notification(
                f"Critical Changes - {self.domain}", message, "critical"
            )
        
        if high:
            message = f"⚠️ HIGH: {len(high)} high severity changes detected!\n"
            for c in high[:5]:
                message += f"• {c['type']}: {c.get('subdomain', 'N/A')}\n"
            await self.notification_manager.send_notification(
                f"High Severity Changes - {self.domain}", message, "high"
            )


# ═══════════════════════════════════════════════════════════════════════════
# NUCLEI SCANNER INTEGRATION
# ═══════════════════════════════════════════════════════════════════════════

class NucleiScanner:
    """
    Integration with Nuclei for vulnerability scanning
    """
    
    def __init__(self, templates_dir: str = "nuclei-templates"):
        self.templates_dir = templates_dir
        self._check_nuclei_installed()
    
    def _check_nuclei_installed(self):
        """Check if Nuclei is installed"""
        try:
            result = subprocess.run(['nuclei', '-version'], 
                                   capture_output=True, text=True)
            if result.returncode == 0:
                logger.info(f"[Nuclei] Version: {result.stdout.strip()}")
            else:
                logger.warning("[Nuclei] Not found. Install with: go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest")
        except FileNotFoundError:
            logger.warning("[Nuclei] Not installed. Some features will be limited.")
    
    async def scan(self, targets: List[str], severity: List[str] = None,
                  templates: List[str] = None) -> List[Dict]:
        """Run Nuclei scan on targets"""
        vulnerabilities = []
        
        if not targets:
            return vulnerabilities
        
        severity = severity or ['critical', 'high', 'medium']
        
        # Create temporary target file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, 
                                         suffix='.txt') as f:
            f.write('\n'.join(targets))
            target_file = f.name
        
        try:
            # Build command
            cmd = [
                'nuclei',
                '-l', target_file,
                '-severity', ','.join(severity),
                '-json',
                '-silent'
            ]
            
            if templates:
                cmd.extend(['-t', ','.join(templates)])
            
            # Run Nuclei
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            # Parse results
            for line in stdout.decode().split('\n'):
                if line.strip():
                    try:
                        vuln = json.loads(line)
                        vulnerabilities.append({
                            'template': vuln.get('template-id', ''),
                            'name': vuln.get('info', {}).get('name', ''),
                            'severity': vuln.get('info', {}).get('severity', ''),
                            'host': vuln.get('host', ''),
                            'matched_at': vuln.get('matched-at', ''),
                            'description': vuln.get('info', {}).get('description', ''),
                            'references': vuln.get('info', {}).get('reference', []),
                            'cve_id': vuln.get('info', {}).get('classification', {}).get('cve-id', []),
                            'cvss_score': vuln.get('info', {}).get('classification', {}).get('cvss-score', 0)
                        })
                    except json.JSONDecodeError:
                        continue
            
            logger.info(f"[Nuclei] Found {len(vulnerabilities)} vulnerabilities")
            
        except Exception as e:
            logger.error(f"[Nuclei] Scan error: {e}")
        finally:
            os.unlink(target_file)
        
        return vulnerabilities
    
    async def scan_with_templates(self, targets: List[str], 
                                 template_tags: List[str]) -> List[Dict]:
        """Scan with specific template tags"""
        vulnerabilities = []
        
        if not targets:
            return vulnerabilities
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, 
                                         suffix='.txt') as f:
            f.write('\n'.join(targets))
            target_file = f.name
        
        try:
            cmd = [
                'nuclei',
                '-l', target_file,
                '-tags', ','.join(template_tags),
                '-json',
                '-silent'
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            for line in stdout.decode().split('\n'):
                if line.strip():
                    try:
                        vuln = json.loads(line)
                        vulnerabilities.append({
                            'template': vuln.get('template-id', ''),
                            'name': vuln.get('info', {}).get('name', ''),
                            'severity': vuln.get('info', {}).get('severity', ''),
                            'host': vuln.get('host', ''),
                            'matched_at': vuln.get('matched-at', '')
                        })
                    except:
                        continue
            
        except Exception as e:
            logger.error(f"[Nuclei] Template scan error: {e}")
        finally:
            os.unlink(target_file)
        
        return vulnerabilities


# ═══════════════════════════════════════════════════════════════════════════
# DARK WEB MONITOR
# ═══════════════════════════════════════════════════════════════════════════

class DarkWebMonitor:
    """
    Monitor dark web and paste sites for leaked credentials
    """
    
    def __init__(self, tor_proxy: str = "socks5h://127.0.0.1:9050"):
        self.tor_proxy = tor_proxy
        self.session = None
    
    async def check_paste_sites(self, domain: str) -> List[Dict]:
        """Check paste sites for domain mentions"""
        findings = []
        
        # Check Pastebin (via Google dorking since direct API is limited)
        # Check GitHub Gists
        findings.extend(await self._check_github_gists(domain))
        
        # Check other paste sites
        findings.extend(await self._check_paste_sites_api(domain))
        
        return findings
    
    async def _check_github_gists(self, domain: str) -> List[Dict]:
        """Check GitHub Gists for domain mentions"""
        findings = []
        
        try:
            async with aiohttp.ClientSession() as session:
                # Search GitHub for gists containing the domain
                url = f"https://api.github.com/search/code?q={domain}+extension:txt+extension:env+extension:config"
                headers = {'Accept': 'application/vnd.github.v3+json'}
                
                async with session.get(url, headers=headers, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()
                        for item in data.get('items', [])[:10]:
                            findings.append({
                                'source': 'GitHub',
                                'type': 'code_search',
                                'url': item.get('html_url', ''),
                                'file': item.get('name', ''),
                                'repository': item.get('repository', {}).get('full_name', '')
                            })
        except Exception as e:
            logger.debug(f"GitHub gist check error: {e}")
        
        return findings
    
    async def _check_paste_sites_api(self, domain: str) -> List[Dict]:
        """Check various paste sites"""
        findings = []
        
        paste_sites = [
            f"https://pastebin.com/raw/{domain}",  # This won't work directly, just placeholder
        ]
        
        # Note: Real implementation would require proper API access or scraping
        # This is a placeholder for the concept
        
        return findings
    
    async def check_haveibeenpwned(self, domain: str, api_key: str = None) -> List[Dict]:
        """Check HaveIBeenPwned for breaches (requires API key)"""
        breaches = []
        
        if not api_key:
            return breaches
        
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://haveibeenpwned.com/api/v3/breaches?domain={domain}"
                headers = {
                    'hibp-api-key': api_key,
                    'user-agent': 'ReconHunterPro-v5.0'
                }
                
                async with session.get(url, headers=headers, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()
                        for breach in data:
                            breaches.append({
                                'name': breach.get('Name'),
                                'title': breach.get('Title'),
                                'domain': breach.get('Domain'),
                                'breach_date': breach.get('BreachDate'),
                                'added_date': breach.get('AddedDate'),
                                'pwn_count': breach.get('PwnCount'),
                                'description': breach.get('Description'),
                                'data_classes': breach.get('DataClasses', []),
                                'is_verified': breach.get('IsVerified', False)
                            })
        except Exception as e:
            logger.debug(f"HaveIBeenPwned check error: {e}")
        
        return breaches


# ═══════════════════════════════════════════════════════════════════════════
# WHOIS & BGP ANALYZER
# ═══════════════════════════════════════════════════════════════════════════

class WhoisAnalyzer:
    """
    WHOIS and BGP analysis
    """
    
    @staticmethod
    async def get_whois(domain: str) -> Dict:
        """Get WHOIS information for domain"""
        result = {
            'domain': domain,
            'registrar': '',
            'creation_date': '',
            'expiration_date': '',
            'updated_date': '',
            'name_servers': [],
            'status': '',
            'emails': [],
            'organization': '',
            'country': '',
            'raw': ''
        }
        
        try:
            # Use python-whois if available
            import whois
            w = whois.whois(domain)
            
            result['registrar'] = w.registrar or ''
            result['creation_date'] = str(w.creation_date) if w.creation_date else ''
            result['expiration_date'] = str(w.expiration_date) if w.expiration_date else ''
            result['updated_date'] = str(w.updated_date) if w.updated_date else ''
            result['name_servers'] = w.name_servers or []
            result['status'] = w.status[0] if isinstance(w.status, list) else w.status or ''
            result['emails'] = w.emails or []
            result['organization'] = w.org or ''
            result['country'] = w.country or ''
            
        except ImportError:
            # Fallback to subprocess
            try:
                process = await asyncio.create_subprocess_exec(
                    'whois', domain,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                result['raw'] = stdout.decode('utf-8', errors='ignore')
                
                # Parse basic info from raw output
                raw = result['raw'].lower()
                
                # Extract registrar
                match = re.search(r'registrar:\s*(.+)', result['raw'], re.IGNORECASE)
                if match:
                    result['registrar'] = match.group(1).strip()
                
                # Extract emails
                emails = re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', result['raw'])
                result['emails'] = list(set(emails))
                
            except Exception as e:
                logger.debug(f"WHOIS error: {e}")
        except Exception as e:
            logger.debug(f"WHOIS error: {e}")
        
        return result
    
    @staticmethod
    async def get_bgp_info(ip: str) -> Dict:
        """Get BGP/ASN information for IP"""
        result = {
            'ip': ip,
            'asn': '',
            'as_name': '',
            'as_country': '',
            'as_range': '',
            'prefix': ''
        }
        
        try:
            # Use whois.cymru.com
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection('whois.cymru.com', 43),
                timeout=10
            )
            
            writer.write(f" -v {ip}\n".encode())
            await writer.drain()
            
            response = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            
            lines = response.decode().strip().split('\n')
            if len(lines) > 1:
                parts = lines[1].split('|')
                if len(parts) >= 5:
                    result['asn'] = parts[0].strip()
                    result['as_name'] = parts[6].strip() if len(parts) > 6 else ''
                    result['as_country'] = parts[1].strip()
                    result['as_range'] = parts[2].strip()
                    result['prefix'] = parts[2].strip()
            
        except Exception as e:
            logger.debug(f"BGP info error: {e}")
        
        return result


# ═══════════════════════════════════════════════════════════════════════════
# API SECURITY TESTER
# ═══════════════════════════════════════════════════════════════════════════

class APISecurityTester:
    """
    API security testing (GraphQL, REST)
    """
    
    def __init__(self, timeout: int = 15):
        self.timeout = timeout
    
    async def test_graphql_introspection(self, url: str) -> Dict:
        """Test GraphQL introspection"""
        result = {
            'url': url,
            'is_graphql': False,
            'introspection_enabled': False,
            'schema': None,
            'vulnerabilities': []
        }
        
        introspection_query = {
            "query": """
                {
                    __schema {
                        types {
                            name
                            kind
                            description
                        }
                    }
                }
            """
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=introspection_query, 
                                       timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        if '__schema' in str(data):
                            result['is_graphql'] = True
                            result['introspection_enabled'] = True
                            result['schema'] = data
                            result['vulnerabilities'].append({
                                'type': 'graphql_introspection',
                                'severity': 'medium',
                                'description': 'GraphQL introspection is enabled'
                            })
        except Exception as e:
            logger.debug(f"GraphQL test error: {e}")
        
        return result
    
    async def test_rest_api(self, base_url: str) -> Dict:
        """Test REST API endpoints"""
        result = {
            'url': base_url,
            'endpoints': [],
            'vulnerabilities': []
        }
        
        # Common API endpoints to check
        common_endpoints = [
            '/api', '/api/v1', '/api/v2', '/api/docs', '/api/swagger',
            '/swagger', '/swagger-ui', '/docs', '/redoc', '/openapi.json',
            '/api.json', '/graph', '/graphql', '/api/graphql',
            '/.well-known/openapi', '/api/openapi.json'
        ]
        
        try:
            async with aiohttp.ClientSession() as session:
                for endpoint in common_endpoints:
                    url = f"{base_url.rstrip('/')}{endpoint}"
                    try:
                        async with session.get(url, timeout=5, ssl=False) as response:
                            if response.status in [200, 201, 301, 302]:
                                content_type = response.headers.get('Content-Type', '')
                                result['endpoints'].append({
                                    'url': url,
                                    'status': response.status,
                                    'content_type': content_type
                                })
                                
                                # Check for exposed API docs
                                if 'swagger' in endpoint.lower() or 'docs' in endpoint.lower():
                                    if response.status == 200:
                                        result['vulnerabilities'].append({
                                            'type': 'exposed_api_docs',
                                            'severity': 'low',
                                            'url': url,
                                            'description': 'API documentation is publicly accessible'
                                        })
                    except:
                        continue
        except Exception as e:
            logger.debug(f"REST API test error: {e}")
        
        return result
    
    async def test_api_rate_limiting(self, url: str, requests: int = 50) -> Dict:
        """Test API rate limiting"""
        result = {
            'url': url,
            'rate_limited': False,
            'limit_threshold': None,
            'responses': []
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                tasks = []
                for i in range(requests):
                    tasks.append(session.get(url, timeout=5, ssl=False))
                
                responses = await asyncio.gather(*tasks, return_exceptions=True)
                
                status_codes = []
                for resp in responses:
                    if isinstance(resp, aiohttp.ClientResponse):
                        status_codes.append(resp.status)
                        resp.close()
                
                result['responses'] = status_codes
                
                # Check for rate limiting
                if 429 in status_codes:
                    result['rate_limited'] = True
                    result['limit_threshold'] = status_codes.index(429)
                elif status_codes.count(403) > len(status_codes) * 0.5:
                    result['rate_limited'] = True
                    
        except Exception as e:
            logger.debug(f"Rate limit test error: {e}")
        
        return result


# ═══════════════════════════════════════════════════════════════════════════
# SOCIAL MEDIA OSINT
# ═══════════════════════════════════════════════════════════════════════════

class SocialMediaOSINT:
    """
    Social media OSINT gathering
    """
    
    @staticmethod
    async def search_linkedin(company: str) -> List[Dict]:
        """Search LinkedIn for company employees (limited without API)"""
        results = []
        
        # Note: LinkedIn has strict scraping policies
        # This is a placeholder for the concept
        # Real implementation would use LinkedIn API
        
        return results
    
    @staticmethod
    async def search_github(domain: str) -> List[Dict]:
        """Search GitHub for repositories and code related to domain"""
        results = []
        
        try:
            async with aiohttp.ClientSession() as session:
                # Search for repositories
                url = f"https://api.github.com/search/repositories?q={domain}&sort=updated&per_page=20"
                headers = {'Accept': 'application/vnd.github.v3+json'}
                
                async with session.get(url, headers=headers, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()
                        for item in data.get('items', []):
                            results.append({
                                'type': 'repository',
                                'name': item.get('full_name', ''),
                                'description': item.get('description', ''),
                                'url': item.get('html_url', ''),
                                'stars': item.get('stargazers_count', 0),
                                'language': item.get('language', ''),
                                'updated_at': item.get('updated_at', '')
                            })
                
                # Search for code containing domain
                url = f"https://api.github.com/search/code?q={domain}&per_page=10"
                
                async with session.get(url, headers=headers, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()
                        for item in data.get('items', []):
                            results.append({
                                'type': 'code',
                                'file': item.get('name', ''),
                                'repository': item.get('repository', {}).get('full_name', ''),
                                'url': item.get('html_url', '')
                            })
                            
        except Exception as e:
            logger.debug(f"GitHub search error: {e}")
        
        return results
    
    @staticmethod
    def generate_email_patterns(domain: str, first_names: List[str], 
                               last_names: List[str]) -> List[str]:
        """Generate possible email patterns"""
        patterns = []
        
        # Common email patterns
        email_formats = [
            '{first}@{domain}',
            '{last}@{domain}',
            '{first}.{last}@{domain}',
            '{first}_{last}@{domain}',
            '{first}{last}@{domain}',
            '{f}{last}@{domain}',
            '{first}{l}@{domain}',
            '{f}.{last}@{domain}',
            '{first}.{l}@{domain}',
        ]
        
        for first in first_names:
            for last in last_names:
                for fmt in email_formats:
                    email = fmt.format(
                        first=first.lower(),
                        last=last.lower(),
                        f=first[0].lower() if first else '',
                        l=last[0].lower() if last else '',
                        domain=domain
                    )
                    patterns.append(email)
        
        return list(set(patterns))


# ═══════════════════════════════════════════════════════════════════════════
# INTERACTIVE DASHBOARD (HTML GENERATOR)
# ═══════════════════════════════════════════════════════════════════════════

class DashboardGenerator:
    """
    Generate interactive HTML dashboard
    """
    
    @staticmethod
    def generate_dashboard(results: Dict, output_path: str = None) -> str:
        """Generate interactive HTML dashboard"""
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recon Hunter Pro - Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1e3a 100%);
            color: #e1e8f0;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        header {{
            text-align: center;
            padding: 30px 0;
            border-bottom: 1px solid #2a2e4a;
            margin-bottom: 30px;
        }}
        
        h1 {{
            color: #00d4ff;
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .subtitle {{
            color: #7c8db5;
            font-size: 1.1em;
        }}
        
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .metric-card {{
            background: #1a1e3a;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            border: 1px solid #2a2e4a;
            transition: transform 0.3s, box-shadow 0.3s;
        }}
        
        .metric-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.1);
        }}
        
        .metric-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #00d4ff;
            margin-bottom: 10px;
        }}
        
        .metric-label {{
            color: #7c8db5;
            font-size: 0.9em;
        }}
        
        .metric-card.critical .metric-value {{
            color: #ff6b6b;
        }}
        
        .metric-card.warning .metric-value {{
            color: #ffd700;
        }}
        
        .metric-card.success .metric-value {{
            color: #7ee787;
        }}
        
        .charts-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .chart-card {{
            background: #1a1e3a;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #2a2e4a;
        }}
        
        .chart-title {{
            color: #00d4ff;
            font-size: 1.2em;
            margin-bottom: 15px;
        }}
        
        .table-container {{
            background: #1a1e3a;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #2a2e4a;
            margin-bottom: 30px;
            overflow-x: auto;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        
        th, td {{
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #2a2e4a;
        }}
        
        th {{
            background: #0a0e27;
            color: #00d4ff;
            font-weight: 600;
            position: sticky;
            top: 0;
        }}
        
        tr:hover {{
            background: #0a0e27;
        }}
        
        .status-badge {{
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
        }}
        
        .status-200 {{ background: #238636; color: white; }}
        .status-300 {{ background: #0066ff; color: white; }}
        .status-400 {{ background: #f85149; color: white; }}
        .status-500 {{ background: #da3633; color: white; }}
        
        .vulnerable {{
            color: #ff6b6b;
            font-weight: bold;
        }}
        
        .cdn-tag {{
            background: #7ee787;
            color: #0a0e27;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.8em;
        }}
        
        .waf-tag {{
            background: #ffa657;
            color: #0a0e27;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.8em;
        }}
        
        .search-box {{
            margin-bottom: 20px;
        }}
        
        .search-box input {{
            width: 100%;
            padding: 12px 20px;
            border: 1px solid #2a2e4a;
            border-radius: 8px;
            background: #0a0e27;
            color: #e1e8f0;
            font-size: 1em;
        }}
        
        .search-box input:focus {{
            outline: none;
            border-color: #00d4ff;
        }}
        
        .tabs {{
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }}
        
        .tab {{
            padding: 10px 20px;
            background: #1a1e3a;
            border: 1px solid #2a2e4a;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }}
        
        .tab:hover, .tab.active {{
            background: #00d4ff;
            color: #0a0e27;
        }}
        
        .tab-content {{
            display: none;
        }}
        
        .tab-content.active {{
            display: block;
        }}
        
        footer {{
            text-align: center;
            padding: 20px;
            border-top: 1px solid #2a2e4a;
            margin-top: 30px;
            color: #7c8db5;
        }}
        
        #network-graph {{
            width: 100%;
            height: 500px;
            background: #0a0e27;
            border-radius: 8px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🎯 Recon Hunter Pro - Dashboard</h1>
            <p class="subtitle">Target: {results.get('domain', 'N/A')} | Scan Level: {results.get('scan_level', 'N/A').upper()}</p>
            <p class="subtitle">Scan Time: {results.get('scan_time', 'N/A')} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </header>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-value">{results.get('summary', {}).get('total_subdomains', 0)}</div>
                <div class="metric-label">Total Subdomains</div>
            </div>
            <div class="metric-card success">
                <div class="metric-value">{results.get('summary', {}).get('alive_services', 0)}</div>
                <div class="metric-label">Live Services</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{results.get('summary', {}).get('unique_ips', 0)}</div>
                <div class="metric-label">Unique IPs</div>
            </div>
            <div class="metric-card warning">
                <div class="metric-value">{results.get('summary', {}).get('cdn_count', 0)}</div>
                <div class="metric-label">CDN Protected</div>
            </div>
            <div class="metric-card critical">
                <div class="metric-value">{results.get('summary', {}).get('takeover_vulnerable', 0)}</div>
                <div class="metric-label">Takeover Vulnerable</div>
            </div>
            <div class="metric-card critical">
                <div class="metric-value">{results.get('summary', {}).get('secrets_found', 0)}</div>
                <div class="metric-label">Secrets Found</div>
            </div>
        </div>
        
        <div class="tabs">
            <div class="tab active" onclick="showTab('overview')">Overview</div>
            <div class="tab" onclick="showTab('subdomains')">Subdomains</div>
            <div class="tab" onclick="showTab('security')">Security</div>
            <div class="tab" onclick="showTab('network')">Network Graph</div>
        </div>
        
        <div id="overview" class="tab-content active">
            <div class="charts-grid">
                <div class="chart-card">
                    <div class="chart-title">Status Code Distribution</div>
                    <canvas id="statusChart"></canvas>
                </div>
                <div class="chart-card">
                    <div class="chart-title">Technology Stack</div>
                    <canvas id="techChart"></canvas>
                </div>
                <div class="chart-card">
                    <div class="chart-title">Security Headers Score</div>
                    <canvas id="securityChart"></canvas>
                </div>
                <div class="chart-card">
                    <div class="chart-title">Port Distribution</div>
                    <canvas id="portChart"></canvas>
                </div>
            </div>
        </div>
        
        <div id="subdomains" class="tab-content">
            <div class="table-container">
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Search subdomains..." onkeyup="filterTable()">
                </div>
                <table id="subdomainTable">
                    <thead>
                        <tr>
                            <th>Subdomain</th>
                            <th>IP Addresses</th>
                            <th>Status</th>
                            <th>Title</th>
                            <th>Technologies</th>
                            <th>CDN/WAF</th>
                            <th>Takeover</th>
                        </tr>
                    </thead>
                    <tbody>
'''
        
        # Add subdomain rows
        for sub, info in sorted(results.get('subdomains', {}).items()):
            if info.get('status_code') or info.get('ips'):
                status_class = f"status-{str(info.get('status_code', 'xxx'))[0]}00"
                takeover_status = 'VULNERABLE' if info.get('takeover_vulnerable') else '-'
                takeover_class = 'vulnerable' if info.get('takeover_vulnerable') else ''
                
                cdn_waf = ''
                if info.get('cdn'):
                    cdn_waf += f'<span class="cdn-tag">{info["cdn"]}</span> '
                if info.get('waf'):
                    cdn_waf += f'<span class="waf-tag">{info["waf"]}</span>'
                
                html += f'''
                        <tr>
                            <td>{sub}</td>
                            <td>{', '.join(info.get('ips', [])[:3])}</td>
                            <td><span class="status-badge {status_class}">{info.get('status_code', '-')}</span></td>
                            <td>{info.get('title', '')[:50]}</td>
                            <td>{', '.join(info.get('technologies', [])[:3])}</td>
                            <td>{cdn_waf or '-'}</td>
                            <td class="{takeover_class}">{takeover_status}</td>
                        </tr>
'''
        
        html += '''
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="security" class="tab-content">
            <div class="table-container">
                <h3>Security Findings</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Subdomain</th>
                            <th>Severity</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
'''
        
        # Add security findings
        for sub, info in results.get('subdomains', {}).items():
            if info.get('takeover_vulnerable'):
                html += f'''
                        <tr>
                            <td>Subdomain Takeover</td>
                            <td>{sub}</td>
                            <td><span class="status-badge status-400">Critical</span></td>
                            <td>Vulnerable to takeover via {info.get('takeover_type', 'Unknown')}</td>
                        </tr>
'''
            
            if info.get('js_secrets'):
                for secret in info['js_secrets']:
                    html += f'''
                        <tr>
                            <td>Exposed Secret</td>
                            <td>{sub}</td>
                            <td><span class="status-badge status-400">High</span></td>
                            <td>{secret.get('type', 'Unknown')} found in JavaScript</td>
                        </tr>
'''
            
            if info.get('ssl_info', {}).get('expired'):
                html += f'''
                        <tr>
                            <td>SSL Certificate</td>
                            <td>{sub}</td>
                            <td><span class="status-badge status-400">High</span></td>
                            <td>Certificate has expired</td>
                        </tr>
'''
        
        html += '''
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="network" class="tab-content">
            <div class="chart-card">
                <div class="chart-title">Network Topology</div>
                <div id="network-graph"></div>
            </div>
        </div>
        
        <footer>
            <p>Recon Hunter Pro v5.0 - Ultimate Edition | Generated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </footer>
    </div>
    
    <script>
        // Tab switching
        function showTab(tabId) {{
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }}
        
        // Table filtering
        function filterTable() {{
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('subdomainTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let row of rows) {{
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            }}
        }}
        
        // Charts
        const ctx1 = document.getElementById('statusChart').getContext('2d');
        new Chart(ctx1, {{
            type: 'doughnut',
            data: {{
                labels: ['200 OK', '300 Redirect', '400 Client Error', '500 Server Error'],
                datasets: [{{
                    data: [
'''
        
        # Calculate status code distribution
        status_counts = {'200': 0, '300': 0, '400': 0, '500': 0}
        for sub, info in results.get('subdomains', {}).items():
            code = info.get('status_code')
            if code:
                if 200 <= code < 300:
                    status_counts['200'] += 1
                elif 300 <= code < 400:
                    status_counts['300'] += 1
                elif 400 <= code < 500:
                    status_counts['400'] += 1
                elif 500 <= code < 600:
                    status_counts['500'] += 1
        
        html += f'''
                        {status_counts['200']},
                        {status_counts['300']},
                        {status_counts['400']},
                        {status_counts['500']}
                    ],
                    backgroundColor: ['#238636', '#0066ff', '#f85149', '#da3633']
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{
                        labels: {{ color: '#e1e8f0' }}
                    }}
                }}
            }}
        }});
        
        // Technology Chart
        const ctx2 = document.getElementById('techChart').getContext('2d');
        new Chart(ctx2, {{
            type: 'bar',
            data: {{
                labels: {json.dumps(results.get('summary', {}).get('technologies', [])[:10])},
                datasets: [{{
                    label: 'Occurrences',
                    data: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    backgroundColor: '#00d4ff'
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{
                        labels: {{ color: '#e1e8f0' }}
                    }}
                }},
                scales: {{
                    y: {{
                        ticks: {{ color: '#e1e8f0' }},
                        grid: {{ color: '#2a2e4a' }}
                    }},
                    x: {{
                        ticks: {{ color: '#e1e8f0' }},
                        grid: {{ color: '#2a2e4a' }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
'''
        
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html)
        
        return html


# ═══════════════════════════════════════════════════════════════════════════
# MAIN SCANNER CLASS (Inherits from v4.0)
# ═══════════════════════════════════════════════════════════════════════════

# Import the base scanner from the enhanced version
# For brevity, we'll create a simplified version here

class UltimateReconScannerV5:
    """
    Ultimate reconnaissance scanner v5.0
    Integrates all modules including AI, monitoring, and Nuclei
    """
    
    def __init__(self, gui=None, scan_level = None, config: Config = None):
        self.gui = gui
        self.scan_level = scan_level or ScanLevel.NORMAL
        self.config = config or Config()
        self.results = {
            'domain': '',
            'scan_time': '',
            'scan_level': self.scan_level.value if hasattr(self.scan_level, 'value') else str(self.scan_level),
            'subdomains': {},
            'summary': {
                'total_subdomains': 0,
                'alive_services': 0,
                'unique_ips': 0,
                'cdn_count': 0,
                'real_ips': 0,
                'technologies': set(),
                'wafs_detected': set(),
                'takeover_vulnerable': 0,
                'secrets_found': 0,
                'cloud_buckets': 0,
                'vulnerabilities': 0
            }
        }
        
        self.db = DatabaseManager(self.config.DATABASE_PATH)
        self.notification_manager = NotificationManager(self.config)
        self.ai_predictor = AISubdomainPredictor(self.config.OPENAI_API_KEY)
        self.nuclei_scanner = NucleiScanner(self.config.NUCLEI_TEMPLATES_DIR)
        self.dark_web_monitor = DarkWebMonitor(self.config.TOR_PROXY)
        self.stop_flag = False
    
    def log(self, message: str, level: str = 'info'):
        """Log message to GUI and logger"""
        if self.gui:
            self.gui.log(message)
        
        if level == 'info':
            logger.info(message)
        elif level == 'warning':
            logger.warning(message)
        elif level == 'error':
            logger.error(message)
    
    async def run(self, domain: str, custom_wordlist: List[str] = None) -> Dict:
        """Execute complete reconnaissance scan"""
        start_time = datetime.now()
        self.results['domain'] = domain
        
        self.log(f"🚀 Starting ULTIMATE v5.0 reconnaissance scan for {domain}")
        self.log(f"⚙️  Scan Level: {self.scan_level.value if hasattr(self.scan_level, 'value') else self.scan_level}")
        self.log("=" * 70)
        
        # Phase 1: AI-Powered Subdomain Prediction
        self.log("🤖 [Phase 1/6] AI-Powered Analysis...")
        
        # Get historical data for AI
        history = self.db.get_scan_history(domain, 5)
        known_subs = []
        for h in history:
            if h.get('results_json'):
                try:
                    data = json.loads(h['results_json'])
                    known_subs.extend(data.get('subdomains', {}).keys())
                except:
                    pass
        
        if known_subs:
            predictions = self.ai_predictor.generate_predictions(domain, known_subs, 100)
            self.log(f"   AI predicted {len(predictions)} potential subdomains")
        
        # Phase 2: Passive Reconnaissance (would integrate with v4.0 engine)
        self.log("🔍 [Phase 2/6] Passive reconnaissance...")
        
        # Phase 3: Active Scanning
        self.log("🔬 [Phase 3/6] Active scanning...")
        
        # Phase 4: Nuclei Vulnerability Scanning
        if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE]:
            self.log("🎯 [Phase 4/6] Nuclei vulnerability scanning...")
            # Would run Nuclei on discovered targets
        
        # Phase 5: API Security Testing
        if self.scan_level == ScanLevel.ULTIMATE:
            self.log("🔌 [Phase 5/6] API security testing...")
            # Would test GraphQL, REST APIs
        
        # Phase 6: Dark Web & OSINT
        if self.scan_level == ScanLevel.ULTIMATE:
            self.log("🌐 [Phase 6/6] Dark web & OSINT gathering...")
            # Would check paste sites, breaches
        
        # Calculate scan time
        scan_duration = datetime.now() - start_time
        self.results['scan_time'] = str(scan_duration)
        
        # Save to database
        self.db.save_scan(self.results)
        
        # Send notification
        await self.notification_manager.send_notification(
            f"Scan Complete - {domain}",
            f"Found {self.results['summary']['total_subdomains']} subdomains, "
            f"{self.results['summary']['vulnerabilities']} vulnerabilities",
            "info"
        )
        
        self.log("\n" + "=" * 70)
        self.log("✅ Scan completed successfully!")
        self.log(f"⏱️  Total time: {scan_duration}")
        self.log("=" * 70)
        
        return self.results
    
    def stop(self):
        """Stop the scan"""
        self.stop_flag = True


class ScanLevel(Enum):
    """Scan intensity levels"""
    PASSIVE = "passive"
    NORMAL = "normal"
    AGGRESSIVE = "aggressive"
    STEALTH = "stealth"
    ULTIMATE = "ultimate"


# ═══════════════════════════════════════════════════════════════════════════
# GUI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════

class ReconHunterUltimateGUIV5:
    """
    Ultimate GUI for Recon Hunter Pro v5.0
    """
    
    def __init__(self, root):
        self.root = root
        self.root.title("🎯 Recon Hunter Pro - ULTIMATE Edition v5.0")
        self.root.geometry("1600x1000")
        self.root.configure(bg="#0a0e27")
        
        self.scanner = None
        self.results = None
        self.config = Config()
        self.db = DatabaseManager(self.config.DATABASE_PATH)
        self.monitor = None
        
        self._setup_styles()
        self._create_widgets()
        self._create_menu()
    
    def _setup_styles(self):
        """Setup custom styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("Title.TLabel", font=("JetBrains Mono", 18, "bold"),
                       foreground="#00d4ff", background="#0a0e27")
        style.configure("TLabel", font=("Segoe UI", 10),
                       foreground="#e1e8f0", background="#0a0e27")
    
    def _create_menu(self):
        """Create menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Save Results (JSON)", command=lambda: self.save_results('json'))
        file_menu.add_command(label="Generate Dashboard", command=self.generate_dashboard)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Settings menu
        settings_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Settings", menu=settings_menu)
        settings_menu.add_command(label="Configure API Keys", command=self.show_api_config)
        settings_menu.add_command(label="Configure Notifications", command=self.show_notification_config)
        
        # Monitoring menu
        monitor_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Monitoring", menu=monitor_menu)
        monitor_menu.add_command(label="Start Continuous Monitoring", command=self.start_monitoring)
        monitor_menu.add_command(label="Stop Monitoring", command=self.stop_monitoring)
        monitor_menu.add_separator()
        monitor_menu.add_command(label="View Scan History", command=self.view_history)
        
        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Nuclei Scan", command=self.run_nuclei)
        tools_menu.add_command(label="Dark Web Check", command=self.run_darkweb_check)
        tools_menu.add_command(label="API Security Test", command=self.run_api_test)
    
    def _create_widgets(self):
        """Create all GUI widgets"""
        main_container = tk.Frame(self.root, bg="#0a0e27")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_container, bg="#0a0e27")
        header_frame.pack(fill="x", pady=(0, 20))
        
        title = ttk.Label(header_frame, text="🎯 RECON HUNTER PRO - ULTIMATE v5.0",
                         style="Title.TLabel")
        title.pack()
        
        subtitle = ttk.Label(header_frame,
            text="AI-Powered | Continuous Monitoring | Nuclei Integration | Dashboard",
            font=("JetBrains Mono", 10), foreground="#7c8db5", background="#0a0e27")
        subtitle.pack()
        
        # Input Section
        input_frame = tk.LabelFrame(main_container, text="⚙️ Configuration",
                                   font=("Segoe UI", 11, "bold"),
                                   bg="#1a1e3a", fg="#00d4ff", bd=2, relief="groove")
        input_frame.pack(fill="x", pady=(0, 15))
        
        # Target domain
        target_frame = tk.Frame(input_frame, bg="#1a1e3a")
        target_frame.pack(fill="x", padx=15, pady=10)
        
        ttk.Label(target_frame, text="Target Domain:", background="#1a1e3a").pack(side="left", padx=(0, 10))
        self.domain_entry = ttk.Entry(target_frame, width=40, font=("Consolas", 11))
        self.domain_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        # Scan level
        scan_frame = tk.Frame(input_frame, bg="#1a1e3a")
        scan_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        ttk.Label(scan_frame, text="Scan Level:", background="#1a1e3a").pack(side="left", padx=(0, 20))
        
        self.scan_level_var = tk.StringVar(value="normal")
        
        levels = [
            ("🟢 Passive", "passive"),
            ("🟡 Normal", "normal"),
            ("🔴 Aggressive", "aggressive"),
            ("🟣 Ultimate", "ultimate")
        ]
        
        for text, value in levels:
            rb = ttk.Radiobutton(scan_frame, text=text, variable=self.scan_level_var,
                                value=value)
            rb.pack(side="left", padx=10)
        
        # Control buttons
        button_frame = tk.Frame(input_frame, bg="#1a1e3a")
        button_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        self.start_btn = tk.Button(button_frame, text="▶ START SCAN", command=self.start_scan,
                                  bg="#00aa00", fg="white", font=("Segoe UI", 10, "bold"),
                                  padx=20, pady=8, cursor="hand2", relief="flat")
        self.start_btn.pack(side="left", padx=5)
        
        self.stop_btn = tk.Button(button_frame, text="⏹ STOP", command=self.stop_scan,
                                 bg="#cc0000", fg="white", font=("Segoe UI", 10, "bold"),
                                 padx=20, pady=8, cursor="hand2", relief="flat", state="disabled")
        self.stop_btn.pack(side="left", padx=5)
        
        self.dashboard_btn = tk.Button(button_frame, text="📊 DASHBOARD", command=self.generate_dashboard,
                                      bg="#6b5ce7", fg="white", font=("Segoe UI", 10, "bold"),
                                      padx=20, pady=8, cursor="hand2", relief="flat")
        self.dashboard_btn.pack(side="left", padx=5)
        
        self.progress = ttk.Progressbar(button_frame, mode='indeterminate', length=200)
        self.progress.pack(side="right", padx=5)
        
        # Notebook for tabs
        self.notebook = ttk.Notebook(main_container)
        self.notebook.pack(fill="both", expand=True)
        
        # Tabs
        self._create_log_tab()
        self._create_summary_tab()
        self._create_security_tab()
        self._create_secrets_tab()
        self._create_monitoring_tab()
        
        # Status bar
        status_frame = tk.Frame(main_container, bg="#0a0e27", height=25)
        status_frame.pack(fill="x", pady=(10, 0))
        
        self.status_label = tk.Label(status_frame, text="⚪ Ready",
                                    font=("Segoe UI", 9), bg="#0a0e27", fg="#7c8db5", anchor="w")
        self.status_label.pack(side="left", fill="x", expand=True)
    
    def _create_log_tab(self):
        """Create log tab"""
        log_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(log_tab, text="📋 Live Logs")
        
        self.log_text = scrolledtext.ScrolledText(log_tab, height=20, font=("Consolas", 9),
                                                 bg="#0d1117", fg="#58a6ff",
                                                 insertbackground="#58a6ff", relief="flat", bd=0)
        self.log_text.pack(fill="both", expand=True, padx=5, pady=5)
    
    def _create_summary_tab(self):
        """Create summary tab"""
        summary_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(summary_tab, text="📊 Summary")
        
        self.summary_text = scrolledtext.ScrolledText(summary_tab, height=20, font=("Consolas", 9),
                                                     bg="#0d1117", fg="#c9d1d9",
                                                     insertbackground="#c9d1d9", relief="flat", bd=0)
        self.summary_text.pack(fill="both", expand=True, padx=5, pady=5)
    
    def _create_security_tab(self):
        """Create security tab"""
        security_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(security_tab, text="⚠️ Security")
        
        self.security_text = scrolledtext.ScrolledText(security_tab, height=20, font=("Consolas", 9),
                                                      bg="#0d1117", fg="#ff7b72",
                                                      insertbackground="#ff7b72", relief="flat", bd=0)
        self.security_text.pack(fill="both", expand=True, padx=5, pady=5)
    
    def _create_secrets_tab(self):
        """Create secrets tab"""
        secrets_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(secrets_tab, text="🔐 Secrets")
        
        self.secrets_text = scrolledtext.ScrolledText(secrets_tab, height=20, font=("Consolas", 9),
                                                     bg="#0d1117", fg="#ffd700",
                                                     insertbackground="#ffd700", relief="flat", bd=0)
        self.secrets_text.pack(fill="both", expand=True, padx=5, pady=5)
    
    def _create_monitoring_tab(self):
        """Create monitoring tab"""
        monitor_tab = tk.Frame(self.notebook, bg="#1a1e3a")
        self.notebook.add(monitor_tab, text="📡 Monitoring")
        
        self.monitor_text = scrolledtext.ScrolledText(monitor_tab, height=20, font=("Consolas", 9),
                                                     bg="#0d1117", fg="#7ee787",
                                                     insertbackground="#7ee787", relief="flat", bd=0)
        self.monitor_text.pack(fill="both", expand=True, padx=5, pady=5)
    
    def log(self, message: str):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def start_scan(self):
        """Start reconnaissance scan"""
        domain = self.domain_entry.get().strip()
        
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        self.log_text.delete(1.0, tk.END)
        self.results = None
        
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.progress.start(10)
        self.status_label.config(text="🟢 Scanning...", fg="#00ff00")
        
        scan_level_map = {
            'passive': ScanLevel.PASSIVE,
            'normal': ScanLevel.NORMAL,
            'aggressive': ScanLevel.AGGRESSIVE,
            'ultimate': ScanLevel.ULTIMATE
        }
        scan_level = scan_level_map[self.scan_level_var.get()]
        
        def run_scan():
            try:
                self.scanner = UltimateReconScannerV5(gui=self, scan_level=scan_level, 
                                                     config=self.config)
                results = asyncio.run(self.scanner.run(domain))
                
                self.results = results
                self.root.after(0, self.display_results)
                self.root.after(0, self.status_label.config, 
                              {'text': '✅ Scan completed', 'fg': '#00ff00'})
                
            except Exception as e:
                self.log(f"❌ Error: {str(e)}")
                logger.exception("Scan error")
                self.root.after(0, messagebox.showerror, "Error", f"Scan failed: {e}")
            
            finally:
                self.root.after(0, self.start_btn.config, {'state': 'normal'})
                self.root.after(0, self.stop_btn.config, {'state': 'disabled'})
                self.root.after(0, self.progress.stop)
        
        threading.Thread(target=run_scan, daemon=True).start()
    
    def stop_scan(self):
        """Stop ongoing scan"""
        if self.scanner:
            self.scanner.stop()
        self.progress.stop()
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.status_label.config(text="⏸️ Stopped", fg="#ff7b72")
        self.log("⏹️ Scan stopped by user")
    
    def display_results(self):
        """Display scan results"""
        if not self.results:
            return
        
        # Display summary
        self.summary_text.delete(1.0, tk.END)
        summary = self.results.get('summary', {})
        
        self.summary_text.insert(tk.END, f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                    ULTIMATE v5.0 RECONNAISSANCE SUMMARY                    ║
╚═══════════════════════════════════════════════════════════════════════════╝

📌 TARGET: {self.results.get('domain', 'N/A')}
⏱️  SCAN TIME: {self.results.get('scan_time', 'N/A')}

📊 METRICS:
   • Total Subdomains: {summary.get('total_subdomains', 0)}
   • Live Services: {summary.get('alive_services', 0)}
   • Unique IPs: {summary.get('unique_ips', 0)}
   • CDN Protected: {summary.get('cdn_count', 0)}

🔒 SECURITY:
   • Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)}
   • Secrets Found: {summary.get('secrets_found', 0)}
   • Vulnerabilities: {summary.get('vulnerabilities', 0)}
""")
    
    def generate_dashboard(self):
        """Generate interactive dashboard"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to display!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("HTML files", "*.html")]
        )
        
        if filename:
            DashboardGenerator.generate_dashboard(self.results, filename)
            messagebox.showinfo("Success", f"Dashboard saved to {filename}")
            
            # Open in browser
            import webbrowser
            webbrowser.open(f"file://{os.path.abspath(filename)}")
    
    def start_monitoring(self):
        """Start continuous monitoring"""
        domain = self.domain_entry.get().strip()
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        self.config.ENABLE_CONTINUOUS_MONITORING = True
        self.monitor = ContinuousMonitor(domain, self.config, self.db)
        
        def run_monitor():
            asyncio.run(self.monitor.start_monitoring(self.scanner))
        
        threading.Thread(target=run_monitor, daemon=True).start()
        self.log(f"📡 Started continuous monitoring for {domain}")
    
    def stop_monitoring(self):
        """Stop continuous monitoring"""
        if self.monitor:
            self.monitor.stop_monitoring()
            self.log("📡 Stopped continuous monitoring")
    
    def view_history(self):
        """View scan history"""
        domain = self.domain_entry.get().strip()
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        history = self.db.get_scan_history(domain, 10)
        
        self.monitor_text.delete(1.0, tk.END)
        self.monitor_text.insert(tk.END, f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                         SCAN HISTORY FOR {domain:<30}║
╚═══════════════════════════════════════════════════════════════════════════╝

""")
        
        for h in history:
            self.monitor_text.insert(tk.END, 
                f"📅 {h['created_at']} | Level: {h['scan_level']} | "
                f"Subdomains: {h['total_subdomains']} | Live: {h['alive_services']}\n")
    
    def run_nuclei(self):
        """Run Nuclei scan"""
        messagebox.showinfo("Nuclei", "Nuclei scan will run on discovered targets during aggressive/ultimate scans.")
    
    def run_darkweb_check(self):
        """Run dark web check"""
        domain = self.domain_entry.get().strip()
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        self.log("🌐 Checking dark web and paste sites...")
        
        async def check():
            results = await self.dark_web_monitor.check_paste_sites(domain)
            return results
        
        results = asyncio.run(check())
        
        self.secrets_text.delete(1.0, tk.END)
        self.secrets_text.insert(tk.END, "🌐 Dark Web & Paste Site Check Results\n\n")
        
        for r in results:
            self.secrets_text.insert(tk.END, f"• [{r['source']}] {r.get('url', r.get('file', 'N/A'))}\n")
    
    def run_api_test(self):
        """Run API security test"""
        messagebox.showinfo("API Test", "API security testing runs automatically during Ultimate scans.")
    
    def show_api_config(self):
        """Show API configuration dialog"""
        config_window = tk.Toplevel(self.root)
        config_window.title("API Configuration")
        config_window.geometry("500x500")
        config_window.configure(bg="#1a1e3a")
        
        apis = [
            ("Shodan API Key", "SHODAN_API_KEY"),
            ("Censys API ID", "CENSYS_API_ID"),
            ("Censys API Secret", "CENSYS_API_SECRET"),
            ("SecurityTrails API Key", "SECURITYTRAILS_API_KEY"),
            ("VirusTotal API Key", "VIRUSTOTAL_API_KEY"),
            ("OpenAI API Key", "OPENAI_API_KEY"),
            ("HaveIBeenPwned API Key", "HAVEIBEENPWNED_API_KEY"),
        ]
        
        entries = {}
        for i, (label, key) in enumerate(apis):
            tk.Label(config_window, text=label, bg="#1a1e3a", fg="#e1e8f0").grid(
                row=i, column=0, padx=10, pady=5, sticky="w")
            entry = ttk.Entry(config_window, width=40, show="*")
            entry.grid(row=i, column=1, padx=10, pady=5)
            entry.insert(0, getattr(self.config, key, ""))
            entries[key] = entry
        
        def save_config():
            for key, entry in entries.items():
                setattr(self.config, key, entry.get())
            config_window.destroy()
            messagebox.showinfo("Success", "API keys saved!")
        
        tk.Button(config_window, text="Save", command=save_config, 
                 bg="#0066ff", fg="white").grid(row=len(apis), column=0, columnspan=2, pady=20)
    
    def show_notification_config(self):
        """Show notification configuration dialog"""
        config_window = tk.Toplevel(self.root)
        config_window.title("Notification Configuration")
        config_window.geometry("500x400")
        config_window.configure(bg="#1a1e3a")
        
        notifications = [
            ("Slack Webhook URL", "SLACK_WEBHOOK_URL"),
            ("Discord Webhook URL", "DISCORD_WEBHOOK_URL"),
            ("Telegram Bot Token", "TELEGRAM_BOT_TOKEN"),
            ("Telegram Chat ID", "TELEGRAM_CHAT_ID"),
            ("Custom Webhook URL", "CUSTOM_WEBHOOK_URL"),
        ]
        
        entries = {}
        for i, (label, key) in enumerate(notifications):
            tk.Label(config_window, text=label, bg="#1a1e3a", fg="#e1e8f0").grid(
                row=i, column=0, padx=10, pady=5, sticky="w")
            entry = ttk.Entry(config_window, width=40)
            entry.grid(row=i, column=1, padx=10, pady=5)
            entry.insert(0, getattr(self.config, key, ""))
            entries[key] = entry
        
        def save_config():
            for key, entry in entries.items():
                setattr(self.config, key, entry.get())
            config_window.destroy()
            messagebox.showinfo("Success", "Notification settings saved!")
        
        tk.Button(config_window, text="Save", command=save_config, 
                 bg="#0066ff", fg="white").grid(row=len(notifications), column=0, columnspan=2, pady=20)
    
    def save_results(self, format_type: str):
        """Save results in specified format"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to save!")
            return
        
        if format_type == 'json':
            filename = filedialog.asksaveasfilename(
                defaultextension=".json",
                filetypes=[("JSON files", "*.json")]
            )
            if filename:
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(self.results, f, indent=2, default=str)
                messagebox.showinfo("Success", f"Results saved to {filename}")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

def main():
    """Main entry point"""
    try:
        root = tk.Tk()
        app = ReconHunterUltimateGUIV5(root)
        
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - (root.winfo_width() // 2)
        y = (root.winfo_screenheight() // 2) - (root.winfo_height() // 2)
        root.geometry(f'+{x}+{y}')
        
        root.mainloop()
        
    except Exception as e:
        logger.exception("Application error")
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║          🎯 RECON HUNTER PRO - ULTIMATE EDITION v5.0 🎯                   ║
║                                                                           ║
║              AI-Powered Reconnaissance & OSINT Framework                  ║
║         Continuous Monitoring | Nuclei | Dashboard | Notifications        ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

[*] Initializing application...
[*] Loading modules...
[*] Starting GUI...

""")
    main()
║                                                                           ║
