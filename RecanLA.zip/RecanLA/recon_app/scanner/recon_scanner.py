#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Main Reconnaissance Scanner for Recon Hunter Pro
"""

import asyncio
import logging
from datetime import datetime
from typing import Set, Dict, List, Optional, Any
from dataclasses import asdict

from ..config import Config
from ..models.data_models import SubdomainInfo, ScanLevel, ScanResult
from ..core.dns_resolver import DNSResolver
from ..core.dns_bruteforce import DNSBruteForcer
from ..core.passive_recon import PassiveReconEngine
from ..detection.waf_detector import WAFDetector
from ..detection.cdn_detector import CDNDetector
from ..detection.tech_detector import TechnologyDetector
from ..detection.takeover_detector import TakeoverDetector
from ..analysis.port_scanner import PortScanner
from ..analysis.vulnerability_analyzer import VulnerabilityAnalyzer

logger = logging.getLogger(__name__)


class ReconScanner:
    """
    Main reconnaissance scanner that integrates all modules
    """
    
    def __init__(
        self,
        config: Config = None,
        scan_level: ScanLevel = ScanLevel.NORMAL,
        gui_callback=None
    ):
        """
        Initialize the reconnaissance scanner
        
        Args:
            config: Configuration object
            scan_level: Scan intensity level
            gui_callback: Callback function for GUI updates
        """
        self.config = config or Config()
        self.scan_level = scan_level
        self.gui_callback = gui_callback
        self._stop_flag = False
        
        # Initialize components
        self.dns_resolver = DNSResolver()
        self.passive_recon = None
        self.dns_bruteforcer = None
    
    def log(self, message: str, level: str = 'info'):
        """Log message to GUI and logger"""
        if self.gui_callback:
            self.gui_callback(message)
        
        if level == 'info':
            logger.info(message)
        elif level == 'warning':
            logger.warning(message)
        elif level == 'error':
            logger.error(message)
    
    def stop(self):
        """Stop the scan"""
        self._stop_flag = True
        self.log("Stop requested...")
    
    async def enumerate_subdomains(self, domain: str) -> Set[str]:
        """
        Enumerate subdomains using passive and active methods
        
        Args:
            domain: Target domain
        
        Returns:
            Set of discovered subdomains
        """
        all_subdomains = set()
        
        # Phase 1: Passive Reconnaissance
        self.log("Phase 1: Running passive reconnaissance...")
        self.passive_recon = PassiveReconEngine(domain, timeout=self.config.TIMEOUT)
        passive_subs = await self.passive_recon.run_all()
        all_subdomains.update(passive_subs)
        self.log(f"Passive recon completed: {len(passive_subs)} subdomains found")
        
        if self._stop_flag:
            return all_subdomains
        
        # Phase 2: DNS Bruteforce (if not passive only)
        if self.scan_level != ScanLevel.PASSIVE:
            self.log("Phase 2: Running DNS bruteforce...")
            self.dns_bruteforcer = DNSBruteForcer(domain, self.dns_resolver)
            brute_subs = await self.dns_bruteforcer.bruteforce()
            all_subdomains.update(brute_subs)
            self.log(f"DNS bruteforce completed: {len(brute_subs)} new subdomains found")
        
        if self._stop_flag:
            return all_subdomains
        
        # Phase 3: Permutation (if aggressive)
        if self.scan_level == ScanLevel.AGGRESSIVE:
            self.log("Phase 3: Generating and testing permutations...")
            permutations = self.dns_bruteforcer.generate_permutations(all_subdomains)
            self.log(f"Generated {len(permutations)} permutations, testing...")
            
            valid_perms = set()
            for perm in list(permutations)[:500]:  # Limit permutations
                if self._stop_flag:
                    break
                ips = await self.dns_resolver.resolve(perm)
                if ips:
                    valid_perms.add(perm)
            
            all_subdomains.update(valid_perms)
            self.log(f"Permutation testing completed: {len(valid_perms)} valid permutations")
        
        return all_subdomains
    
    async def analyze_subdomain(self, subdomain: str) -> SubdomainInfo:
        """
        Analyze a single subdomain
        
        Args:
            subdomain: Subdomain to analyze
        
        Returns:
            SubdomainInfo object with analysis results
        """
        info = SubdomainInfo(domain=subdomain)
        
        try:
            # DNS Resolution
            dns_records = await self.dns_resolver.resolve_all(subdomain)
            info.ips = dns_records.get('A', []) + dns_records.get('AAAA', [])
            info.cnames = dns_records.get('CNAME', [])
            info.mx_records = dns_records.get('MX', [])
            info.txt_records = dns_records.get('TXT', [])
            
            if not info.ips:
                return info
            
            # CDN Detection
            for ip in info.ips:
                is_cdn, provider = CDNDetector.detect_cdn(ip)
                if is_cdn:
                    info.cdn = provider
                    break
            
            # HTTP Probing (if not passive only)
            if self.scan_level != ScanLevel.PASSIVE:
                http_result = await self._probe_http(subdomain, info.ips[0] if info.ips else None)
                
                if http_result:
                    info.status_code = http_result.get('status_code')
                    info.title = http_result.get('title', '')
                    info.server = http_result.get('server', '')
                    info.technologies = http_result.get('technologies', [])
                    info.content_length = http_result.get('content_length', 0)
                    
                    # WAF Detection
                    if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE]:
                        info.waf = await WAFDetector.detect(http_result.get('url', ''))
            
            # Port Scanning (aggressive mode only)
            if self.scan_level in [ScanLevel.AGGRESSIVE, ScanLevel.ULTIMATE] and info.ips and not info.cdn:
                port_results = await PortScanner.scan(info.ips[0])
                info.open_ports = [p.port for p in port_results if p.is_open]
            
            # Takeover Detection
            if info.cnames:
                is_vulnerable, service = await TakeoverDetector.check_cname_takeover(info.cnames[0])
                if is_vulnerable:
                    info.takeover_vulnerable = True
                    info.takeover_type = service
        
        except Exception as e:
            logger.debug(f"Error analyzing {subdomain}: {e}")
        
        return info
    
    async def _probe_http(self, subdomain: str, real_ip: str = None) -> Optional[Dict]:
        """
        Probe subdomain for HTTP services
        
        Args:
            subdomain: Subdomain to probe
            real_ip: Real IP to use (bypassing CDN)
        
        Returns:
            Dictionary with HTTP probe results
        """
        import aiohttp
        from datetime import datetime
        
        result = {}
        
        for protocol in ['https', 'http']:
            try:
                url = f"{protocol}://{real_ip or subdomain}"
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Host': subdomain,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
                
                timeout = aiohttp.ClientTimeout(total=self.config.HTTP_TIMEOUT)
                
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    start_time = datetime.now()
                    
                    async with session.get(
                        url,
                        headers=headers,
                        ssl=False,
                        allow_redirects=True
                    ) as response:
                        result['url'] = url
                        result['status_code'] = response.status
                        result['headers'] = dict(response.headers)
                        result['server'] = response.headers.get('Server', 'Unknown')
                        
                        content = await response.text()
                        result['content_length'] = len(content)
                        
                        # Extract title
                        import re
                        match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
                        if match:
                            result['title'] = match.group(1).strip()[:200]
                        
                        # Detect technologies
                        cookies = {k: v.value for k, v in response.cookies.items()}
                        result['technologies'] = TechnologyDetector.detect(
                            content,
                            result['headers'],
                            cookies
                        )
                        
                        return result
            
            except asyncio.TimeoutError:
                logger.debug(f"Timeout probing {subdomain} with {protocol}")
            except Exception as e:
                logger.debug(f"Error probing {subdomain}: {e}")
        
        return None
    
    async def run(self, domain: str) -> Dict:
        """
        Run the full reconnaissance scan
        
        Args:
            domain: Target domain
        
        Returns:
            Dictionary with all findings
        """
        start_time = datetime.now()
        self._stop_flag = False
        
        self.log(f"Starting reconnaissance scan for {domain}")
        self.log(f"Scan level: {self.scan_level.value}")
        
        result = {
            'domain': domain,
            'scan_level': self.scan_level.value,
            'start_time': start_time.isoformat(),
            'end_time': '',
            'duration': '',
            'status': 'pending',
            'error': None,
            'subdomains': {},
            'summary': {
                'total_subdomains': 0,
                'alive_services': 0,
                'unique_ips': [],
                'cdn_count': 0,
                'technologies': [],
                'wafs': [],
                'takeover_vulnerable': 0,
                'secrets_found': 0,
                'cloud_buckets': 0,
                'vulnerabilities': 0
            }
        }
        
        try:
            # Enumerate subdomains
            subdomains = await self.enumerate_subdomains(domain)
            result['summary']['total_subdomains'] = len(subdomains)
            self.log(f"Total subdomains discovered: {len(subdomains)}")
            
            if self._stop_flag:
                result['status'] = 'stopped'
                return result
            
            # Analyze each subdomain
            self.log("Analyzing discovered subdomains...")
            
            subdomain_list = sorted(list(subdomains))
            batch_size = 10
            
            unique_ips = set()
            technologies = set()
            wafs = set()
            
            for i in range(0, len(subdomain_list), batch_size):
                if self._stop_flag:
                    break
                
                batch = subdomain_list[i:i + batch_size]
                self.log(f"Analyzing batch {i // batch_size + 1}/{(len(subdomain_list) + batch_size - 1) // batch_size}...")
                
                tasks = [self.analyze_subdomain(sub) for sub in batch]
                batch_results = await asyncio.gather(*tasks)
                
                for subdomain_info in batch_results:
                    result['subdomains'][subdomain_info.domain] = asdict(subdomain_info)
                    
                    # Update summary
                    if subdomain_info.ips:
                        unique_ips.update(subdomain_info.ips)
                    if subdomain_info.status_code:
                        result['summary']['alive_services'] += 1
                    if subdomain_info.cdn:
                        result['summary']['cdn_count'] += 1
                    if subdomain_info.technologies:
                        technologies.update(subdomain_info.technologies)
                    if subdomain_info.waf:
                        wafs.add(subdomain_info.waf)
                    if subdomain_info.takeover_vulnerable:
                        result['summary']['takeover_vulnerable'] += 1
            
            # Convert sets to lists for JSON serialization
            result['summary']['unique_ips'] = list(unique_ips)
            result['summary']['technologies'] = list(technologies)
            result['summary']['wafs'] = list(wafs)
            
            result['status'] = 'completed'
            self.log("Scan completed successfully!")
        
        except Exception as e:
            result['status'] = 'error'
            result['error'] = str(e)
            self.log(f"Scan error: {e}", level='error')
            logger.exception("Scan error")
        
        finally:
            result['end_time'] = datetime.now().isoformat()
            result['duration'] = str(datetime.now() - start_time)
        
        return result