#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GUI Application for Recon Hunter Pro
"""

import sys
import os
import asyncio
import threading
import json
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

from ..config import Config
from ..models.data_models import ScanLevel
from ..scanner.recon_scanner import ReconScanner
from ..output.dashboard_generator import DashboardGenerator
from ..output.report_generator import ReportGenerator


class ReconHunterApp:
    """
    Main GUI Application for Recon Hunter Pro
    """
    
    def __init__(self, root: tk.Tk = None):
        """Initialize the application"""
        self.root = root or tk.Tk()
        self.root.title("Recon Hunter Pro - Enterprise Edition")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1a1e3a")
        
        # Configuration
        self.config = Config()
        self.scanner = None
        self.results = None
        
        # Setup UI
        self._setup_styles()
        self._create_menu()
        self._create_main_frame()
        self._create_input_section()
        self._create_control_section()
        self._create_notebook()
        self._create_status_bar()
    
    def _setup_styles(self):
        """Setup custom styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure styles
        style.configure('TFrame', background='#1a1e3a')
        style.configure('TLabel', background='#1a1e3a', foreground='#e1e8f0')
        style.configure('TButton', background='#0066ff', foreground='white')
        style.configure('TEntry', fieldbackground='#0d1117', foreground='#e1e8f0')
        style.configure('TCombobox', fieldbackground='#0d1117', foreground='#e1e8f0')
        style.configure('TNotebook', background='#1a1e3a')
        style.configure('TNotebook.Tab', background='#21262d', foreground='#e1e8f0')
        style.map('TNotebook.Tab', background=[('selected', '#0066ff')])
    
    def _create_menu(self):
        """Create menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Scan", command=self._new_scan)
        file_menu.add_separator()
        file_menu.add_command(label="Export JSON", command=lambda: self._export_results('json'))
        file_menu.add_command(label="Export CSV", command=lambda: self._export_results('csv'))
        file_menu.add_command(label="Export TXT", command=lambda: self._export_results('txt'))
        file_menu.add_command(label="Export Markdown", command=lambda: self._export_results('md'))
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Settings menu
        settings_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Settings", menu=settings_menu)
        settings_menu.add_command(label="API Configuration", command=self._show_api_config)
        settings_menu.add_command(label="Scan Options", command=self._show_scan_options)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self._show_about)
    
    def _create_main_frame(self):
        """Create main frame"""
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def _create_input_section(self):
        """Create input section"""
        input_frame = ttk.Frame(self.main_frame)
        input_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Domain input
        ttk.Label(input_frame, text="Target Domain:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.domain_var = tk.StringVar()
        self.domain_entry = ttk.Entry(input_frame, textvariable=self.domain_var, width=50)
        self.domain_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        # Scan level
        ttk.Label(input_frame, text="Scan Level:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.scan_level_var = tk.StringVar(value='normal')
        scan_levels = ['passive', 'normal', 'aggressive']
        self.scan_level_combo = ttk.Combobox(
            input_frame,
            textvariable=self.scan_level_var,
            values=scan_levels,
            state='readonly',
            width=15
        )
        self.scan_level_combo.pack(side=tk.LEFT)
    
    def _create_control_section(self):
        """Create control section"""
        control_frame = ttk.Frame(self.main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Start button
        self.start_btn = ttk.Button(
            control_frame,
            text="Start Scan",
            command=self._start_scan
        )
        self.start_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # Stop button
        self.stop_btn = ttk.Button(
            control_frame,
            text="Stop Scan",
            command=self._stop_scan,
            state=tk.DISABLED
        )
        self.stop_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # Generate dashboard button
        self.dashboard_btn = ttk.Button(
            control_frame,
            text="Generate Dashboard",
            command=self._generate_dashboard
        )
        self.dashboard_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress = ttk.Progressbar(
            control_frame,
            variable=self.progress_var,
            maximum=100,
            length=300
        )
        self.progress.pack(side=tk.RIGHT)
    
    def _create_notebook(self):
        """Create notebook with tabs"""
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Log tab
        log_frame = ttk.Frame(self.notebook)
        self.notebook.add(log_frame, text="Log")
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=20,
            font=("Consolas", 10),
            bg="#0d1117",
            fg="#7ee787",
            insertbackground="#7ee787",
            relief=tk.FLAT
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Summary tab
        summary_frame = ttk.Frame(self.notebook)
        self.notebook.add(summary_frame, text="Summary")
        
        self.summary_text = scrolledtext.ScrolledText(
            summary_frame,
            height=20,
            font=("Consolas", 10),
            bg="#0d1117",
            fg="#e1e8f0",
            insertbackground="#e1e8f0",
            relief=tk.FLAT
        )
        self.summary_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Subdomains tab
        subdomains_frame = ttk.Frame(self.notebook)
        self.notebook.add(subdomains_frame, text="Subdomains")
        
        # Create treeview for subdomains
        columns = ('subdomain', 'status', 'ips', 'cdn', 'waf', 'technologies')
        self.subdomains_tree = ttk.Treeview(
            subdomains_frame,
            columns=columns,
            show='headings',
            height=20
        )
        
        for col in columns:
            self.subdomains_tree.heading(col, text=col.title())
            self.subdomains_tree.column(col, width=150)
        
        scrollbar = ttk.Scrollbar(
            subdomains_frame,
            orient=tk.VERTICAL,
            command=self.subdomains_tree.yview
        )
        self.subdomains_tree.configure(yscrollcommand=scrollbar.set)
        
        self.subdomains_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def _create_status_bar(self):
        """Create status bar"""
        self.status_frame = ttk.Frame(self.root)
        self.status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        
        self.status_label = ttk.Label(
            self.status_frame,
            text="Ready",
            foreground='#00ff00'
        )
        self.status_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        self.time_label = ttk.Label(
            self.status_frame,
            text="",
            foreground='#8b949e'
        )
        self.time_label.pack(side=tk.RIGHT, padx=10, pady=5)
    
    def log(self, message: str):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def _start_scan(self):
        """Start the scan"""
        domain = self.domain_var.get().strip()
        
        if not domain:
            messagebox.showerror("Error", "Please enter a target domain!")
            return
        
        # Clear previous results
        self.log_text.delete(1.0, tk.END)
        self.summary_text.delete(1.0, tk.END)
        for item in self.subdomains_tree.get_children():
            self.subdomains_tree.delete(item)
        
        self.results = None
        
        # Update UI
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Scanning...", foreground='#ffff00')
        
        # Get scan level
        scan_level_map = {
            'passive': ScanLevel.PASSIVE,
            'normal': ScanLevel.NORMAL,
            'aggressive': ScanLevel.AGGRESSIVE
        }
        scan_level = scan_level_map[self.scan_level_var.get()]
        
        # Run scan in thread
        def run_scan():
            try:
                self.scanner = ReconScanner(
                    config=self.config,
                    scan_level=scan_level,
                    gui_callback=self.log
                )
                
                # Run async scan
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                self.results = loop.run_until_complete(self.scanner.run(domain))
                loop.close()
                
                # Update UI on completion
                self.root.after(0, self._display_results)
                self.root.after(0, lambda: self.status_label.config(
                    text="Completed",
                    foreground='#00ff00'
                ))
            
            except Exception as e:
                self.log(f"Error: {str(e)}")
                self.root.after(0, lambda: self.status_label.config(
                    text="Error",
                    foreground='#ff0000'
                ))
            
            finally:
                self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
                self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))
        
        thread = threading.Thread(target=run_scan, daemon=True)
        thread.start()
    
    def _stop_scan(self):
        """Stop the scan"""
        if self.scanner:
            self.scanner.stop()
        self.status_label.config(text="Stopped", foreground='#ff7b72')
    
    def _display_results(self):
        """Display scan results"""
        if not self.results:
            return
        
        # Display summary
        summary = self.results.summary if hasattr(self.results, 'summary') else {}
        
        summary_text = f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                    RECON HUNTER PRO - SCAN SUMMARY                         ║
╚═══════════════════════════════════════════════════════════════════════════╝

Target: {self.results.domain}
Scan Level: {self.results.scan_level}
Duration: {self.results.duration}

METRICS:
   • Total Subdomains: {summary.get('total_subdomains', 0)}
   • Live Services: {summary.get('alive_services', 0)}
   • Unique IPs: {len(summary.get('unique_ips', []))}
   • CDN Protected: {summary.get('cdn_count', 0)}
   • Technologies: {len(summary.get('technologies', []))}
   • WAFs Detected: {len(summary.get('wafs', []))}
   • Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)}
"""
        
        self.summary_text.delete(1.0, tk.END)
        self.summary_text.insert(tk.END, summary_text)
        
        # Display subdomains
        subdomains = self.results.subdomains if hasattr(self.results, 'subdomains') else {}
        
        for subdomain, info in sorted(subdomains.items()):
            status = info.get('status_code', '-')
            ips = ', '.join(info.get('ips', [])[:2])
            cdn = info.get('cdn', '-')
            waf = info.get('waf', '-')
            techs = ', '.join(info.get('technologies', [])[:3])
            
            self.subdomains_tree.insert('', tk.END, values=(
                subdomain,
                status,
                ips,
                cdn,
                waf,
                techs
            ))
    
    def _generate_dashboard(self):
        """Generate HTML dashboard"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to display!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("HTML files", "*.html")],
            title="Save Dashboard"
        )
        
        if filename:
            # Convert results to dict if needed
            from dataclasses import asdict
            if hasattr(self.results, '__dict__'):
                results_dict = {
                    'domain': self.results.domain,
                    'scan_level': self.results.scan_level,
                    'summary': self.results.summary,
                    'subdomains': self.results.subdomains
                }
            else:
                results_dict = self.results
            
            DashboardGenerator.generate_dashboard(results_dict, filename)
            messagebox.showinfo("Success", f"Dashboard saved to {filename}")
            
            # Open in browser
            import webbrowser
            webbrowser.open(f"file://{os.path.abspath(filename)}")
    
    def _export_results(self, format_type: str):
        """Export results to file"""
        if not self.results:
            messagebox.showwarning("Warning", "No results to export!")
            return
        
        # Convert results to dict
        from dataclasses import asdict
        if hasattr(self.results, '__dict__'):
            results_dict = {
                'domain': self.results.domain,
                'scan_level': self.results.scan_level,
                'summary': self.results.summary,
                'subdomains': self.results.subdomains
            }
        else:
            results_dict = self.results
        
        format_map = {
            'json': ('JSON files', '*.json', ReportGenerator.to_json),
            'csv': ('CSV files', '*.csv', ReportGenerator.to_csv),
            'txt': ('Text files', '*.txt', ReportGenerator.to_txt),
            'md': ('Markdown files', '*.md', ReportGenerator.to_markdown)
        }
        
        if format_type not in format_map:
            return
        
        file_type, extension, export_func = format_map[format_type]
        
        filename = filedialog.asksaveasfilename(
            defaultextension=extension,
            filetypes=[(file_type, extension)],
            title=f"Export as {format_type.upper()}"
        )
        
        if filename:
            export_func(results_dict, filename)
            messagebox.showinfo("Success", f"Results exported to {filename}")
    
    def _new_scan(self):
        """Reset for new scan"""
        self.domain_var.set('')
        self.log_text.delete(1.0, tk.END)
        self.summary_text.delete(1.0, tk.END)
        for item in self.subdomains_tree.get_children():
            self.subdomains_tree.delete(item)
        self.results = None
        self.status_label.config(text="Ready", foreground='#00ff00')
    
    def _show_api_config(self):
        """Show API configuration dialog"""
        config_window = tk.Toplevel(self.root)
        config_window.title("API Configuration")
        config_window.geometry("500x400")
        config_window.configure(bg="#1a1e3a")
        
        apis = [
            ("Shodan API Key", "SHODAN_API_KEY"),
            ("Censys API ID", "CENSYS_API_ID"),
            ("Censys API Secret", "CENSYS_API_SECRET"),
            ("SecurityTrails API Key", "SECURITYTRAILS_API_KEY"),
            ("VirusTotal API Key", "VIRUSTOTAL_API_KEY"),
        ]
        
        entries = {}
        for i, (label, key) in enumerate(apis):
            tk.Label(
                config_window,
                text=label,
                bg="#1a1e3a",
                fg="#e1e8f0"
            ).grid(row=i, column=0, padx=10, pady=5, sticky="w")
            
            entry = ttk.Entry(config_window, width=40, show="*")
            entry.grid(row=i, column=1, padx=10, pady=5)
            entry.insert(0, getattr(self.config, key, ""))
            entries[key] = entry
        
        def save_config():
            for key, entry in entries.items():
                setattr(self.config, key, entry.get())
            config_window.destroy()
            messagebox.showinfo("Success", "API keys saved!")
        
        tk.Button(
            config_window,
            text="Save",
            command=save_config,
            bg="#0066ff",
            fg="white"
        ).grid(row=len(apis), column=0, columnspan=2, pady=20)
    
    def _show_scan_options(self):
        """Show scan options dialog"""
        options_window = tk.Toplevel(self.root)
        options_window.title("Scan Options")
        options_window.geometry("400x300")
        options_window.configure(bg="#1a1e3a")
        
        options = [
            ("Request Timeout", "REQUEST_TIMEOUT", "30"),
            ("Max Concurrent Requests", "MAX_CONCURRENT", "100"),
            ("DNS Timeout", "DNS_TIMEOUT", "5"),
        ]
        
        entries = {}
        for i, (label, key, default) in enumerate(options):
            tk.Label(
                options_window,
                text=label,
                bg="#1a1e3a",
                fg="#e1e8f0"
            ).grid(row=i, column=0, padx=10, pady=5, sticky="w")
            
            entry = ttk.Entry(options_window, width=20)
            entry.grid(row=i, column=1, padx=10, pady=5)
            entry.insert(0, str(getattr(self.config, key, default)))
            entries[key] = entry
        
        def save_options():
            for key, entry in entries.items():
                try:
                    value = int(entry.get())
                    setattr(self.config, key, value)
                except ValueError:
                    pass
            options_window.destroy()
            messagebox.showinfo("Success", "Options saved!")
        
        tk.Button(
            options_window,
            text="Save",
            command=save_options,
            bg="#0066ff",
            fg="white"
        ).grid(row=len(options), column=0, columnspan=2, pady=20)
    
    def _show_about(self):
        """Show about dialog"""
        messagebox.showinfo(
            "About Recon Hunter Pro",
            "Recon Hunter Pro - Enterprise Edition v4.0\n\n"
            "Advanced Reconnaissance & OSINT Framework\n\n"
            "Features:\n"
            "• Multi-Source Passive Recon\n"
            "• DNS Enumeration & Bruteforce\n"
            "• WAF & CDN Detection\n"
            "• Technology Fingerprinting\n"
            "• Subdomain Takeover Detection\n"
            "• Interactive Dashboard Generation\n\n"
            "Built for Security Professionals"
        )
    
    def run(self):
        """Run the application"""
        self.root.mainloop()


def main():
    """Main entry point for GUI"""
    root = tk.Tk()
    app = ReconHunterApp(root)
    
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (root.winfo_width() // 2)
    y = (root.winfo_screenheight() // 2) - (root.winfo_height() // 2)
    root.geometry(f'+{x}+{y}')
    
    app.run()


if __name__ == "__main__":
    main()