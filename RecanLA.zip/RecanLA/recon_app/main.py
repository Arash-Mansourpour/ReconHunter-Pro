#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Recon Hunter Pro - Enterprise Edition
Main Entry Point

Advanced Reconnaissance & OSINT Framework
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    """Main entry point"""
    print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║           RECON HUNTER PRO - ENTERPRISE EDITION v4.0                      ║
║           Advanced Reconnaissance & OSINT Framework                        ║
╚═══════════════════════════════════════════════════════════════════════════╝

[*] Initializing application...
""")
    
    # Check for CLI mode
    if len(sys.argv) > 1:
        run_cli()
    else:
        run_gui()


def run_gui():
    """Run GUI application"""
    try:
        from gui.app import ReconHunterApp
        import tkinter as tk
        
        root = tk.Tk()
        app = ReconHunterApp(root)
        
        # Center window
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - (root.winfo_width() // 2)
        y = (root.winfo_screenheight() // 2) - (root.winfo_height() // 2)
        root.geometry(f'+{x}+{y}')
        
        print("[*] Starting GUI...")
        app.run()
        
    except ImportError as e:
        print(f"[!] Error loading GUI: {e}")
        print("[*] Falling back to CLI mode...")
        run_cli()
    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit(1)


def run_cli():
    """Run CLI application"""
    import asyncio
    import argparse
    import json
    from datetime import datetime
    
    from config import Config
    from models.data_models import ScanLevel
    from scanner.recon_scanner import ReconScanner
    from output.report_generator import ReportGenerator
    from output.dashboard_generator import DashboardGenerator
    
    parser = argparse.ArgumentParser(
        description='Recon Hunter Pro - Advanced Reconnaissance Framework'
    )
    parser.add_argument(
        'domain',
        help='Target domain to scan'
    )
    parser.add_argument(
        '-l', '--level',
        choices=['passive', 'normal', 'aggressive'],
        default='normal',
        help='Scan level (default: normal)'
    )
    parser.add_argument(
        '-o', '--output',
        help='Output directory for results'
    )
    parser.add_argument(
        '-f', '--format',
        choices=['json', 'csv', 'txt', 'md', 'all'],
        default='json',
        help='Output format (default: json)'
    )
    parser.add_argument(
        '--dashboard',
        action='store_true',
        help='Generate HTML dashboard'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Verbose output'
    )
    
    args = parser.parse_args()
    
    # Setup
    config = Config()
    
    scan_level_map = {
        'passive': ScanLevel.PASSIVE,
        'normal': ScanLevel.NORMAL,
        'aggressive': ScanLevel.AGGRESSIVE
    }
    scan_level = scan_level_map[args.level]
    
    def log_callback(message):
        """Log callback for scanner"""
        print(f"[*] {message}")
    
    # Run scan
    print(f"""
[*] Target: {args.domain}
[*] Scan Level: {args.level}
[*] Starting scan...
""")
    
    scanner = ReconScanner(
        config=config,
        scan_level=scan_level,
        gui_callback=log_callback if args.verbose else None
    )
    
    # Run async scan
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    results = loop.run_until_complete(scanner.run(args.domain))
    loop.close()
    
    # Display summary
    summary = results.summary if hasattr(results, 'summary') else {}
    
    print(f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                           SCAN COMPLETED                                   ║
╚═══════════════════════════════════════════════════════════════════════════╝

📊 RESULTS:
   • Total Subdomains: {summary.get('total_subdomains', 0)}
   • Live Services: {summary.get('alive_services', 0)}
   • Unique IPs: {len(summary.get('unique_ips', []))}
   • CDN Protected: {summary.get('cdn_count', 0)}
   • Technologies: {len(summary.get('technologies', []))}
   • WAFs Detected: {len(summary.get('wafs', []))}
   • Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)}
   • Duration: {results.duration}
""")
    
    # Save results
    if args.output:
        output_dir = args.output
    else:
        output_dir = '.'
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Convert results to dict
    results_dict = {
        'domain': results.domain,
        'scan_level': results.scan_level,
        'start_time': results.start_time,
        'end_time': results.end_time,
        'duration': results.duration,
        'summary': results.summary,
        'subdomains': results.subdomains
    }
    
    base_name = f"recon_{args.domain.replace('.', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    if args.format == 'all':
        files = ReportGenerator.generate_all(results_dict, output_dir, base_name)
        print(f"\n[*] Reports saved:")
        for fmt, path in files.items():
            print(f"    • {fmt.upper()}: {path}")
    else:
        output_path = os.path.join(output_dir, f"{base_name}.{args.format}")
        
        format_map = {
            'json': ReportGenerator.to_json,
            'csv': ReportGenerator.to_csv,
            'txt': ReportGenerator.to_txt,
            'md': ReportGenerator.to_markdown
        }
        
        if args.format in format_map:
            format_map[args.format](results_dict, output_path)
            print(f"\n[*] Results saved to: {output_path}")
    
    # Generate dashboard
    if args.dashboard:
        dashboard_path = os.path.join(output_dir, f"{base_name}_dashboard.html")
        DashboardGenerator.generate_dashboard(results_dict, dashboard_path)
        print(f"[*] Dashboard saved to: {dashboard_path}")
    
    print("\n[*] Done!")


if __name__ == "__main__":
    main()