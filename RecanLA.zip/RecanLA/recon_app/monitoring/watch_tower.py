#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Watch Tower - Continuous Monitoring System for Recon Hunter Pro
Monitors domains for changes and alerts on new findings
"""

import asyncio
import json
import os
import logging
import smtplib
from datetime import datetime, timedelta
from typing import Dict, List, Set, Optional, Any
from dataclasses import dataclass, asdict, field
from email.message import EmailMessage
import aiohttp

logger = logging.getLogger(__name__)


@dataclass
class Alert:
    """Alert data model"""
    timestamp: str
    alert_type: str
    severity: str  # critical, high, medium, low, info
    domain: str
    title: str
    description: str
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)


class ChangeDetector:
    """
    Detects changes between scan results
    Compares current scan with previous scan to identify new findings
    """
    
    @staticmethod
    def detect_changes(old_results: Dict, new_results: Dict) -> List[Alert]:
        """
        Detect all changes between old and new scan results
        
        Args:
            old_results: Previous scan results
            new_results: Current scan results
        
        Returns:
            List of Alert objects for detected changes
        """
        alerts = []
        domain = new_results.get('domain', 'unknown')
        timestamp = datetime.now().isoformat()
        
        # Get subdomain sets
        old_subs = set(old_results.get('subdomains', {}).keys()) if old_results else set()
        new_subs = set(new_results.get('subdomains', {}).keys())
        
        # 1. New subdomains detected
        new_subdomains = new_subs - old_subs
        for sub in new_subdomains:
            sub_info = new_results['subdomains'].get(sub, {})
            alerts.append(Alert(
                timestamp=timestamp,
                alert_type='new_subdomain',
                severity='medium',
                domain=domain,
                title=f'New Subdomain: {sub}',
                description=f'A new subdomain was discovered: {sub}',
                details={
                    'subdomain': sub,
                    'ips': sub_info.get('ips', []),
                    'status_code': sub_info.get('status_code'),
                    'technologies': sub_info.get('technologies', [])
                }
            ))
        
        # 2. Removed subdomains
        removed_subdomains = old_subs - new_subs
        for sub in removed_subdomains:
            alerts.append(Alert(
                timestamp=timestamp,
                alert_type='removed_subdomain',
                severity='low',
                domain=domain,
                title=f'Subdomain Removed: {sub}',
                description=f'A subdomain is no longer resolving: {sub}',
                details={'subdomain': sub}
            ))
        
        # 3. New takeover vulnerabilities
        for sub, info in new_results.get('subdomains', {}).items():
            if info.get('takeover_vulnerable'):
                old_info = old_results.get('subdomains', {}).get(sub, {}) if old_results else {}
                if not old_info.get('takeover_vulnerable'):
                    alerts.append(Alert(
                        timestamp=timestamp,
                        alert_type='takeover_vulnerable',
                        severity='critical',
                        domain=domain,
                        title=f'Takeover Vulnerability: {sub}',
                        description=f'Subdomain {sub} is vulnerable to takeover via {info.get("takeover_type", "unknown service")}',
                        details={
                            'subdomain': sub,
                            'takeover_type': info.get('takeover_type'),
                            'cnames': info.get('cnames', [])
                        }
                    ))
        
        # 4. New secrets found
        old_secrets_count = 0
        if old_results:
            for sub_info in old_results.get('subdomains', {}).values():
                old_secrets_count += len(sub_info.get('js_secrets', []))
        
        new_secrets = []
        for sub, info in new_results.get('subdomains', {}).items():
            for secret in info.get('js_secrets', []):
                old_info = old_results.get('subdomains', {}).get(sub, {}) if old_results else {}
                old_secret_types = [s.get('type') for s in old_info.get('js_secrets', [])]
                if secret.get('type') not in old_secret_types:
                    new_secrets.append({
                        'subdomain': sub,
                        'secret_type': secret.get('type'),
                        'value': secret.get('value', '')[:50] + '...'
                    })
        
        for secret in new_secrets:
            alerts.append(Alert(
                timestamp=timestamp,
                alert_type='secret_exposed',
                severity='high',
                domain=domain,
                title=f"Exposed Secret: {secret['secret_type']}",
                description=f"Found exposed {secret['secret_type']} in {secret['subdomain']}",
                details=secret
            ))
        
        # 5. New cloud buckets
        for sub, info in new_results.get('subdomains', {}).items():
            new_buckets = info.get('cloud_buckets', [])
            old_buckets = old_results.get('subdomains', {}).get(sub, {}).get('cloud_buckets', []) if old_results else []
            
            for bucket in new_buckets:
                if bucket not in old_buckets:
                    alerts.append(Alert(
                        timestamp=timestamp,
                        alert_type='cloud_bucket',
                        severity='high',
                        domain=domain,
                        title=f"Cloud Bucket Exposed: {bucket.get('provider', 'Unknown')}",
                        description=f"Found exposed cloud storage bucket on {sub}",
                        details={
                            'subdomain': sub,
                            'bucket': bucket
                        }
                    ))
        
        # 6. New open ports (for aggressive scans)
        for sub, info in new_results.get('subdomains', {}).items():
            new_ports = set(info.get('open_ports', []))
            old_ports = set(old_results.get('subdomains', {}).get(sub, {}).get('open_ports', [])) if old_results else set()
            
            new_open_ports = new_ports - old_ports
            for port in new_open_ports:
                alerts.append(Alert(
                    timestamp=timestamp,
                    alert_type='new_open_port',
                    severity='medium',
                    domain=domain,
                    title=f"New Open Port: {sub}:{port}",
                    description=f"New open port detected on {sub}",
                    details={
                        'subdomain': sub,
                        'port': port,
                        'ip': info.get('ips', ['unknown'])[0] if info.get('ips') else 'unknown'
                    }
                ))
        
        # 7. Status code changes
        for sub, info in new_results.get('subdomains', {}).items():
            new_status = info.get('status_code')
            old_status = old_results.get('subdomains', {}).get(sub, {}).get('status_code') if old_results else None
            
            if new_status != old_status:
                # Only alert on significant changes
                if (new_status and new_status >= 400) or (old_status and old_status < 400 and new_status and new_status >= 400):
                    alerts.append(Alert(
                        timestamp=timestamp,
                        alert_type='status_change',
                        severity='medium' if new_status and new_status < 500 else 'high',
                        domain=domain,
                        title=f"Status Change: {sub} ({old_status} -> {new_status})",
                        description=f"HTTP status code changed for {sub}",
                        details={
                            'subdomain': sub,
                            'old_status': old_status,
                            'new_status': new_status
                        }
                    ))
        
        # 8. New WAF detected
        for sub, info in new_results.get('subdomains', {}).items():
            new_waf = info.get('waf')
            old_waf = old_results.get('subdomains', {}).get(sub, {}).get('waf') if old_results else None
            
            if new_waf and new_waf != old_waf:
                alerts.append(Alert(
                    timestamp=timestamp,
                    alert_type='waf_detected',
                    severity='info',
                    domain=domain,
                    title=f"WAF Detected: {sub}",
                    description=f"New WAF detected on {sub}: {new_waf}",
                    details={
                        'subdomain': sub,
                        'waf': new_waf
                    }
                ))
        
        # 9. SSL Certificate changes
        for sub, info in new_results.get('subdomains', {}).items():
            new_ssl = info.get('ssl_info', {})
            old_ssl = old_results.get('subdomains', {}).get(sub, {}).get('ssl_info', {}) if old_results else {}
            
            # Check for expired certificate
            if new_ssl.get('expired') and not old_ssl.get('expired'):
                alerts.append(Alert(
                    timestamp=timestamp,
                    alert_type='ssl_expired',
                    severity='high',
                    domain=domain,
                    title=f"SSL Expired: {sub}",
                    description=f"SSL certificate has expired for {sub}",
                    details={
                        'subdomain': sub,
                        'issuer': new_ssl.get('issuer'),
                        'expired_date': new_ssl.get('not_after')
                    }
                ))
            
            # Check for certificate issuer change
            if new_ssl.get('issuer') and old_ssl.get('issuer') and new_ssl.get('issuer') != old_ssl.get('issuer'):
                alerts.append(Alert(
                    timestamp=timestamp,
                    alert_type='ssl_change',
                    severity='low',
                    domain=domain,
                    title=f"SSL Changed: {sub}",
                    description=f"SSL certificate issuer changed for {sub}",
                    details={
                        'subdomain': sub,
                        'old_issuer': old_ssl.get('issuer'),
                        'new_issuer': new_ssl.get('issuer')
                    }
                ))
        
        return alerts


class HistoryManager:
    """
    Manages scan history storage and retrieval
    Uses JSON files for persistence (no external database required)
    """
    
    def __init__(self, output_dir: str = "watchtower_history"):
        """
        Initialize history manager
        
        Args:
            output_dir: Directory to store history files
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def _get_domain_file(self, domain: str) -> str:
        """Get history file path for a domain"""
        safe_domain = domain.replace('.', '_').replace(':', '_')
        return os.path.join(self.output_dir, f"{safe_domain}_history.json")
    
    def save_scan(self, domain: str, results: Dict) -> str:
        """
        Save scan results to history
        
        Args:
            domain: Target domain
            results: Scan results dictionary
        
        Returns:
            Path to saved file
        """
        history_file = self._get_domain_file(domain)
        
        # Load existing history
        history = self.load_history(domain)
        
        # Add new scan
        scan_record = {
            'timestamp': datetime.now().isoformat(),
            'domain': domain,
            'scan_level': results.get('scan_level', 'unknown'),
            'summary': results.get('summary', {}),
            'results_file': f"{domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        }
        
        history.append(scan_record)
        
        # Save history index
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2, default=str)
        
        # Save full results
        results_file = os.path.join(self.output_dir, scan_record['results_file'])
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"[WatchTower] Saved scan results for {domain}")
        return results_file
    
    def load_history(self, domain: str, limit: int = 100) -> List[Dict]:
        """
        Load scan history for a domain
        
        Args:
            domain: Target domain
            limit: Maximum number of records to return
        
        Returns:
            List of scan records
        """
        history_file = self._get_domain_file(domain)
        
        if not os.path.exists(history_file):
            return []
        
        try:
            with open(history_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
            return history[-limit:]
        except Exception as e:
            logger.error(f"Error loading history for {domain}: {e}")
            return []
    
    def get_last_scan(self, domain: str) -> Optional[Dict]:
        """
        Get the most recent scan results for a domain
        
        Args:
            domain: Target domain
        
        Returns:
            Last scan results or None
        """
        history = self.load_history(domain, 1)
        if not history:
            return None
        
        last_scan = history[-1]
        results_file = os.path.join(self.output_dir, last_scan.get('results_file', ''))
        
        if os.path.exists(results_file):
            try:
                with open(results_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading last scan for {domain}: {e}")
        
        return None
    
    def cleanup_old_scans(self, domain: str, keep_days: int = 30):
        """
        Remove scans older than specified days
        
        Args:
            domain: Target domain
            keep_days: Number of days to keep
        """
        history = self.load_history(domain)
        cutoff = datetime.now() - timedelta(days=keep_days)
        
        new_history = []
        for record in history:
            try:
                scan_time = datetime.fromisoformat(record['timestamp'])
                if scan_time > cutoff:
                    new_history.append(record)
                else:
                    # Delete old results file
                    results_file = os.path.join(self.output_dir, record.get('results_file', ''))
                    if os.path.exists(results_file):
                        os.remove(results_file)
            except Exception:
                new_history.append(record)  # Keep if can't parse
        
        # Save cleaned history
        history_file = self._get_domain_file(domain)
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(new_history, f, indent=2, default=str)


class NotificationManager:
    """
    Handles notifications for alerts
    Supports email, webhooks, and console output
    """
    
    def __init__(self, config):
        """
        Initialize notification manager
        
        Args:
            config: Configuration object with notification settings
        """
        self.config = config
    
    async def send_alert(self, alert: Alert):
        """
        Send alert through configured channels
        
        Args:
            alert: Alert object to send
        """
        # Always log to console
        self._log_alert(alert)
        
        # Send email if configured
        if self.config.EMAIL_SMTP_SERVER and self.config.EMAIL_RECIPIENTS:
            await self._send_email_alert(alert)
        
        # Send to webhooks
        if self.config.SLACK_WEBHOOK_URL:
            await self._send_webhook_alert(alert, 'slack')
        
        if self.config.DISCORD_WEBHOOK_URL:
            await self._send_webhook_alert(alert, 'discord')
        
        if self.config.TELEGRAM_BOT_TOKEN and self.config.TELEGRAM_CHAT_ID:
            await self._send_telegram_alert(alert)
        
        if self.config.CUSTOM_WEBHOOK_URL:
            await self._send_webhook_alert(alert, 'custom')
    
    def _log_alert(self, alert: Alert):
        """Log alert to console"""
        severity_icons = {
            'critical': '🔴',
            'high': '🟠',
            'medium': '🟡',
            'low': '🟢',
            'info': '🔵'
        }
        icon = severity_icons.get(alert.severity, '⚪')
        
        log_msg = f"{icon} [{alert.severity.upper()}] {alert.title}"
        logger.info(log_msg)
        print(f"\n{icon} ALERT: {alert.title}")
        print(f"   Type: {alert.alert_type}")
        print(f"   Description: {alert.description}")
    
    async def _send_email_alert(self, alert: Alert):
        """Send alert via email"""
        try:
            msg = EmailMessage()
            msg['Subject'] = f"[WatchTower] {alert.title}"
            msg['From'] = self.config.EMAIL_USERNAME
            msg['To'] = ', '.join(self.config.EMAIL_RECIPIENTS)
            
            body = f"""
Watch Tower Alert

Domain: {alert.domain}
Type: {alert.alert_type}
Severity: {alert.severity}
Time: {alert.timestamp}

{alert.description}

Details:
{json.dumps(alert.details, indent=2, default=str)}
"""
            msg.set_content(body)
            
            # Send email (run in executor to avoid blocking)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._send_email_sync, msg)
            
        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")
    
    def _send_email_sync(self, msg: EmailMessage):
        """Synchronous email sending"""
        with smtplib.SMTP(self.config.EMAIL_SMTP_SERVER, self.config.EMAIL_SMTP_PORT) as server:
            server.starttls()
            server.login(self.config.EMAIL_USERNAME, self.config.EMAIL_PASSWORD)
            server.send_message(msg)
    
    async def _send_webhook_alert(self, alert: Alert, webhook_type: str):
        """Send alert to webhook"""
        try:
            if webhook_type == 'slack':
                url = self.config.SLACK_WEBHOOK_URL
                payload = {
                    'text': f"[WatchTower Alert] {alert.title}",
                    'attachments': [{
                        'color': 'danger' if alert.severity in ['critical', 'high'] else 'warning',
                        'fields': [
                            {'title': 'Domain', 'value': alert.domain, 'short': True},
                            {'title': 'Severity', 'value': alert.severity, 'short': True},
                            {'title': 'Type', 'value': alert.alert_type, 'short': True},
                            {'title': 'Description', 'value': alert.description, 'short': False}
                        ]
                    }]
                }
            elif webhook_type == 'discord':
                url = self.config.DISCORD_WEBHOOK_URL
                payload = {
                    'content': f"**[WatchTower Alert]** {alert.title}",
                    'embeds': [{
                        'title': alert.alert_type,
                        'description': alert.description,
                        'color': 0xff0000 if alert.severity == 'critical' else 0xffa500,
                        'fields': [
                            {'name': 'Domain', 'value': alert.domain, 'inline': True},
                            {'name': 'Severity', 'value': alert.severity, 'inline': True}
                        ]
                    }]
                }
            else:  # custom
                url = self.config.CUSTOM_WEBHOOK_URL
                payload = alert.to_dict()
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as response:
                    if response.status not in [200, 204]:
                        logger.warning(f"Webhook returned status {response.status}")
        
        except Exception as e:
            logger.error(f"Failed to send webhook alert: {e}")
    
    async def _send_telegram_alert(self, alert: Alert):
        """Send alert via Telegram"""
        try:
            url = f"https://api.telegram.org/bot{self.config.TELEGRAM_BOT_TOKEN}/sendMessage"
            
            text = f"""
🚨 *WatchTower Alert*

*Domain:* {alert.domain}
*Type:* {alert.alert_type}
*Severity:* {alert.severity}
*Title:* {alert.title}

{alert.description}
"""
            
            payload = {
                'chat_id': self.config.TELEGRAM_CHAT_ID,
                'text': text,
                'parse_mode': 'Markdown'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as response:
                    if response.status != 200:
                        logger.warning(f"Telegram returned status {response.status}")
        
        except Exception as e:
            logger.error(f"Failed to send Telegram alert: {e}")


class WatchTower:
    """
    Main Watch Tower monitoring system
    Runs continuous scans and detects changes
    """
    
    def __init__(self, config, scanner_class, domains: List[str] = None):
        """
        Initialize Watch Tower
        
        Args:
            config: Configuration object
            scanner_class: Scanner class to use for scans
            domains: List of domains to monitor
        """
        self.config = config
        self.scanner_class = scanner_class
        self.domains = domains or []
        self.history_manager = HistoryManager(config.OUTPUT_DIR)
        self.notification_manager = NotificationManager(config)
        self.change_detector = ChangeDetector()
        
        self._running = False
        self._stop_event = asyncio.Event()
    
    def add_domain(self, domain: str):
        """Add a domain to monitor"""
        if domain not in self.domains:
            self.domains.append(domain)
    
    def remove_domain(self, domain: str):
        """Remove a domain from monitoring"""
        if domain in self.domains:
            self.domains.remove(domain)
    
    async def scan_domain(self, domain: str) -> Dict:
        """
        Run a scan on a single domain
        
        Args:
            domain: Domain to scan
        
        Returns:
            Scan results dictionary
        """
        from ..models.data_models import ScanLevel
        
        scanner = self.scanner_class(
            config=self.config,
            scan_level=ScanLevel.NORMAL  # Use normal scan level for monitoring
        )
        
        results = await scanner.run(domain)
        
        # Convert to dict if needed
        if hasattr(results, 'to_dict'):
            results = results.to_dict()
        elif hasattr(results, '__dict__'):
            results = {
                'domain': getattr(results, 'domain', domain),
                'scan_level': getattr(results, 'scan_level', 'normal'),
                'summary': getattr(results, 'summary', {}),
                'subdomains': getattr(results, 'subdomains', {})
            }
        
        return results
    
    async def process_domain(self, domain: str) -> List[Alert]:
        """
        Process a single domain: scan, compare, alert
        
        Args:
            domain: Domain to process
        
        Returns:
            List of alerts generated
        """
        logger.info(f"[WatchTower] Scanning {domain}...")
        
        # Run new scan
        new_results = await self.scan_domain(domain)
        
        # Get previous scan results
        old_results = self.history_manager.get_last_scan(domain)
        
        # Detect changes
        alerts = self.change_detector.detect_changes(old_results, new_results)
        
        # Save current scan
        self.history_manager.save_scan(domain, new_results)
        
        # Send alerts
        for alert in alerts:
            await self.notification_manager.send_alert(alert)
        
        # Cleanup old scans
        self.history_manager.cleanup_old_scans(domain, keep_days=30)
        
        return alerts
    
    async def run_cycle(self):
        """Run one monitoring cycle for all domains"""
        logger.info(f"[WatchTower] Starting monitoring cycle for {len(self.domains)} domains")
        
        all_alerts = []
        
        for domain in self.domains:
            if self._stop_event.is_set():
                break
            
            try:
                alerts = await self.process_domain(domain)
                all_alerts.extend(alerts)
            except Exception as e:
                logger.error(f"[WatchTower] Error processing {domain}: {e}")
        
        logger.info(f"[WatchTower] Cycle complete. Generated {len(all_alerts)} alerts")
        return all_alerts
    
    async def start(self, interval_hours: float = 6):
        """
        Start continuous monitoring
        
        Args:
            interval_hours: Hours between scan cycles
        """
        if not self.domains:
            logger.warning("[WatchTower] No domains configured for monitoring")
            return
        
        self._running = True
        self._stop_event.clear()
        
        logger.info(f"[WatchTower] Starting continuous monitoring")
        logger.info(f"[WatchTower] Domains: {', '.join(self.domains)}")
        logger.info(f"[WatchTower] Interval: {interval_hours} hours")
        
        while self._running and not self._stop_event.is_set():
            try:
                await self.run_cycle()
            except Exception as e:
                logger.error(f"[WatchTower] Cycle error: {e}")
            
            # Wait for next cycle or stop
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=interval_hours * 3600
                )
                # If we get here, stop was requested
                break
            except asyncio.TimeoutError:
                # Normal timeout, continue to next cycle
                pass
        
        logger.info("[WatchTower] Monitoring stopped")
    
    def stop(self):
        """Stop continuous monitoring"""
        self._running = False
        self._stop_event.set()
        logger.info("[WatchTower] Stop requested")
    
    def get_status(self) -> Dict:
        """Get current monitoring status"""
        return {
            'running': self._running,
            'domains': self.domains,
            'interval_hours': self.config.MONITORING_INTERVAL / 3600 if hasattr(self.config, 'MONITORING_INTERVAL') else 6
        }


async def watch_tower_mode(
    domains: List[str],
    config,
    scanner_class,
    interval_hours: float = 6,
    single_run: bool = False
):
    """
    Convenience function to run Watch Tower mode
    
    Args:
        domains: List of domains to monitor
        config: Configuration object
        scanner_class: Scanner class to use
        interval_hours: Hours between scans
        single_run: If True, run only one cycle
    """
    watch_tower = WatchTower(config, scanner_class, domains)
    
    if single_run:
        return await watch_tower.run_cycle()
    else:
        await watch_tower.start(interval_hours)