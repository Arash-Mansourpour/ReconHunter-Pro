"""
Output package for Recon Hunter Pro
"""

from .dashboard_generator import DashboardGenerator
from .report_generator import ReportGenerator

__all__ = ['DashboardGenerator', 'ReportGenerator']