#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dashboard Generator for Recon Hunter Pro
"""

import json
from datetime import datetime
from typing import Dict, Any


class DashboardGenerator:
    """
    Generate interactive HTML dashboard from scan results
    """
    
    @staticmethod
    def generate_dashboard(results: Dict[str, Any], output_path: str) -> None:
        """
        Generate an interactive HTML dashboard
        
        Args:
            results: Scan results dictionary
            output_path: Path to save the HTML file
        """
        html_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recon Hunter Pro - Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1e3a 0%, #0d1117 100%);
            color: #e1e8f0;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            padding: 30px 0;
            border-bottom: 1px solid #30363d;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 2.5em;
            background: linear-gradient(90deg, #0066ff, #00ccff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        
        .header .subtitle {
            color: #8b949e;
            font-size: 1.1em;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: #0066ff;
        }
        
        .stat-card .number {
            font-size: 2.5em;
            font-weight: bold;
            color: #00ccff;
            margin-bottom: 5px;
        }
        
        .stat-card .label {
            color: #8b949e;
            font-size: 0.9em;
        }
        
        .section {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .section h2 {
            color: #00ccff;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #30363d;
        }
        
        .subdomain-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .subdomain-table th,
        .subdomain-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #30363d;
        }
        
        .subdomain-table th {
            background: #21262d;
            color: #00ccff;
            font-weight: 600;
        }
        
        .subdomain-table tr:hover {
            background: #21262d;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: 600;
        }
        
        .status-200 { background: #238636; color: white; }
        .status-300 { background: #f0883e; color: white; }
        .status-400 { background: #da3633; color: white; }
        .status-500 { background: #8b949e; color: white; }
        
        .cdn-badge {
            background: #8957e5;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75em;
        }
        
        .waf-badge {
            background: #f85149;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75em;
        }
        
        .tech-badge {
            background: #1f6feb;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75em;
            margin-right: 4px;
            display: inline-block;
            margin-bottom: 2px;
        }
        
        .takeover-badge {
            background: #f85149;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75em;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .footer {
            text-align: center;
            padding: 20px;
            color: #8b949e;
            border-top: 1px solid #30363d;
            margin-top: 30px;
        }
        
        .search-box {
            width: 100%;
            padding: 12px;
            border: 1px solid #30363d;
            border-radius: 8px;
            background: #0d1117;
            color: #e1e8f0;
            margin-bottom: 15px;
            font-size: 1em;
        }
        
        .search-box:focus {
            outline: none;
            border-color: #0066ff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Recon Hunter Pro</h1>
            <div class="subtitle">Reconnaissance Dashboard for {domain}</div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="number">{total_subdomains}</div>
                <div class="label">Total Subdomains</div>
            </div>
            <div class="stat-card">
                <div class="number">{alive_services}</div>
                <div class="label">Live Services</div>
            </div>
            <div class="stat-card">
                <div class="number">{unique_ips}</div>
                <div class="label">Unique IPs</div>
            </div>
            <div class="stat-card">
                <div class="number">{cdn_count}</div>
                <div class="label">CDN Protected</div>
            </div>
            <div class="stat-card">
                <div class="number">{tech_count}</div>
                <div class="label">Technologies</div>
            </div>
            <div class="stat-card">
                <div class="number">{waf_count}</div>
                <div class="label">WAFs Detected</div>
            </div>
        </div>
        
        <div class="section">
            <h2>Subdomains</h2>
            <input type="text" class="search-box" id="searchInput" placeholder="Search subdomains...">
            <div style="overflow-x: auto;">
                <table class="subdomain-table" id="subdomainTable">
                    <thead>
                        <tr>
                            <th>Subdomain</th>
                            <th>Status</th>
                            <th>IPs</th>
                            <th>CDN</th>
                            <th>WAF</th>
                            <th>Technologies</th>
                            <th>Open Ports</th>
                        </tr>
                    </thead>
                    <tbody>
                        {subdomain_rows}
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="footer">
            <p>Generated by Recon Hunter Pro | {timestamp}</p>
        </div>
    </div>
    
    <script>
        document.getElementById('searchInput').addEventListener('keyup', function() {{
            var filter = this.value.toLowerCase();
            var table = document.getElementById('subdomainTable');
            var rows = table.getElementsByTagName('tr');
            
            for (var i = 1; i < rows.length; i++) {{
                var cells = rows[i].getElementsByTagName('td');
                var found = false;
                
                for (var j = 0; j < cells.length; j++) {{
                    if (cells[j].textContent.toLowerCase().indexOf(filter) > -1) {{
                        found = true;
                        break;
                    }}
                }}
                
                rows[i].style.display = found ? '' : 'none';
            }}
        }});
    </script>
</body>
</html>'''
        
        # Extract summary data
        summary = results.get('summary', {})
        subdomains = results.get('subdomains', {})
        
        # Generate subdomain rows
        rows_html = []
        for subdomain, info in sorted(subdomains.items()):
            status_code = info.get('status_code')
            status_class = 'status-200' if status_code == 200 else 'status-300' if status_code and status_code < 400 else 'status-400' if status_code and status_code < 500 else 'status-500' if status_code else ''
            status_text = str(status_code) if status_code else '-'
            
            ips = ', '.join(info.get('ips', [])[:3])
            if len(info.get('ips', [])) > 3:
                ips += f' +{len(info.get("ips", [])) - 3} more'
            
            cdn = f'<span class="cdn-badge">{info.get("cdn")}</span>' if info.get('cdn') else '-'
            waf = f'<span class="waf-badge">{info.get("waf")}</span>' if info.get('waf') else '-'
            
            techs = info.get('technologies', [])
            tech_html = ' '.join([f'<span class="tech-badge">{t}</span>' for t in techs[:5]]) if techs else '-'
            
            ports = ', '.join(map(str, info.get('open_ports', []))) if info.get('open_ports') else '-'
            
            takeover = ''
            if info.get('takeover_vulnerable'):
                takeover = f'<span class="takeover-badge">TAKEOVER: {info.get("takeover_service", "Unknown")}</span>'
            
            row = f'''<tr>
                <td>{subdomain} {takeover}</td>
                <td><span class="status-badge {status_class}">{status_text}</span></td>
                <td>{ips or '-'}</td>
                <td>{cdn}</td>
                <td>{waf}</td>
                <td>{tech_html}</td>
                <td>{ports}</td>
            </tr>'''
            rows_html.append(row)
        
        # Fill template
        html = html_template.format(
            domain=results.get('domain', 'Unknown'),
            total_subdomains=summary.get('total_subdomains', 0),
            alive_services=summary.get('alive_services', 0),
            unique_ips=len(summary.get('unique_ips', [])),
            cdn_count=summary.get('cdn_count', 0),
            tech_count=len(summary.get('technologies', [])),
            waf_count=len(summary.get('wafs', [])),
            subdomain_rows=''.join(rows_html),
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)