#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Report Generator for Recon Hunter Pro
"""

import json
import csv
from datetime import datetime
from typing import Dict, Any, List


class ReportGenerator:
    """
    Generate reports in various formats
    """
    
    @staticmethod
    def to_json(results: Dict[str, Any], output_path: str) -> None:
        """
        Export results to JSON file
        
        Args:
            results: Scan results dictionary
            output_path: Path to save the JSON file
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str, ensure_ascii=False)
    
    @staticmethod
    def to_csv(results: Dict[str, Any], output_path: str) -> None:
        """
        Export subdomains to CSV file
        
        Args:
            results: Scan results dictionary
            output_path: Path to save the CSV file
        """
        subdomains = results.get('subdomains', {})
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Write header
            writer.writerow([
                'Subdomain',
                'Status Code',
                'IPs',
                'CNAMEs',
                'CDN',
                'WAF',
                'Technologies',
                'Open Ports',
                'Title',
                'Server',
                'Takeover Vulnerable',
                'Takeover Service'
            ])
            
            # Write data
            for subdomain, info in sorted(subdomains.items()):
                writer.writerow([
                    subdomain,
                    info.get('status_code', ''),
                    ', '.join(info.get('ips', [])),
                    ', '.join(info.get('cnames', [])),
                    info.get('cdn', ''),
                    info.get('waf', ''),
                    ', '.join(info.get('technologies', [])),
                    ', '.join(map(str, info.get('open_ports', []))),
                    info.get('title', ''),
                    info.get('server', ''),
                    'Yes' if info.get('takeover_vulnerable') else 'No',
                    info.get('takeover_service', '')
                ])
    
    @staticmethod
    def to_txt(results: Dict[str, Any], output_path: str) -> None:
        """
        Export results to plain text file
        
        Args:
            results: Scan results dictionary
            output_path: Path to save the text file
        """
        lines = []
        
        # Header
        lines.append("=" * 80)
        lines.append("RECON HUNTER PRO - SCAN REPORT")
        lines.append("=" * 80)
        lines.append("")
        
        # Target info
        lines.append(f"Target: {results.get('domain', 'Unknown')}")
        lines.append(f"Scan Level: {results.get('scan_level', 'Unknown')}")
        lines.append(f"Start Time: {results.get('start_time', 'Unknown')}")
        lines.append(f"End Time: {results.get('end_time', 'Unknown')}")
        lines.append(f"Duration: {results.get('duration', 'Unknown')}")
        lines.append("")
        
        # Summary
        summary = results.get('summary', {})
        lines.append("-" * 40)
        lines.append("SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Total Subdomains: {summary.get('total_subdomains', 0)}")
        lines.append(f"Live Services: {summary.get('alive_services', 0)}")
        lines.append(f"Unique IPs: {len(summary.get('unique_ips', []))}")
        lines.append(f"CDN Protected: {summary.get('cdn_count', 0)}")
        lines.append(f"Technologies Found: {len(summary.get('technologies', []))}")
        lines.append(f"WAFs Detected: {len(summary.get('wafs', []))}")
        lines.append(f"Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)}")
        lines.append("")
        
        # Subdomains
        subdomains = results.get('subdomains', {})
        lines.append("-" * 40)
        lines.append("SUBDOMAINS")
        lines.append("-" * 40)
        
        for subdomain, info in sorted(subdomains.items()):
            lines.append(f"\n[{subdomain}]")
            
            if info.get('status_code'):
                lines.append(f"  Status: {info.get('status_code')}")
            
            if info.get('ips'):
                lines.append(f"  IPs: {', '.join(info.get('ips', []))}")
            
            if info.get('cnames'):
                lines.append(f"  CNAMEs: {', '.join(info.get('cnames', []))}")
            
            if info.get('cdn'):
                lines.append(f"  CDN: {info.get('cdn')}")
            
            if info.get('waf'):
                lines.append(f"  WAF: {info.get('waf')}")
            
            if info.get('technologies'):
                lines.append(f"  Technologies: {', '.join(info.get('technologies', []))}")
            
            if info.get('open_ports'):
                lines.append(f"  Open Ports: {', '.join(map(str, info.get('open_ports', [])))}")
            
            if info.get('title'):
                lines.append(f"  Title: {info.get('title')}")
            
            if info.get('takeover_vulnerable'):
                lines.append(f"  [!] TAKEOVER VULNERABLE: {info.get('takeover_service', 'Unknown')}")
        
        lines.append("")
        lines.append("=" * 80)
        lines.append(f"Generated by Recon Hunter Pro - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 80)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
    
    @staticmethod
    def to_markdown(results: Dict[str, Any], output_path: str) -> None:
        """
        Export results to Markdown file
        
        Args:
            results: Scan results dictionary
            output_path: Path to save the Markdown file
        """
        lines = []
        
        # Header
        lines.append("# Recon Hunter Pro - Scan Report")
        lines.append("")
        
        # Target info
        lines.append("## Target Information")
        lines.append("")
        lines.append(f"| Property | Value |")
        lines.append(f"|----------|-------|")
        lines.append(f"| Domain | `{results.get('domain', 'Unknown')}` |")
        lines.append(f"| Scan Level | {results.get('scan_level', 'Unknown')} |")
        lines.append(f"| Start Time | {results.get('start_time', 'Unknown')} |")
        lines.append(f"| End Time | {results.get('end_time', 'Unknown')} |")
        lines.append(f"| Duration | {results.get('duration', 'Unknown')} |")
        lines.append("")
        
        # Summary
        summary = results.get('summary', {})
        lines.append("## Summary")
        lines.append("")
        lines.append(f"| Metric | Count |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Total Subdomains | {summary.get('total_subdomains', 0)} |")
        lines.append(f"| Live Services | {summary.get('alive_services', 0)} |")
        lines.append(f"| Unique IPs | {len(summary.get('unique_ips', []))} |")
        lines.append(f"| CDN Protected | {summary.get('cdn_count', 0)} |")
        lines.append(f"| Technologies Found | {len(summary.get('technologies', []))} |")
        lines.append(f"| WAFs Detected | {len(summary.get('wafs', []))} |")
        lines.append(f"| Takeover Vulnerable | {summary.get('takeover_vulnerable', 0)} |")
        lines.append("")
        
        # Technologies
        if summary.get('technologies'):
            lines.append("## Technologies Detected")
            lines.append("")
            for tech in sorted(summary.get('technologies', [])):
                lines.append(f"- {tech}")
            lines.append("")
        
        # WAFs
        if summary.get('wafs'):
            lines.append("## WAFs Detected")
            lines.append("")
            for waf in sorted(summary.get('wafs', [])):
                lines.append(f"- {waf}")
            lines.append("")
        
        # Subdomains table
        subdomains = results.get('subdomains', {})
        lines.append("## Subdomains")
        lines.append("")
        lines.append("| Subdomain | Status | IPs | CDN | WAF | Technologies |")
        lines.append("|-----------|--------|-----|-----|-----|--------------|")
        
        for subdomain, info in sorted(subdomains.items()):
            status = info.get('status_code', '-')
            ips = ', '.join(info.get('ips', [])[:2])
            if len(info.get('ips', [])) > 2:
                ips += f' +{len(info.get("ips", [])) - 2}'
            cdn = info.get('cdn', '-')
            waf = info.get('waf', '-')
            techs = ', '.join(info.get('technologies', [])[:3]) or '-'
            
            lines.append(f"| `{subdomain}` | {status} | {ips or '-'} | {cdn} | {waf} | {techs} |")
        
        lines.append("")
        lines.append("---")
        lines.append(f"*Generated by Recon Hunter Pro - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
    
    @staticmethod
    def generate_all(results: Dict[str, Any], output_dir: str, base_name: str = None) -> Dict[str, str]:
        """
        Generate all report formats
        
        Args:
            results: Scan results dictionary
            output_dir: Directory to save reports
            base_name: Base name for report files
        
        Returns:
            Dictionary with paths to generated files
        """
        import os
        
        if base_name is None:
            base_name = f"recon_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        os.makedirs(output_dir, exist_ok=True)
        
        files = {}
        
        # JSON
        json_path = os.path.join(output_dir, f"{base_name}.json")
        ReportGenerator.to_json(results, json_path)
        files['json'] = json_path
        
        # CSV
        csv_path = os.path.join(output_dir, f"{base_name}.csv")
        ReportGenerator.to_csv(results, csv_path)
        files['csv'] = csv_path
        
        # TXT
        txt_path = os.path.join(output_dir, f"{base_name}.txt")
        ReportGenerator.to_txt(results, txt_path)
        files['txt'] = txt_path
        
        # Markdown
        md_path = os.path.join(output_dir, f"{base_name}.md")
        ReportGenerator.to_markdown(results, md_path)
        files['markdown'] = md_path
        
        return files