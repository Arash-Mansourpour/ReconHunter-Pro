# Recon Hunter Pro - Enterprise Edition v4.0

Advanced Reconnaissance & OSINT Framework

## Features

- **Multi-Source Passive Reconnaissance** - 8+ OSINT sources
  - crt.sh (SSL Certificates)
  - ThreatCrowd
  - HackerTarget
  - Wayback Machine
  - VirusTotal
  - AlienVault OTX
  - URLScan.io
  - RapidDNS

- **Advanced DNS Enumeration**
  - Async DNS resolution with caching
  - DNS bruteforce with common wordlist
  - Permutation generation

- **Detection Modules**
  - WAF Detection (Cloudflare, Akamai, AWS WAF, etc.)
  - CDN Detection (Cloudflare, CloudFront, Akamai, Fastly, etc.)
  - Technology Fingerprinting (WordPress, Laravel, React, etc.)
  - Subdomain Takeover Detection

- **Analysis Tools**
  - Port Scanner with service detection
  - JavaScript Analyzer for secrets
  - Email pattern analysis
  - Vulnerability detection

- **Output Options**
  - Interactive HTML Dashboard
  - JSON, CSV, TXT, Markdown reports
  - CLI and GUI interfaces

## Installation

```bash
# Clone or download the project
cd RecanLA/recon_app

# Install dependencies
pip install -r requirements.txt
```

## Usage

### GUI Mode

```bash
python main.py
```

### CLI Mode

```bash
# Basic scan
python main.py example.com

# Passive scan only
python main.py example.com -l passive

# Aggressive scan with all outputs
python main.py example.com -l aggressive -f all --dashboard

# Save to specific directory
python main.py example.com -o ./results -f json
```

### CLI Options

| Option | Description |
|--------|-------------|
| `domain` | Target domain to scan |
| `-l, --level` | Scan level: passive, normal, aggressive |
| `-o, --output` | Output directory for results |
| `-f, --format` | Output format: json, csv, txt, md, all |
| `--dashboard` | Generate HTML dashboard |
| `-v, --verbose` | Verbose output |

## Project Structure

```
recon_app/
├── main.py              # Entry point
├── config.py            # Configuration settings
├── requirements.txt     # Dependencies
├── README.md            # Documentation
│
├── models/              # Data models
│   ├── __init__.py
│   └── data_models.py
│
├── core/                # Core functionality
│   ├── __init__.py
│   ├── dns_resolver.py      # DNS resolution
│   ├── dns_bruteforce.py    # DNS bruteforce
│   └── passive_recon.py     # Passive reconnaissance
│
├── detection/           # Detection modules
│   ├── __init__.py
│   ├── waf_detector.py      # WAF detection
│   ├── cdn_detector.py      # CDN detection
│   ├── tech_detector.py     # Technology fingerprinting
│   └── takeover_detector.py # Subdomain takeover
│
├── analysis/            # Analysis tools
│   ├── __init__.py
│   ├── port_scanner.py      # Port scanning
│   ├── js_analyzer.py       # JavaScript analysis
│   ├── email_analyzer.py    # Email pattern analysis
│   └── vulnerability_analyzer.py
│
├── scanner/             # Main scanner
│   ├── __init__.py
│   └── recon_scanner.py
│
├── output/              # Output generators
│   ├── __init__.py
│   ├── dashboard_generator.py
│   └── report_generator.py
│
├── gui/                 # GUI application
│   ├── __init__.py
│   └── app.py
│
└── utils/               # Utilities
    ├── __init__.py
    ├── logger.py
    ├── rate_limiter.py
    └── proxy_manager.py
```

## Scan Levels

| Level | Description |
|-------|-------------|
| Passive | Only passive reconnaissance (OSINT sources) |
| Normal | Passive + DNS bruteforce |
| Aggressive | Normal + Permutations + Port scanning + WAF detection |

## API Keys (Optional)

For enhanced results, configure API keys in Settings > API Configuration:

- Shodan API Key
- Censys API ID & Secret
- SecurityTrails API Key
- VirusTotal API Key

## Requirements

- Python 3.8+
- aiohttp
- aiodns
- pyOpenSSL
- tkinter (included with Python)

## License

This tool is for educational and authorized security testing purposes only.

## Disclaimer

Use this tool responsibly and only on targets you have permission to test. The authors are not responsible for any misuse or damage caused by this tool.