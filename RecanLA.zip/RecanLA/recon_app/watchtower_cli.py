
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Watch Tower CLI - Continuous Security Monitoring
100% Free and Open-Source - No API Keys Required

Usage:
    python watchtower_cli.py <domain> [options]

Examples:
    # Start monitoring with default settings (6 hour intervals)
    python watchtower_cli.py example.com
    
    # Monitor with 1 hour intervals
    python watchtower_cli.py example.com --interval 1
    
    # Monitor with notifications
    python watchtower_cli.py example.com --slack-webhook https://hooks.slack.com/...
    
    # Single scan (no continuous monitoring)
    python watchtower_cli.py example.com --single-scan
    
    # View history
    python watchtower_cli.py example.com --history
"""

import asyncio
import argparse
import sys
import os
import logging
from datetime import datetime
from typing import List, Optional

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from recon_app.config import Config, create_watchtower_config
from recon_app.monitoring.watch_tower import WatchTower
from recon_app.scanner.recon_scanner import ReconScanner

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('watchtower.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def print_banner():
    """Print Watch Tower banner"""
    print("""
+=======================================================================+
|                                                                       |
|   WATCH TOWER - Continuous Security Monitoring System                 |
|                                                                       |
|              100% Free - No API Keys Required                         |
|                                                                       |
+=======================================================================+
""")


def print_results_summary(results: dict):
    """Print a summary of scan results"""
    summary = results.get('summary', {})
    
    print("\n" + "=" * 70)
    print("SCAN RESULTS SUMMARY")
    print("=" * 70)
    
    print(f"\n[*] Target: {results.get('domain', 'N/A')}")
    print(f"[*] Scan Time: {results.get('scan_time', 'N/A')}")
    
    print(f"\n[+] METRICS:")
    print(f"   - Total Subdomains: {summary.get('total_subdomains', 0)}")
    print(f"   - Live Services: {summary.get('alive_services', 0)}")
    print(f"   - Unique IPs: {summary.get('unique_ips', 0)}")
    print(f"   - CDN Protected: {summary.get('cdn_count', 0)}")
    
    print(f"\n[!] SECURITY:")
    print(f"   - Takeover Vulnerable: {summary.get('takeover_vulnerable', 0)}")
    print(f"   - Secrets Found: {summary.get('secrets_found', 0)}")
    print(f"   - Cloud Buckets: {summary.get('cloud_buckets', 0)}")
    print(f"   - Vulnerabilities: {summary.get('vulnerabilities', 0)}")
    
    print("=" * 70)


def print_alerts(alerts: List[dict]):
    """Print detected alerts"""
    if not alerts:
        print("\n✅ No new alerts detected.")
        return
    
    print("\n" + "=" * 70)
    print("🚨 ALERTS - CHANGES DETECTED")
    print("=" * 70)
    
    for alert in alerts:
        severity = alert.get('severity', 'info').upper()
        icon = {
            'CRITICAL': '🔴',
            'HIGH': '🟠',
            'MEDIUM': '🟡',
            'LOW': '🟢',
            'INFO': 'ℹ️'
        }.get(severity, 'ℹ️')
        
        print(f"\n{icon} [{severity}] {alert.get('type', 'Unknown')}")
        print(f"   {alert.get('message', '')}")
        
        if alert.get('details'):
            print(f"   Details: {alert.get('details')}")


async def run_single_scan(domain: str, config: Config):
    """Run a single scan"""
    print(f"\n🔍 Running single scan for: {domain}")
    
    scanner = ReconScanner(config=config)
    results = await scanner.run(domain)
    
    print_results_summary(results)
    
    # Save results
    output_dir = config.OUTPUT_DIR
    os.makedirs(output_dir, exist_ok=True)
    
    import json
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{output_dir}/{domain.replace('.', '_')}_{timestamp}.json"
    
    with open(filename, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n💾 Results saved to: {filename}")
    
    return results


async def run_watch_tower(domain: str, config: Config):
    """Run Watch Tower continuous monitoring"""
    print(f"\n🗼 Starting Watch Tower for: {domain}")
    print(f"⏰ Monitoring interval: {config.get_monitoring_interval_hours():.1f} hours")
    
    if config.is_notification_enabled():
        print("📢 Notifications: Enabled")
    else:
        print("📢 Notifications: Disabled")
    
    print("\n" + "-" * 70)
    print("Press Ctrl+C to stop monitoring")
    print("-" * 70 + "\n")
    
    watch_tower = WatchTower(domain, config)
    
    try:
        await watch_tower.start()
    except KeyboardInterrupt:
        print("\n\n⏹️ Watch Tower stopped by user.")
        watch_tower.stop()


async def view_history(domain: str, config: Config):
    """View scan history for a domain"""
    print(f"\n📜 Scan history for: {domain}\n")
    
    watch_tower = WatchTower(domain, config)
    history = watch_tower.get_history()
    
    if not history:
        print("No history found for this domain.")
        return
    
    print("=" * 70)
    print(f"{'Date':<25} {'Subdomains':<12} {'Live':<10} {'Secrets':<10} {'Alerts':<10}")
    print("=" * 70)
    
    for entry in history[-20:]:  # Last 20 entries
        date = entry.get('timestamp', 'N/A')
        summary = entry.get('summary', {})
        alerts = entry.get('alerts', [])
        
        print(f"{date:<25} "
              f"{summary.get('total_subdomains', 0):<12} "
              f"{summary.get('alive_services', 0):<10} "
              f"{summary.get('secrets_found', 0):<10} "
              f"{len(alerts):<10}")
    
    print("=" * 70)


def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='Watch Tower - Continuous Security Monitoring System',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s example.com                          # Start monitoring with defaults
  %(prog)s example.com --interval 1             # Monitor every 1 hour
  %(prog)s example.com --single-scan            # Run single scan only
  %(prog)s example.com --history                # View scan history
  %(prog)s example.com --slack-webhook URL      # Enable Slack notifications
        """
    )
    
    parser.add_argument(
        'domain',
        help='Target domain to monitor'
    )
    
    parser.add_argument(
        '--interval',
        type=float,
        default=6,
        help='Monitoring interval in hours (default: 6)'
    )
    
    parser.add_argument(
        '--single-scan',
        action='store_true',
        help='Run a single scan instead of continuous monitoring'
    )
    
    parser.add_argument(
        '--history',
        action='store_true',
        help='View scan history for the domain'
    )
    
    parser.add_argument(
        '--output-dir',
        default='recon_results',
        help='Output directory for results (default: recon_results)'
    )
    
    parser.add_argument(
        '--stealth',
        action='store_true',
        help='Enable stealth mode (slower but more隐蔽)'
    )
    
    # Notification options
    parser.add_argument(
        '--slack-webhook',
        help='Slack webhook URL for notifications'
    )
    
    parser.add_argument(
        '--discord-webhook',
        help='Discord webhook URL for notifications'
    )
    
    parser.add_argument(
        '--telegram-token',
        help='Telegram bot token'
    )
    
    parser.add_argument(
        '--telegram-chat-id',
        help='Telegram chat ID'
    )
    
    parser.add_argument(
        '--email',
        help='Email recipient (can be specified multiple times)',
        action='append',
        default=[]
    )
    
    parser.add_argument(
        '--config',
        help='Path to configuration file (JSON)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    return parser.parse_args()


def create_config_from_args(args) -> Config:
    """Create configuration from command line arguments"""
    # Start with default config
    config = Config()
    
    # Apply command line arguments
    config.OUTPUT_DIR = args.output_dir
    config.STEALTH_MODE = args.stealth
    config.MONITORING_INTERVAL = int(args.interval * 3600)
    
    # Notifications
    if args.slack_webhook:
        config.SLACK_WEBHOOK_URL = args.slack_webhook
    if args.discord_webhook:
        config.DISCORD_WEBHOOK_URL = args.discord_webhook
    if args.telegram_token and args.telegram_chat_id:
        config.TELEGRAM_BOT_TOKEN = args.telegram_token
        config.TELEGRAM_CHAT_ID = args.telegram_chat_id
    if args.email:
        config.EMAIL_RECIPIENTS = args.email
        config.EMAIL_ENABLED = True
    
    # Verbose mode
    if args.verbose:
        config.LOG_LEVEL = 'DEBUG'
        logging.getLogger().setLevel(logging.DEBUG)
    
    return config


async def main():
    """Main entry point"""
    args = parse_arguments()
    
    print_banner()
    
    # Create configuration
    if args.config:
        config = Config.from_file(args.config)
    else:
        config = create_config_from_args(args)
    
    # Handle different modes
    try:
        if args.history:
            await view_history(args.domain, config)
        elif args.single_scan:
            await run_single_scan(args.domain, config)
        else:
            await run_watch_tower(args.domain, config)
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        logger.exception(f"Error: {e}")
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())