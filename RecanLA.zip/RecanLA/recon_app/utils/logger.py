#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Logger for Recon Hunter Pro
"""

import logging
import sys
from typing import Optional


def setup_logger(
    name: str = "recon_hunter",
    log_file: str = "recon_hunter.log",
    level: int = logging.INFO,
    format_string: str = '%(asctime)s - %(levelname)s - %(message)s'
) -> logging.Logger:
    """
    Setup and return a logger instance
    
    Args:
        name: Logger name
        log_file: Path to log file
        level: Logging level
        format_string: Log format string
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid adding handlers multiple times
    if logger.handlers:
        return logger
    
    # File handler
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(format_string))
    logger.addHandler(file_handler)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(logging.Formatter(format_string))
    logger.addHandler(console_handler)
    
    return logger


def get_logger(name: str = "recon_hunter") -> logging.Logger:
    """
    Get an existing logger instance
    
    Args:
        name: Logger name
    
    Returns:
        Logger instance
    """
    return logging.getLogger(name)


class LogColors:
    """ANSI color codes for terminal output"""
    RESET = '\033[0m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'


def colorize(message: str, color: str) -> str:
    """
    Add color to a message
    
    Args:
        message: Message to colorize
        color: Color code from LogColors
    
    Returns:
        Colorized message
    """
    return f"{color}{message}{LogColors.RESET}"


def log_info(logger: logging.Logger, message: str):
    """Log info message with color"""
    logger.info(message)


def log_warning(logger: logging.Logger, message: str):
    """Log warning message with color"""
    logger.warning(message)


def log_error(logger: logging.Logger, message: str):
    """Log error message with color"""
    logger.error(message)


def log_success(logger: logging.Logger, message: str):
    """Log success message"""
    logger.info(f"✓ {message}")


def log_section(logger: logging.Logger, title: str):
    """Log a section header"""
    separator = "=" * 70
    logger.info(f"\n{separator}")
    logger.info(f"  {title}")
    logger.info(f"{separator}\n")