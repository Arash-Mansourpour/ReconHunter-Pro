#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Proxy Manager for Recon Hunter Pro
"""

from typing import List, Optional, Set
import random


class ProxyManager:
    """Proxy rotation manager"""
    
    def __init__(self, proxy_list: List[str] = None):
        """
        Initialize proxy manager
        
        Args:
            proxy_list: List of proxy URLs (e.g., ['http://proxy:8080', 'socks5://proxy:1080'])
        """
        self.proxies = proxy_list or []
        self.current_index = 0
        self.bad_proxies: Set[str] = set()
        self.proxy_stats: dict = {}
        
        # Initialize stats for each proxy
        for proxy in self.proxies:
            self.proxy_stats[proxy] = {
                'success': 0,
                'failure': 0,
                'avg_response_time': 0
            }
    
    def get_proxy(self) -> Optional[str]:
        """Get next available proxy"""
        if not self.proxies:
            return None
        
        available = [p for p in self.proxies if p not in self.bad_proxies]
        if not available:
            return None
        
        proxy = available[self.current_index % len(available)]
        self.current_index += 1
        return proxy
    
    def get_random_proxy(self) -> Optional[str]:
        """Get a random available proxy"""
        if not self.proxies:
            return None
        
        available = [p for p in self.proxies if p not in self.bad_proxies]
        if not available:
            return None
        
        return random.choice(available)
    
    def get_best_proxy(self) -> Optional[str]:
        """Get the proxy with best performance"""
        if not self.proxies:
            return None
        
        available = [p for p in self.proxies if p not in self.bad_proxies]
        if not available:
            return None
        
        # Sort by success rate
        best = max(available, key=lambda p: self.proxy_stats.get(p, {}).get('success', 0))
        return best
    
    def mark_bad(self, proxy: str):
        """Mark a proxy as bad/unusable"""
        self.bad_proxies.add(proxy)
        if proxy in self.proxy_stats:
            self.proxy_stats[proxy]['failure'] += 1
    
    def mark_success(self, proxy: str, response_time: float = 0):
        """Mark a proxy as successful"""
        if proxy in self.proxy_stats:
            self.proxy_stats[proxy]['success'] += 1
            # Update average response time
            current_avg = self.proxy_stats[proxy]['avg_response_time']
            success_count = self.proxy_stats[proxy]['success']
            self.proxy_stats[proxy]['avg_response_time'] = (
                (current_avg * (success_count - 1) + response_time) / success_count
            )
    
    def reset_bad_proxies(self):
        """Reset the bad proxy list (give them another chance)"""
        self.bad_proxies.clear()
    
    def add_proxy(self, proxy: str):
        """Add a new proxy to the pool"""
        if proxy not in self.proxies:
            self.proxies.append(proxy)
            self.proxy_stats[proxy] = {
                'success': 0,
                'failure': 0,
                'avg_response_time': 0
            }
    
    def remove_proxy(self, proxy: str):
        """Remove a proxy from the pool"""
        if proxy in self.proxies:
            self.proxies.remove(proxy)
        self.bad_proxies.discard(proxy)
        if proxy in self.proxy_stats:
            del self.proxy_stats[proxy]
    
    def get_stats(self) -> dict:
        """Get proxy statistics"""
        return {
            'total_proxies': len(self.proxies),
            'available_proxies': len([p for p in self.proxies if p not in self.bad_proxies]),
            'bad_proxies': len(self.bad_proxies),
            'proxy_stats': self.proxy_stats
        }