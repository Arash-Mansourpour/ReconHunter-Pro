#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rate Limiter for Recon Hunter Pro
"""

import asyncio
import time


class RateLimiter:
    """Advanced rate limiter with adaptive delays"""
    
    def __init__(self, requests_per_second: float = 10, burst: int = 20):
        """
        Initialize rate limiter
        
        Args:
            requests_per_second: Maximum requests per second
            burst: Maximum burst size
        """
        self.requests_per_second = requests_per_second
        self.burst = burst
        self.tokens = burst
        self.last_update = time.time()
        self.lock = asyncio.Lock()
    
    async def acquire(self):
        """Acquire a token, waiting if necessary"""
        async with self.lock:
            now = time.time()
            elapsed = now - self.last_update
            self.tokens = min(self.burst, self.tokens + elapsed * self.requests_per_second)
            self.last_update = now
            
            if self.tokens < 1:
                sleep_time = (1 - self.tokens) / self.requests_per_second
                await asyncio.sleep(sleep_time)
                self.tokens = 0
            else:
                self.tokens -= 1
    
    async def acquire_multiple(self, count: int = 1):
        """Acquire multiple tokens"""
        for _ in range(count):
            await self.acquire()
    
    def reset(self):
        """Reset the rate limiter"""
        self.tokens = self.burst
        self.last_update = time.time()