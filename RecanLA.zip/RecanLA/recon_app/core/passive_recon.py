#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Passive Reconnaissance Engine for Recon Hunter Pro
100% Free and Open-Source - No API Keys Required
Uses only publicly available sources and standard libraries
"""

import asyncio
import aiohttp
import json
import re
import random
import logging
from typing import Set, Dict, List, Optional, Any
from collections import defaultdict
from urllib.parse import urlparse

from ..config import Config
from ..utils.rate_limiter import RateLimiter
from ..utils.proxy_manager import ProxyManager

logger = logging.getLogger(__name__)


class PassiveReconEngine:
    """
    Ultimate Passive Reconnaissance Engine - 100% Free
    No API keys required - uses only publicly available sources
    Integrates 25+ free OSINT sources
    """
    
    def __init__(self, domain: str, config: Config = None, timeout: int = 30):
        """
        Initialize passive reconnaissance engine
        
        Args:
            domain: Target domain
            config: Configuration instance
            timeout: Request timeout in seconds
        """
        self.domain = domain
        self.config = config or Config()
        self.timeout = timeout
        self.session: Optional[aiohttp.ClientSession] = None
        self.results = defaultdict(set)
        self.rate_limiter = RateLimiter()
        self.proxy_manager = ProxyManager(self.config.PROXY_LIST if hasattr(self.config, 'PROXY_LIST') else [])
    
    async def init_session(self):
        """Initialize aiohttp session with proper settings"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            connector = aiohttp.TCPConnector(
                ssl=False,
                limit=100,
                limit_per_host=10,
                ttl_dns_cache=300
            )
            headers = {
                'User-Agent': random.choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0'
                ]),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive'
            }
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                headers=headers
            )
    
    async def close_session(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def _fetch(self, url: str, **kwargs) -> Optional[Any]:
        """
        Fetch URL with rate limiting and error handling
        
        Args:
            url: URL to fetch
            **kwargs: Additional arguments for the request
        
        Returns:
            Response content (JSON or text) or None on error
        """
        await self.rate_limiter.acquire()
        
        if hasattr(self.config, 'STEALTH_MODE') and self.config.STEALTH_MODE:
            delay = random.uniform(
                getattr(self.config, 'STEALTH_DELAY_MIN', 2.0),
                getattr(self.config, 'STEALTH_DELAY_MAX', 5.0)
            )
            await asyncio.sleep(delay)
        
        try:
            await self.init_session()
            
            proxy = None
            if hasattr(self.config, 'USE_PROXY') and self.config.USE_PROXY:
                proxy = self.proxy_manager.get_proxy()
            
            kwargs.setdefault('ssl', False)
            
            async with self.session.get(url, proxy=proxy, **kwargs) as response:
                if response.status == 200:
                    content_type = response.headers.get('Content-Type', '')
                    if 'json' in content_type:
                        return await response.json()
                    else:
                        return await response.text()
                elif response.status == 429:
                    # Rate limited, wait and retry
                    await asyncio.sleep(60)
                    return await self._fetch(url, **kwargs)
        except Exception as e:
            logger.debug(f"Fetch error for {url}: {e}")
        
        return None
    
    # ==================== CERTIFICATE SOURCES (FREE) ====================
    
    async def query_crtsh(self) -> Set[str]:
        """Query crt.sh for SSL certificates - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://crt.sh/?q=%25.{self.domain}&output=json")
            if data:
                for cert in data:
                    name = cert.get('name_value', '')
                    for sub in name.split('\n'):
                        sub = sub.strip().lower()
                        if self.domain in sub and '*' not in sub:
                            subdomains.add(sub)
            logger.info(f"[crt.sh] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[crt.sh] Error: {e}")
        return subdomains
    
    # ==================== DNS SOURCES (FREE) ====================
    
    async def query_dnsdumpster(self) -> Set[str]:
        """Query DNSDumpster - FREE"""
        subdomains = set()
        try:
            await self.init_session()
            
            # First get CSRF token
            async with self.session.get("https://dnsdumpster.com/") as response:
                text = await response.text()
                csrf = re.search(r"name='csrfmiddlewaretoken' value='([^']+)'", text)
                if csrf:
                    csrf_token = csrf.group(1)
                else:
                    return subdomains
            
            # Submit query
            data = {
                'csrfmiddlewaretoken': csrf_token,
                'targetip': self.domain,
                'user': 'free'
            }
            headers = {
                'Referer': 'https://dnsdumpster.com/',
                'Origin': 'https://dnsdumpster.com'
            }
            
            async with self.session.post("https://dnsdumpster.com/", data=data, headers=headers) as response:
                if response.status == 200:
                    text = await response.text()
                    matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                    for match in matches:
                        subdomains.add(match.lower())
            
            logger.info(f"[DNSDumpster] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[DNSDumpster] Error: {e}")
        return subdomains
    
    async def query_hackertarget(self) -> Set[str]:
        """Query HackerTarget API - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://api.hackertarget.com/hostsearch/?q={self.domain}")
            if text:
                for line in text.split('\n'):
                    if ',' in line:
                        sub = line.split(',')[0].strip().lower()
                        if self.domain in sub:
                            subdomains.add(sub)
            logger.info(f"[HackerTarget] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[HackerTarget] Error: {e}")
        return subdomains
    
    async def query_threatcrowd(self) -> Set[str]:
        """Query ThreatCrowd API - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://www.threatcrowd.org/searchApi/v2/domain/report/?domain={self.domain}")
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(sub.lower())
            logger.info(f"[ThreatCrowd] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ThreatCrowd] Error: {e}")
        return subdomains
    
    async def query_alienvault(self) -> Set[str]:
        """Query AlienVault OTX - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://otx.alienvault.com/api/v1/indicators/domain/{self.domain}/passive_dns")
            if data:
                for item in data.get('passive_dns', []):
                    hostname = item.get('hostname', '').lower()
                    if hostname and self.domain in hostname:
                        subdomains.add(hostname)
            logger.info(f"[AlienVault] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[AlienVault] Error: {e}")
        return subdomains
    
    async def query_urlscan(self) -> Set[str]:
        """Query URLScan.io - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://urlscan.io/api/v1/search/?q=domain:{self.domain}")
            if data:
                for result in data.get('results', []):
                    page = result.get('page', {})
                    domain_info = page.get('domain', '').lower()
                    if domain_info and self.domain in domain_info:
                        subdomains.add(domain_info)
            logger.info(f"[URLScan] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[URLScan] Error: {e}")
        return subdomains
    
    async def query_rapiddns(self) -> Set[str]:
        """Query RapidDNS - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://rapiddns.io/subdomain/{self.domain}?full=1")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[RapidDNS] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[RapidDNS] Error: {e}")
        return subdomains
    
    # ==================== SEARCH ENGINE SOURCES (FREE) ====================
    
    async def query_wayback(self) -> Set[str]:
        """Query Wayback Machine - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(
                f"https://web.archive.org/cdx/search/cdx?url=*.{self.domain}/*&output=json&collapse=urlkey&pageSize=100000"
            )
            if data:
                for record in data[1:]:
                    try:
                        url_part = record[2]
                        parsed = urlparse(url_part)
                        host = parsed.netloc or url_part.split('/')[0]
                        if self.domain in host:
                            subdomains.add(host.lower())
                    except Exception:
                        pass
            logger.info(f"[Wayback] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Wayback] Error: {e}")
        return subdomains
    
    async def query_commoncrawl(self) -> Set[str]:
        """Query Common Crawl Index - FREE"""
        subdomains = set()
        try:
            data = await self._fetch("https://index.commoncrawl.org/collinfo.json")
            if data:
                latest_index = data[0].get('id', '')
                url = f"https://index.commoncrawl.org/{latest_index}-index?url=*.{self.domain}&output=json"
                text = await self._fetch(url)
                if text:
                    for line in text.strip().split('\n'):
                        try:
                            record = json.loads(line)
                            url_part = record.get('url', '')
                            parsed = urlparse(url_part)
                            host = parsed.netloc
                            if self.domain in host:
                                subdomains.add(host.lower())
                        except Exception:
                            pass
            logger.info(f"[CommonCrawl] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[CommonCrawl] Error: {e}")
        return subdomains
    
    # ==================== ADDITIONAL FREE SOURCES ====================
    
    async def query_bufferover(self) -> Set[str]:
        """Query BufferOver.run - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://dns.bufferover.run/dns?q=.{self.domain}")
            if data:
                for item in data.get('FDNS_A', []):
                    parts = item.split(',')
                    if len(parts) > 1:
                        sub = parts[1].lower()
                        if self.domain in sub:
                            subdomains.add(sub)
                for item in data.get('RDNS', []):
                    parts = item.split(',')
                    if len(parts) > 1:
                        sub = parts[1].lower()
                        if self.domain in sub:
                            subdomains.add(sub)
            logger.info(f"[BufferOver] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[BufferOver] Error: {e}")
        return subdomains
    
    async def query_sonarsearch(self) -> Set[str]:
        """Query SonarSearch (Project Sonar) - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://sonar.omnisint.io/subdomains/{self.domain}")
            if data and isinstance(data, list):
                for sub in data:
                    subdomains.add(sub.lower())
            logger.info(f"[SonarSearch] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[SonarSearch] Error: {e}")
        return subdomains
    
    async def query_jldc(self) -> Set[str]:
        """Query JLDC DNS - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://jldc.me/anubis/subdomains/{self.domain}")
            if text:
                try:
                    data = json.loads(text)
                    for sub in data:
                        subdomains.add(sub.lower())
                except:
                    pass
            logger.info(f"[JLDC] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[JLDC] Error: {e}")
        return subdomains
    
    async def query_threatminer(self) -> Set[str]:
        """Query ThreatMiner - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://api.threatminer.org/v2/domain.php?q={self.domain}&rt=5")
            if data:
                for item in data.get('results', []):
                    sub = item.lower()
                    if self.domain in sub:
                        subdomains.add(sub)
            logger.info(f"[ThreatMiner] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ThreatMiner] Error: {e}")
        return subdomains
    
    async def query_anubis(self) -> Set[str]:
        """Query Anubis-DB - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://anubisdb.com/api/subdomains/{self.domain}")
            if data:
                for sub in data:
                    subdomains.add(sub.lower())
            logger.info(f"[AnubisDB] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[AnubisDB] Error: {e}")
        return subdomains
    
    async def query_hackertarget_dns(self) -> Set[str]:
        """Query HackerTarget DNS enumeration - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://api.hackertarget.com/dnsenum/?q={self.domain}")
            if text:
                for line in text.split('\n'):
                    if ':' in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            sub = parts[0].strip().lower()
                            if self.domain in sub:
                                subdomains.add(sub)
            logger.info(f"[HackerTarget DNS] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[HackerTarget DNS] Error: {e}")
        return subdomains
    
    async def query_fullhunt(self) -> Set[str]:
        """Query FullHunt - FREE (no auth required for basic)"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://fullhunt.io/api/v1/domain/{self.domain}/subdomains")
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(sub.lower())
            logger.info(f"[FullHunt] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[FullHunt] Error: {e}")
        return subdomains
    
    async def query_recondev(self) -> Set[str]:
        """Query Recon.dev - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://recon.dev/api/search?domain={self.domain}")
            if data:
                for item in data.get('matches', []):
                    sub = item.get('domain', '').lower()
                    if sub:
                        subdomains.add(sub)
            logger.info(f"[Recon.dev] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Recon.dev] Error: {e}")
        return subdomains
    
    # ==================== NEW FREE SOURCES ====================
    
    async def query_riddler(self) -> Set[str]:
        """Query Riddler.io - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://riddler.io/search/exportcsv?q=pld:{self.domain}")
            if text:
                lines = text.splitlines()
                for line in lines[1:]:  # skip header
                    parts = line.split(',')
                    if len(parts) > 1:
                        sub = parts[1].strip().lower()
                        if self.domain in sub:
                            subdomains.add(sub)
            logger.info(f"[Riddler] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Riddler] Error: {e}")
        return subdomains
    
    async def query_crobat(self) -> Set[str]:
        """Query Crobat API - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://sonar.omnisint.io/subdomains/{self.domain}")
            if data and isinstance(data, list):
                for sub in data:
                    subdomains.add(sub.lower())
            logger.info(f"[Crobat] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Crobat] Error: {e}")
        return subdomains
    
    async def query_certspotter(self) -> Set[str]:
        """Query CertSpotter - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://api.certspotter.com/v1/issuances?domain={self.domain}&include_subdomains=true&expand=dns_names")
            if data:
                for item in data:
                    for name in item.get('dns_names', []):
                        if self.domain in name.lower():
                            subdomains.add(name.lower())
            logger.info(f"[CertSpotter] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[CertSpotter] Error: {e}")
        return subdomains
    
    async def query_entrope(self) -> Set[str]:
        """Query Entrope - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://entrope.com/api/v1/subdomains/{self.domain}")
            if data and isinstance(data, list):
                for sub in data:
                    if isinstance(sub, str):
                        subdomains.add(sub.lower())
            logger.info(f"[Entrope] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Entrope] Error: {e}")
        return subdomains
    
    async def query_dnsdb(self) -> Set[str]:
        """Query DNSDB (limited free access) - FREE"""
        subdomains = set()
        try:
            # Using the free endpoint
            data = await self._fetch(f"https://dnsdb.info/lookup/{self.domain}")
            if data:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), str(data))
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[DNSDB] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[DNSDB] Error: {e}")
        return subdomains
    
    async def query_webcache(self) -> Set[str]:
        """Query Google Web Cache - FREE"""
        subdomains = set()
        try:
            # Google cache search
            text = await self._fetch(f"https://webcache.googleusercontent.com/search?q=site:{self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    if len(match) < 100:  # Avoid false positives
                        subdomains.add(match.lower())
            logger.info(f"[WebCache] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[WebCache] Error: {e}")
        return subdomains
    
    async def query_dnslytics(self) -> Set[str]:
        """Query DNSlytics - FREE (limited)"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://dnslytics.com/domain/{self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[DNSlytics] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[DNSlytics] Error: {e}")
        return subdomains
    
    async def query_viewdns(self) -> Set[str]:
        """Query ViewDNS.info - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://viewdns.info/iphistory.php?domain={self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[ViewDNS] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ViewDNS] Error: {e}")
        return subdomains
    
    async def query_iphistory(self) -> Set[str]:
        """Query IP History - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://iphistory.info/domain/{self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[IPHistory] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[IPHistory] Error: {e}")
        return subdomains
    
    async def query_malwaresite(self) -> Set[str]:
        """Query MalwareDomainList - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://www.malwaredomainlist.com/mdl.php?search={self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[MalwareSite] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[MalwareSite] Error: {e}")
        return subdomains
    
    async def query_threatbrand(self) -> Set[str]:
        """Query ThreatBrand - FREE"""
        subdomains = set()
        try:
            data = await self._fetch(f"https://threatbrand.io/api/domain/{self.domain}")
            if data:
                for sub in data.get('subdomains', []):
                    subdomains.add(sub.lower())
            logger.info(f"[ThreatBrand] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[ThreatBrand] Error: {e}")
        return subdomains
    
    async def query_subdomainfinderc99(self) -> Set[str]:
        """Query SubdomainFinder.c99 - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://subdomainfinder.c99.nl/scans/{self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[SubdomainFinder] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[SubdomainFinder] Error: {e}")
        return subdomains
    
    async def query_dnsdumpster_export(self) -> Set[str]:
        """Query DNSDumpster export - FREE"""
        subdomains = set()
        try:
            await self.init_session()
            
            # Try to get the export directly
            async with self.session.get(f"https://dnsdumpster.com/static/map/{self.domain}.png") as response:
                # This endpoint sometimes reveals subdomains in headers
                pass
            
            # Alternative: parse the main page
            async with self.session.get(f"https://dnsdumpster.com/domain/{self.domain}") as response:
                if response.status == 200:
                    text = await response.text()
                    matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                    for match in matches:
                        subdomains.add(match.lower())
            
            logger.info(f"[DNSDumpster Export] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[DNSDumpster Export] Error: {e}")
        return subdomains
    
    async def query_archive_today(self) -> Set[str]:
        """Query Archive.today - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://archive.today/{self.domain}")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[Archive.today] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[Archive.today] Error: {e}")
        return subdomains
    
    async def query_ipvoid(self) -> Set[str]:
        """Query IPVoid - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://www.ipvoid.com/domain/{self.domain}/")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[IPVoid] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[IPVoid] Error: {e}")
        return subdomains
    
    async def query_urlvoid(self) -> Set[str]:
        """Query URLVoid - FREE"""
        subdomains = set()
        try:
            text = await self._fetch(f"https://www.urlvoid.com/domain/{self.domain}/")
            if text:
                matches = re.findall(r'([a-zA-Z0-9.-]+\.{})'.format(re.escape(self.domain)), text)
                for match in matches:
                    subdomains.add(match.lower())
            logger.info(f"[URLVoid] Found {len(subdomains)} subdomains")
        except Exception as e:
            logger.warning(f"[URLVoid] Error: {e}")
        return subdomains
    
    async def run_all(self) -> Set[str]:
        """
        Execute all passive reconnaissance sources (100% FREE - No API keys required)
        
        Returns:
            Set of discovered subdomains
        """
        tasks = [
            # Certificate sources (FREE)
            self.query_crtsh(),
            self.query_certspotter(),
            
            # DNS sources (FREE)
            self.query_dnsdumpster(),
            self.query_hackertarget(),
            self.query_threatcrowd(),
            self.query_alienvault(),
            self.query_urlscan(),
            self.query_rapiddns(),
            
            # Search engines (FREE)
            self.query_wayback(),
            self.query_commoncrawl(),
            self.query_webcache(),
            self.query_archive_today(),
            
            # Additional FREE sources
            self.query_bufferover(),
            self.query_sonarsearch(),
            self.query_jldc(),
            self.query_threatminer(),
            self.query_anubis(),
            self.query_hackertarget_dns(),
            self.query_fullhunt(),
            self.query_recondev(),
            
            # New FREE sources
            self.query_riddler(),
            self.query_crobat(),
            self.query_entrope(),
            self.query_dnslytics(),
            self.query_viewdns(),
            self.query_iphistory(),
            self.query_subdomainfinderc99(),
            self.query_ipvoid(),
            self.query_urlvoid(),
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_subdomains = set()
        for result in results:
            if isinstance(result, set):
                all_subdomains.update(result)
        
        await self.close_session()
        
        logger.info(f"[Passive Recon] Total subdomains found: {len(all_subdomains)}")
        return all_subdomains
    
    async def run_free_only(self) -> Set[str]:
        """
        Run only completely free sources (alias for run_all for clarity)
        
        Returns:
            Set of discovered subdomains
        """
        return await self.run_all()