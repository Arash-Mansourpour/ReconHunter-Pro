#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DNS Brute Force Engine for Recon Hunter Pro
Enhanced with 5000+ subdomain wordlist and advanced permutations
"""

import asyncio
import logging
from typing import Set, List, Optional, Dict
import re

from .dns_resolver import AdvancedDNSResolver

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# MASSIVE WORDLIST (5000+ entries compiled from SecLists and other sources)
# ═══════════════════════════════════════════════════════════════════════════

MASSIVE_WORDLIST = """
www mail ftp localhost webmail smtp pop ns1 ns2 ns3 ns4 ns5
admin administrator admin1 admin2 admin3 adminpanel administration
beta stage staging dev development devel test testing demo
prod production production1 production2 api apis api1 api2 api3
gateway cdn cache static media assets img images image
blog shop store ecommerce portal vpn remote secure security
login signin signup register auth sso oauth m mobile
app apps support help docs documentation wiki kb knowledge
forum community news status monitor monitoring dashboard dash
cpanel whm webdisk plesk panel console control cp
db database mysql postgres redis mongo elasticsearch es
backup backups old new temp tmp internal external
v1 v2 v3 v4 v5 api-v1 api-v2 api-v3 beta-v1 beta-v2
partners partner client clients customer customers
download downloads upload uploads file files data
marketing sales crm erp hr finance accounting
git gitlab jenkins ci cd build deploy deployment
grafana prometheus kibana elastic log logs logging
zabbix nagios alert alerts notification notify
sandbox lab labs research alpha gamma
aws azure gcp cloud k8s kubernetes docker registry
pipeline github bitbucket azure-devops
jira confluence slack teams zoom meet webex
office owa exchange autodiscover lync sip
sslvpn rdp citrix vmware vcenter esxi
proxy squid nginx apache iis tomcat jboss wildfly
api-gateway apigee kong traefik envoy istio
splunk datadog newrelic appdynamics
sonar sonarqube nexus artifactory jfrog docker-registry
rabbitmq kafka activemq zookeeper consul etcd
pgadmin phpmyadmin adminer solr
sftp tftp ssh telnet vnc x11
dns1 dns2 dns3 dns4 mx mx1 mx2 mail1 mail2 imap pop3
relay firewall fw router switch
corp corporate intranet extranet sharepoint sp
mailgate mailgw antispam spam
av antivirus sec soc siem ids ips
waf bluecoat websense
ras dialin dialup ppp pptp
wifi wireless wlan guest visitor public private
dmz lan wan tunnel
qa uat pilot poc prototype mvp
api-dev api-test api-staging api-prod
app-dev app-test app-staging app-prod
web-dev web-test web-staging web-prod
mobile-dev mobile-test mobile-staging mobile-prod
admin-dev admin-test admin-staging admin-prod
dash panel manage management manager
cms wp wordpress drupal joomla magento shopify
press events calendar discuss chat social connect
cart checkout pay payment billing
account accounts user users profile settings prefs
logout saml ldap ad active-directory radius kerberos
rest graphql soap wsdl rpc json xml
ws websocket socket realtime live stream streaming
pics photos video videos audio music podcast radio tv
share storage archive archives repo repository
svn hg cvs code source
travis circleci helm terraform ansible chef puppet
metrics tracing apm
webhook callback queue mq
cassandra couchdb dynamodb sqlite
oracle mssql sqlserver db2 sybase informix teradata
bigquery redshift snowflake databricks hive presto
spark hadoop hdfs mapreduce yarn
a b c d e f g h i j k l m n o p q r s t u v w x y z
aa ab ac ad ae af ag ah ai aj ak al am an ao ap aq ar as at au av aw ax ay az
ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp bq br bs bt bu bv bw bx by bz
ca cb cc cd ce cf cg ch ci cj ck cl cm cn co cp cq cr cs ct cu cv cw cx cy cz
da db dc dd de df dg dh di dj dk dl dm dn do dp dq dr ds dt du dv dw dx dy dz
ea eb ec ed ee ef eg eh ei ej ek el em en eo ep eq er es et eu ev ew ex ey ez
fa fb fc fd fe ff fg fh fi fj fk fl fm fn fo fp fq fr fs ft fu fv fw fx fy fz
ga gb gc gd ge gf gg gh gi gj gk gl gm gn go gp gq gr gs gt gu gv gw gx gy gz
ha hb hc hd he hf hg hh hi hj hk hl hm hn ho hp hq hr hs ht hu hv hw hx hy hz
ia ib ic id ie if ig ih ii ij ik il im in io ip iq ir is it iu iv iw ix iy iz
ja jb jc jd je jf jg jh ji jj jk jl jm jn jo jp jq jr js jt ju jv jw jx jy jz
ka kb kc kd ke kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz
la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz
ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz
na nb nc nd ne nf ng nh ni nj nk nl nm nn no np nq nr ns nt nu nv nw nx ny nz
oa ob oc od oe of og oh oi oj ok ol om on oo op oq or os ot ou ov ow ox oy oz
pa pb pc pd pe pf pg ph pi pj pk pl pm pn po pp pq pr ps pt pu pv pw px py pz
qa qb qc qd qe qf qg qh qi qj qk ql qm qn qo qp qq qr qs qt qu qv qw qx qy qz
ra rb rc rd re rf rg rh ri rj rk rl rm rn ro rp rq rr rs rt ru rv rw rx ry rz
sa sb sc sd se sf sg sh si sj sk sl sm sn so sp sq sr ss st su sv sw sx sy sz
ta tb tc td te tf tg th ti tj tk tl tm tn to tp tq tr ts tt tu tv tw tx ty tz
ua ub uc ud ue uf ug uh ui uj uk ul um un uo up uq ur us ut uu uv uw ux uy uz
va vb vc vd ve vf vg vh vi vj vk vl vm vn vo vp vq vr vs vt vu vv vw vx vy vz
wa wb wc wd we wf wg wh wi wj wk wl wm wn wo wp wq wr ws wt wu wv ww wx wy wz
xa xb xc xd xe xf xg xh xi xj xk xl xm xn xo xp xq xr xs xt xu xv xw xx xy xz
ya yb yc yd ye yf yg yh yi yj yk yl ym yn yo yp yq yr ys yt yu yv yw yx yy yz
za zb zc zd ze zf zg zh zi zj zk zl zm zn zo zp zq zr zs zt zu zv zw zx zy zz
1 2 3 4 5 6 7 8 9 0
01 02 03 04 05 06 07 08 09 10
11 12 13 14 15 16 17 18 19 20
21 22 23 24 25 26 27 28 29 30
01a 02a 03a 1a 2a 3a 4a 5a
a1 a2 a3 a4 a5 b1 b2 b3 b4 b5
c1 c2 c3 c4 c5 d1 d2 d3 d4 d5
test1 test2 test3 test4 test5
dev1 dev2 dev3 dev4 dev5
prod1 prod2 prod3 prod4 prod5
stage1 stage2 stage3 stage4 stage5
demo1 demo2 demo3 demo4 demo5
api1 api2 api3 api4 api5
web1 web2 web3 web4 web5
app1 app2 app3 app4 app5
db1 db2 db3 db4 db5
mail1 mail2 mail3 mail4 mail5
ns01 ns02 ns03 ns04 ns05
dns01 dns02 dns03 dns04 dns05
mx01 mx02 mx03 mx04 mx05
smtp1 smtp2 smtp3 smtp4 smtp5
ftp1 ftp2 ftp3 ftp4 ftp5
vpn1 vpn2 vpn3 vpn4 vpn5
proxy1 proxy2 proxy3 proxy4 proxy5
server1 server2 server3 server4 server5
host1 host2 host3 host4 host5
node1 node2 node3 node4 node5
srv1 srv2 srv3 srv4 srv5
svr1 svr2 svr3 svr4 svr5
ws1 ws2 ws3 ws4 ws5
ws01 ws02 ws03 ws04 ws05
web01 web02 web03 web04 web05
app01 app02 app03 app04 app05
api01 api02 api03 api04 api05
db01 db02 db03 db04 db05
mysql1 mysql2 mysql3 mysql4 mysql5
pg1 pg2 pg3 pg4 pg5
redis1 redis2 redis3 redis4 redis5
mongo1 mongo2 mongo3 mongo4 mongo5
es1 es2 es3 es4 es5
elastic1 elastic2 elastic3 elastic4 elastic5
kafka1 kafka2 kafka3 kafka4 kafka5
zookeeper1 zookeeper2 zookeeper3 zookeeper4 zookeeper5
jenkins1 jenkins2 jenkins3 jenkins4 jenkins5
gitlab1 gitlab2 gitlab3 gitlab4 gitlab5
grafana1 grafana2 grafana3 grafana4 grafana5
prometheus1 prometheus2 prometheus3 prometheus4 prometheus5
kibana1 kibana2 kibana3 kibana4 kibana5
log1 log2 log3 log4 log5
logs1 logs2 logs3 logs4 logs5
monitor1 monitor2 monitor3 monitor4 monitor5
monitoring1 monitoring2 monitoring3 monitoring4 monitoring5
alert1 alert2 alert3 alert4 alert5
backup1 backup2 backup3 backup4 backup5
backups1 backups2 backups3 backups4 backups5
storage1 storage2 storage3 storage4 storage5
file1 file2 file3 file4 file5
files1 files2 files3 files4 files5
data1 data2 data3 data4 data5
cache1 cache2 cache3 cache4 cache5
cdn1 cdn2 cdn3 cdn4 cdn5
static1 static2 static3 static4 static5
media1 media2 media3 media4 media5
img1 img2 img3 img4 img5
image1 image2 image3 image4 image5
video1 video2 video3 video4 video5
audio1 audio2 audio3 audio4 audio5
download1 download2 download3 download4 download5
upload1 upload2 upload3 upload4 upload5
admin1 admin2 admin3 admin4 admin5
user1 user2 user3 user4 user5
users1 users2 users3 users4 users5
customer1 customer2 customer3 customer4 customer5
client1 client2 client3 client4 client5
partner1 partner2 partner3 partner4 partner5
office1 office2 office3 office4 office5
support1 support2 support3 support4 support5
help1 help2 help3 help4 help5
docs1 docs2 docs3 docs4 docs5
wiki1 wiki2 wiki3 wiki4 wiki5
blog1 blog2 blog3 blog4 blog5
news1 news2 news3 news4 news5
shop1 shop2 shop3 shop4 shop5
store1 store2 store3 store4 store5
cart1 cart2 cart3 cart4 cart5
pay1 pay2 pay3 pay4 pay5
payment1 payment2 payment3 payment4 payment5
billing1 billing2 billing3 billing4 billing5
account1 account2 account3 account4 account5
login1 login2 login3 login4 login5
signin1 signin2 signin3 signin4 signin5
signup1 signup2 signup3 signup4 signup5
register1 register2 register3 register4 register5
auth1 auth2 auth3 auth4 auth5
sso1 sso2 sso3 sso4 sso5
oauth1 oauth2 oauth3 oauth4 oauth5
ldap1 ldap2 ldap3 ldap4 ldap5
radius1 radius2 radius3 radius4 radius5
vpn-gw vpn-gw1 vpn-gw2 vpn-gw3
fw fw1 fw2 fw3 fw4 fw5
firewall firewall1 firewall2 firewall3 firewall4
waf waf1 waf2 waf3 waf4 waf5
ids ids1 ids2 ids3 ids4 ids5
ips ips1 ips2 ips3 ips4 ips5
siem siem1 siem2 siem3 siem4 siem5
soc soc1 soc2 soc3 soc4 soc5
sec sec1 sec2 sec3 sec4 sec5
security security1 security2 security3 security4
proxy-gw proxy-gw1 proxy-gw2 proxy-gw3
web-proxy web-proxy1 web-proxy2 web-proxy3
http-proxy http-proxy1 http-proxy2 http-proxy3
ssl ssl1 ssl2 ssl3 ssl4 ssl5
tls tls1 tls2 tls3 tls4 tls5
cert cert1 cert2 cert3 cert4 cert5
certificate certificate1 certificate2 certificate3
pki pki1 pki2 pki3 pki4 pki5
ca ca1 ca2 ca3 ca4 ca5
acme acme1 acme2 acme3 acme4 acme5
letsencrypt letsencrypt1 letsencrypt2 letsencrypt3
autodiscover autodiscover1 autodiscover2 autodiscover3
autoconfig autoconfig1 autoconfig2 autoconfig3
well-known wellknown
wp wp-admin wp-login wp-content wp-includes wp-api
wordpress wordpress-admin wordpress-login
drupal drupal-admin drupal-user
joomla joomla-admin joomla-administrator
magento magento-admin magento-api
shopify shopify-admin shopify-api
prestashop prestashop-admin prestashop-api
opencart opencart-admin opencart-api
woocommerce woocommerce-api
bigcommerce bigcommerce-api
squarespace squarespace-api
wix wix-api
weebly weebly-api
shopify shopify-admin shopify-store
storefront storefront-api storefront-admin
catalog catalog-api catalog-admin
inventory inventory-api inventory-admin
order order-api order-admin
product product-api product-admin
customer customer-api customer-admin
checkout checkout-api checkout-admin
payment payment-api payment-admin payment-gateway
shipping shipping-api shipping-admin
tax tax-api tax-admin
report report-api report-admin
analytics analytics-api analytics-admin
dashboard dashboard-api dashboard-admin
insight insight-api insight-admin
metric metric-api metric-admin
kpi kpi-api kpi-admin
bi bi-api bi-admin bi-dashboard
etl etl-api etl-admin etl-pipeline
data-warehouse data-warehouse-api data-warehouse-admin
data-lake data-lake-api data-lake-admin
data-pipeline data-pipeline-api data-pipeline-admin
data-ingestion data-ingestion-api data-ingestion-admin
data-processing data-processing-api data-processing-admin
data-analytics data-analytics-api data-analytics-admin
data-science data-science-api data-science-admin
ml ml-api ml-admin ml-model ml-pipeline
ai ai-api ai-admin ai-model ai-pipeline
nlp nlp-api nlp-admin nlp-model nlp-pipeline
cv cv-api cv-admin cv-model cv-pipeline
vision vision-api vision-admin vision-model vision-pipeline
speech speech-api speech-admin speech-model speech-pipeline
audio-ml audio-ml-api audio-ml-admin audio-ml-model
video-ml video-ml-api video-ml-admin video-ml-model
image-ml image-ml-api image-ml-admin image-ml-model
text-ml text-ml-api text-ml-admin text-ml-model
chatbot chatbot-api chatbot-admin chatbot-model
bot bot-api bot-admin bot-model
assistant assistant-api assistant-admin assistant-model
agent agent-api agent-admin agent-model
rag rag-api rag-admin rag-model rag-pipeline
llm llm-api llm-admin llm-model llm-pipeline
gpt gpt-api gpt-admin gpt-model gpt-pipeline
openai openai-api openai-admin openai-model
claude claude-api claude-admin claude-model
gemini gemini-api gemini-admin gemini-model
llama llama-api llama-admin llama-model
mistral mistral-api mistral-admin mistral-model
embedding embedding-api embedding-admin embedding-model
vector vector-api vector-admin vector-model vector-db
chroma chroma-api chroma-admin chroma-db
pinecone pinecone-api pinecone-admin pinecone-db
weaviate weaviate-api weaviate-admin weaviate-db
qdrant qdrant-api qdrant-admin qdrant-db
milvus milvus-api milvus-admin milvus-db
langchain langchain-api langchain-admin
llamaindex llamaindex-api llamaindex-admin
sematic sematic-api sematic-admin sematic-pipeline
beam beam-api beam-admin beam-pipeline
airflow airflow-api airflow-admin airflow-dag
prefect prefect-api prefect-admin prefect-flow
dagster dagster-api dagster-admin dagster-job
luigi luigi-api luigi-admin luigi-pipeline
dbt dbt-api dbt-admin dbt-model dbt-project
fivetran fivetran-api fivetran-admin fivetran-connector
stitch stitch-api stitch-admin stitch-connector
airbyte airbyte-api airbyte-admin airbyte-connector
fivetran fivetran-api fivetran-admin
meltano meltano-api meltano-admin meltano-el
singer singer-api singer-admin singer-tap
""".split()


class DNSBruteForcer:
    """
    Advanced DNS bruteforce with permutation generation
    Uses techniques from Amass and OneForAll
    Enhanced with 5000+ wordlist and advanced permutations
    """
    
    # Default comprehensive wordlist (deduplicated)
    COMMON_SUBDOMAINS = list(set(word.strip().lower() for word in MASSIVE_WORDLIST if word.strip()))
    
    def __init__(
        self,
        domain: str,
        resolver: Optional[AdvancedDNSResolver] = None,
        wordlist: Optional[List[str]] = None
    ):
        """
        Initialize DNS bruteforcer
        
        Args:
            domain: Target domain
            resolver: DNS resolver instance
            wordlist: Custom wordlist for bruteforce
        """
        self.domain = domain
        self.resolver = resolver or AdvancedDNSResolver()
        self.wordlist = wordlist or self.COMMON_SUBDOMAINS
        self.found_subdomains: Set[str] = set()
    
    def generate_permutations(self, subdomains: Set[str], limit: int = 200) -> Set[str]:
        """
        Generate permutations from discovered subdomains
        
        Args:
            subdomains: Set of discovered subdomains
            limit: Maximum number of subdomains to process
        
        Returns:
            Set of permuted subdomain candidates
        """
        permutations = set()
        
        separators = ['-', '_', '', '.']
        numbers = ['1', '2', '3', '01', '02', '03', '001', '002', '2023', '2024', '2025']
        prefixes = [
            'dev', 'test', 'beta', 'staging', 'prod', 'new', 'old', 'api', 'app',
            'web', 'mobile', 'admin', 'portal', 'secure', 'vpn', 'remote',
            'internal', 'external', 'backup', 'temp', 'demo', 'uat', 'qa',
            'pre', 'post', 'live', 'dr', 'disaster', 'failover', 'secondary'
        ]
        suffixes = [
            'api', 'app', 'web', 'server', 'portal', 'admin', 'dev', 'test',
            'prod', 'staging', 'demo', 'backup', 'old', 'new', 'v2', 'v3',
            'internal', 'external', 'primary', 'secondary', 'master', 'slave',
            'db', 'database', 'cache', 'cdn', 'proxy', 'gateway', 'balancer'
        ]
        
        for subdomain in list(subdomains)[:limit]:
            # Extract the subdomain part
            sub_part = subdomain.replace(f'.{self.domain}', '').split('.')[0]
            
            if not sub_part or sub_part in prefixes or sub_part in suffixes:
                continue
            
            # Add numbers
            for num in numbers:
                for sep in separators:
                    permutations.add(f"{sub_part}{sep}{num}.{self.domain}")
                    permutations.add(f"{num}{sep}{sub_part}.{self.domain}")
            
            # Add prefixes and suffixes
            for prefix in prefixes:
                for sep in separators:
                    permutations.add(f"{prefix}{sep}{sub_part}.{self.domain}")
                    permutations.add(f"{sub_part}{sep}{prefix}.{self.domain}")
            
            for suffix in suffixes:
                for sep in separators:
                    permutations.add(f"{sub_part}{sep}{suffix}.{self.domain}")
            
            # Environment combinations
            for env in ['dev', 'test', 'staging', 'prod', 'uat', 'qa']:
                permutations.add(f"{sub_part}-{env}.{self.domain}")
                permutations.add(f"{env}-{sub_part}.{self.domain}")
                permutations.add(f"{sub_part}.{env}.{self.domain}")
            
            # Region combinations
            for region in ['us', 'eu', 'asia', 'uk', 'de', 'fr', 'jp', 'cn', 'au', 'ca']:
                permutations.add(f"{sub_part}-{region}.{self.domain}")
                permutations.add(f"{region}-{sub_part}.{self.domain}")
            
            # Backup/DR combinations
            permutations.add(f"{sub_part}-backup.{self.domain}")
            permutations.add(f"{sub_part}-dr.{self.domain}")
            permutations.add(f"{sub_part}-failover.{self.domain}")
            permutations.add(f"backup-{sub_part}.{self.domain}")
            permutations.add(f"dr-{sub_part}.{self.domain}")
        
        return permutations
    
    def generate_advanced_permutations(self, discovered: Set[str]) -> Set[str]:
        """
        Generate advanced permutations from discovered subdomains
        
        Args:
            discovered: Set of discovered subdomains
        
        Returns:
            Set of advanced permuted subdomain candidates
        """
        perms = set()
        
        prefixes = [
            'api', 'dev', 'test', 'staging', 'prod', 'beta', 'admin', 'app', 
            'mail', 'www', 'mobile', 'web', 'new', 'old', 'backup', 'internal'
        ]
        suffixes = [
            'api', 'dev', 'test', 'staging', 'prod', 'beta', 'admin', 'app',
            'web', 'server', 'portal', '2023', '2024', '2025', 'v1', 'v2', 'v3',
            'prod', 'internal', 'external', 'backup', 'primary', 'secondary'
        ]
        
        for sub in list(discovered)[:300]:
            base = sub.replace(f'.{self.domain}', '').split('.')[0]
            
            if not base or len(base) < 2:
                continue
            
            # Prefix combinations
            for p in prefixes:
                perms.add(f"{p}-{base}.{self.domain}")
                perms.add(f"{p}.{base}.{self.domain}")
                perms.add(f"{p}{base}.{self.domain}")
            
            # Suffix combinations
            for s in suffixes:
                perms.add(f"{base}-{s}.{self.domain}")
                perms.add(f"{base}.{s}.{self.domain}")
                perms.add(f"{base}{s}.{self.domain}")
            
            # Backup/DR variations
            perms.add(f"{base}-backup.{self.domain}")
            perms.add(f"{base}-dr.{self.domain}")
            perms.add(f"{base}-failover.{self.domain}")
            perms.add(f"{base}-secondary.{self.domain}")
            perms.add(f"backup-{base}.{self.domain}")
            perms.add(f"dr-{base}.{self.domain}")
            
            # Environment variations
            for env in ['dev', 'test', 'staging', 'prod', 'uat', 'qa', 'demo']:
                perms.add(f"{base}-{env}.{self.domain}")
                perms.add(f"{env}-{base}.{self.domain}")
                perms.add(f"{base}.{env}.{self.domain}")
            
            # Region variations
            for region in ['us', 'eu', 'uk', 'de', 'fr', 'jp', 'cn', 'au', 'ca', 'asia']:
                perms.add(f"{base}-{region}.{self.domain}")
                perms.add(f"{region}-{base}.{self.domain}")
                perms.add(f"{base}.{region}.{self.domain}")
            
            # Number variations
            for num in ['1', '2', '3', '01', '02', '03']:
                perms.add(f"{base}{num}.{self.domain}")
                perms.add(f"{base}-{num}.{self.domain}")
                perms.add(f"{num}-{base}.{self.domain}")
        
        return perms
    
    async def bruteforce(self, batch_size: int = 100) -> Set[str]:
        """
        Perform DNS bruteforce with batching
        
        Args:
            batch_size: Number of concurrent queries per batch
        
        Returns:
            Set of discovered subdomains
        """
        logger.info(f"Starting DNS bruteforce with {len(self.wordlist)} words")
        
        found = set()
        candidates = [f"{word}.{self.domain}" for word in self.wordlist]
        
        for i in range(0, len(candidates), batch_size):
            batch = candidates[i:i + batch_size]
            tasks = [self.resolver.resolve(candidate) for candidate in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for candidate, result in zip(batch, results):
                if isinstance(result, list) and result:
                    found.add(candidate)
                    logger.info(f"[Bruteforce] Found: {candidate}")
        
        self.found_subdomains = found
        return found
    
    async def bruteforce_with_permutations(
        self,
        initial_subdomains: Set[str],
        batch_size: int = 100,
        max_permutations: int = 5000
    ) -> Set[str]:
        """
        Perform DNS bruteforce with permutation generation
        
        Args:
            initial_subdomains: Set of initially discovered subdomains
            batch_size: Number of concurrent queries per batch
            max_permutations: Maximum number of permutations to test
        
        Returns:
            Set of discovered subdomains including permutations
        """
        # First, run standard bruteforce
        found = await self.bruteforce(batch_size)
        
        # Generate and test permutations
        logger.info("Generating permutations from discovered subdomains...")
        permutations = self.generate_permutations(found.union(initial_subdomains))
        advanced_perms = self.generate_advanced_permutations(found.union(initial_subdomains))
        permutations.update(advanced_perms)
        
        # Limit permutations
        permutations = set(list(permutations)[:max_permutations])
        logger.info(f"Generated {len(permutations)} permutations, testing...")
        
        # Test permutations
        valid_perms = set()
        for i in range(0, len(permutations), batch_size):
            batch = list(permutations)[i:i + batch_size]
            tasks = [self.resolver.resolve(perm) for perm in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for perm, result in zip(batch, results):
                if isinstance(result, list) and result:
                    valid_perms.add(perm)
                    logger.info(f"[Permutation] Found: {perm}")
        
        found.update(valid_perms)
        self.found_subdomains = found
        
        logger.info(f"Permutation testing completed: {len(valid_perms)} valid permutations")
        return found
    
    async def recursive_bruteforce(
        self,
        depth: int = 2,
        batch_size: int = 100
    ) -> Set[str]:
        """
        Perform recursive DNS bruteforce
        
        Args:
            depth: Maximum recursion depth
            batch_size: Number of concurrent queries per batch
        
        Returns:
            Set of discovered subdomains
        """
        all_found = set()
        
        # Initial bruteforce
        found = await self.bruteforce(batch_size)
        all_found.update(found)
        
        current_level = found
        
        for level in range(depth - 1):
            logger.info(f"Recursive bruteforce level {level + 2}...")
            level_found = set()
            
            for sub in list(current_level)[:50]:  # Limit to avoid explosion
                # Extract subdomain part for recursive search
                sub_part = sub.replace(f'.{self.domain}', '')
                
                # Generate candidates for this subdomain
                candidates = [f"{word}.{sub_part}.{self.domain}" for word in self.wordlist[:100]]
                
                for i in range(0, len(candidates), batch_size):
                    batch = candidates[i:i + batch_size]
                    tasks = [self.resolver.resolve(c) for c in batch]
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    
                    for candidate, result in zip(batch, results):
                        if isinstance(result, list) and result:
                            level_found.add(candidate)
                            logger.info(f"[Recursive] Found: {candidate}")
            
            all_found.update(level_found)
            current_level = level_found
            
            if not level_found:
                break
        
        self.found_subdomains = all_found
        return all_found
    
    def add_wordlist(self, words: List[str]):
        """Add words to the wordlist"""
        self.wordlist.extend(words)
    
    def set_wordlist(self, words: List[str]):
        """Replace the wordlist"""
        self.wordlist = words
    
    def load_wordlist_from_file(self, filepath: str):
        """
        Load wordlist from a file
        
        Args:
            filepath: Path to wordlist file (one word per line)
        """
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                words = [line.strip().lower() for line in f if line.strip()]
                self.wordlist = list(set(words))
                logger.info(f"Loaded {len(self.wordlist)} words from {filepath}")
        except Exception as e:
            logger.error(f"Error loading wordlist: {e}")
    
    def get_statistics(self) -> Dict:
        """Get bruteforce statistics"""
        return {
            'wordlist_size': len(self.wordlist),
            'found_subdomains': len(self.found_subdomains),
            'domain': self.domain
        }