#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Advanced DNS Resolver for Recon Hunter Pro
"""

import asyncio
import aiodns
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)


class AdvancedDNSResolver:
    """
    High-performance DNS resolver with caching and multiple servers
    Based on best practices from bug bounty tools
    """
    
    DNS_SERVERS = [
        '8.8.8.8',          # Google
        '8.8.4.4',          # Google Secondary
        '1.1.1.1',          # Cloudflare
        '1.0.0.1',          # Cloudflare Secondary
        '9.9.9.9',          # Quad9
        '208.67.222.222',   # OpenDNS
        '208.67.220.220',   # OpenDNS Secondary
        '76.76.19.19',      # Control D
        '76.76.2.0',        # Control D Secondary
        '94.140.14.14',     # AdGuard
    ]
    
    def __init__(self, timeout: int = 5, max_retries: int = 3):
        """
        Initialize DNS resolver
        
        Args:
            timeout: DNS query timeout in seconds
            max_retries: Maximum number of retries for failed queries
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache: Dict[str, List[str]] = {}
        self.resolver: Optional[aiodns.DNSResolver] = None
    
    async def _get_resolver(self) -> aiodns.DNSResolver:
        """Get or create DNS resolver"""
        if not self.resolver:
            self.resolver = aiodns.DNSResolver(timeout=self.timeout)
        return self.resolver
    
    async def resolve(self, domain: str, record_type: str = 'A') -> List[str]:
        """
        Async DNS resolution with caching
        
        Args:
            domain: Domain to resolve
            record_type: DNS record type (A, AAAA, CNAME, MX, TXT, NS, SOA)
        
        Returns:
            List of resolved records
        """
        cache_key = f"{domain}_{record_type}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        resolver = await self._get_resolver()
        
        for attempt in range(self.max_retries):
            try:
                result = await resolver.query(domain, record_type)
                
                records = []
                for r in result:
                    if hasattr(r, 'host'):
                        records.append(r.host)
                    elif hasattr(r, 'address'):
                        records.append(r.address)
                    elif hasattr(r, 'target'):
                        records.append(str(r.target).rstrip('.'))
                    elif hasattr(r, 'exchange'):
                        records.append(str(r.exchange).rstrip('.'))
                    elif hasattr(r, 'text'):
                        records.append(r.text)
                    elif hasattr(r, 'strings'):
                        for s in r.strings:
                            records.append(s.decode('utf-8', errors='ignore'))
                
                self.cache[cache_key] = records
                return records
                
            except aiodns.error.DNSError:
                if attempt == self.max_retries - 1:
                    return []
                await asyncio.sleep(0.5 * (attempt + 1))
            except Exception as e:
                logger.debug(f"DNS error for {domain} ({record_type}): {e}")
                return []
        
        return []
    
    async def resolve_all(self, domain: str) -> Dict[str, List[str]]:
        """
        Resolve all common record types for a domain
        
        Args:
            domain: Domain to resolve
        
        Returns:
            Dictionary with record types as keys and lists of records as values
        """
        record_types = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SOA']
        results = {}
        
        for record_type in record_types:
            try:
                results[record_type] = await self.resolve(domain, record_type)
            except Exception:
                results[record_type] = []
        
        return results
    
    async def reverse_lookup(self, ip: str) -> List[str]:
        """
        Perform reverse DNS lookup
        
        Args:
            ip: IP address to reverse lookup
        
        Returns:
            List of hostnames
        """
        try:
            import dns.reversename
            reversed_ip = dns.reversename.from_address(ip)
            resolver = await self._get_resolver()
            result = await resolver.query(str(reversed_ip), 'PTR')
            
            hostnames = []
            for r in result:
                if hasattr(r, 'target'):
                    hostnames.append(str(r.target).rstrip('.'))
            
            return hostnames
        except Exception as e:
            logger.debug(f"Reverse lookup error for {ip}: {e}")
            return []
    
    async def get_soa(self, domain: str) -> Optional[Dict]:
        """
        Get SOA record for a domain
        
        Args:
            domain: Domain to query
        
        Returns:
            SOA record information or None
        """
        try:
            resolver = await self._get_resolver()
            result = await resolver.query(domain, 'SOA')
            
            if result:
                r = result[0]
                return {
                    'mname': str(r.mname).rstrip('.') if hasattr(r, 'mname') else '',
                    'rname': str(r.rname).rstrip('.') if hasattr(r, 'rname') else '',
                    'serial': r.serial if hasattr(r, 'serial') else 0,
                    'refresh': r.refresh if hasattr(r, 'refresh') else 0,
                    'retry': r.retry if hasattr(r, 'retry') else 0,
                    'expire': r.expire if hasattr(r, 'expire') else 0,
                    'minimum': r.minimum if hasattr(r, 'minimum') else 0
                }
        except Exception as e:
            logger.debug(f"SOA lookup error for {domain}: {e}")
        
        return None
    
    def clear_cache(self):
        """Clear the DNS cache"""
        self.cache.clear()
    
    async def batch_resolve(self, domains: List[str], record_type: str = 'A') -> Dict[str, List[str]]:
        """
        Resolve multiple domains in parallel
        
        Args:
            domains: List of domains to resolve
            record_type: DNS record type
        
        Returns:
            Dictionary mapping domains to their resolved records
        """
        tasks = {domain: self.resolve(domain, record_type) for domain in domains}
        results = {}
        
        for domain, task in tasks.items():
            try:
                results[domain] = await task
            except Exception:
                results[domain] = []
        
        return results


# Alias for backwards compatibility
DNSResolver = AdvancedDNSResolver