#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Data models for Recon Hunter Pro
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum


class ScanLevel(Enum):
    """Scan intensity levels"""
    PASSIVE = "passive"
    NORMAL = "normal"
    AGGRESSIVE = "aggressive"
    STEALTH = "stealth"
    ULTIMATE = "ultimate"


@dataclass
class SubdomainInfo:
    """Enhanced subdomain information model"""
    domain: str
    ips: List[str] = field(default_factory=list)
    cnames: List[str] = field(default_factory=list)
    mx_records: List[str] = field(default_factory=list)
    txt_records: List[str] = field(default_factory=list)
    ns_records: List[str] = field(default_factory=list)
    soa_record: Optional[Dict] = None
    status_code: Optional[int] = None
    title: str = ""
    server: str = ""
    technologies: List[str] = field(default_factory=list)
    waf: Optional[str] = None
    cdn: Optional[str] = None
    ssl_info: Optional[Dict] = field(default_factory=dict)
    open_ports: List[Dict] = field(default_factory=list)
    vulnerabilities: List[Dict] = field(default_factory=list)
    screenshot: Optional[str] = None
    js_files: List[str] = field(default_factory=list)
    js_secrets: List[Dict] = field(default_factory=list)
    api_endpoints: List[str] = field(default_factory=list)
    emails: List[str] = field(default_factory=list)
    takeover_vulnerable: bool = False
    takeover_type: Optional[str] = None
    cloud_buckets: List[Dict] = field(default_factory=list)
    content_type: str = ""
    content_length: int = 0
    redirect_url: Optional[str] = None
    response_time: float = 0.0
    headers: Dict[str, str] = field(default_factory=dict)
    cookies: Dict[str, str] = field(default_factory=dict)
    security_headers: Dict[str, Any] = field(default_factory=dict)
    historical_ips: List[Dict] = field(default_factory=list)


@dataclass
class VulnerabilityInfo:
    """Vulnerability information model"""
    name: str
    severity: str  # critical, high, medium, low, info
    description: str
    url: str
    evidence: str
    cve_id: Optional[str] = None
    cvss_score: Optional[float] = None
    remediation: str = ""
    references: List[str] = field(default_factory=list)


@dataclass
class ScanResult:
    """Complete scan result model"""
    domain: str
    scan_time: str = ""
    scan_level: str = "normal"
    start_time: str = ""
    end_time: str = ""
    duration: str = ""
    status: str = "pending"
    error: Optional[str] = None
    subdomains: Dict[str, Any] = field(default_factory=dict)
    summary: Dict[str, Any] = field(default_factory=lambda: {
        'total_subdomains': 0,
        'alive_services': 0,
        'unique_ips': [],
        'cdn_count': 0,
        'technologies': [],
        'wafs': [],
        'takeover_vulnerable': 0,
        'secrets_found': 0,
        'cloud_buckets': 0,
        'vulnerabilities': 0
    })
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'domain': self.domain,
            'scan_time': self.scan_time,
            'scan_level': self.scan_level,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'duration': self.duration,
            'status': self.status,
            'error': self.error,
            'subdomains': self.subdomains,
            'summary': self.summary
        }


def asdict(dataclass_obj) -> Dict:
    """Convert dataclass to dictionary, handling nested dataclasses"""
    if hasattr(dataclass_obj, '__dataclass_fields__'):
        result = {}
        for field_name in dataclass_obj.__dataclass_fields__:
            value = getattr(dataclass_obj, field_name)
            if hasattr(value, '__dataclass_fields__'):
                result[field_name] = asdict(value)
            elif isinstance(value, list):
                result[field_name] = [asdict(item) if hasattr(item, '__dataclass_fields__') else item for item in value]
            elif isinstance(value, dict):
                result[field_name] = {k: asdict(v) if hasattr(v, '__dataclass_fields__') else v for k, v in value.items()}
            elif isinstance(value, set):
                result[field_name] = list(value)
            else:
                result[field_name] = value
        return result
    return dataclass_obj