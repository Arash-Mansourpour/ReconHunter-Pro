#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration settings for Recon Hunter Pro
100% Free and Open-Source - No API Keys Required
"""

from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum


class ScanLevel(Enum):
    """Scan intensity levels"""
    PASSIVE = "passive"
    NORMAL = "normal"
    AGGRESSIVE = "aggressive"
    ULTIMATE = "ultimate"


class AlertSeverity(Enum):
    """Alert severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class Config:
    """
    Configuration settings for the reconnaissance application
    100% Free - No paid API keys required
    """
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SCAN SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Default scan level
    DEFAULT_SCAN_LEVEL: str = "normal"
    
    # Rate limiting
    REQUEST_DELAY: float = 0.1
    MAX_CONCURRENT_REQUESTS: int = 50
    TIMEOUT: int = 30
    
    # DNS settings
    DNS_TIMEOUT: int = 5
    DNS_MAX_RETRIES: int = 3
    DNS_BATCH_SIZE: int = 100
    
    # Bruteforce settings
    BRUTEFORCE_BATCH_SIZE: int = 100
    BRUTEFORCE_MAX_PERMUTATIONS: int = 5000
    BRUTEFORCE_RECURSION_DEPTH: int = 2
    
    # HTTP probing
    HTTP_TIMEOUT: int = 15
    HTTP_MAX_REDIRECTS: int = 10
    HTTP_USER_AGENT: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    # Port scanning
    PORT_SCAN_TIMEOUT: int = 2
    PORT_SCAN_TOP_PORTS: int = 1000
    PORT_SCAN_THREADS: int = 100
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROXY SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    USE_PROXY: bool = False
    PROXY_LIST: List[str] = field(default_factory=list)
    PROXY_ROTATION: bool = True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STEALTH SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    STEALTH_MODE: bool = False
    STEALTH_DELAY_MIN: float = 2.0
    STEALTH_DELAY_MAX: float = 5.0
    STEALTH_RANDOMIZE_USER_AGENT: bool = True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # OUTPUT SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    OUTPUT_DIR: str = "recon_results"
    SCREENSHOTS_DIR: str = "screenshots"
    JS_ANALYSIS_DIR: str = "js_analysis"
    DATABASE_PATH: str = "recon_hunter.db"
    HISTORY_DIR: str = "scan_history"
    
    # Export formats
    EXPORT_JSON: bool = True
    EXPORT_CSV: bool = True
    EXPORT_HTML: bool = True
    EXPORT_PDF: bool = False  # Requires additional dependencies
    
    # ═══════════════════════════════════════════════════════════════════════════
    # WATCH TOWER MONITORING SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Enable continuous monitoring
    ENABLE_CONTINUOUS_MONITORING: bool = False
    
    # Monitoring interval in seconds (default: 6 hours)
    MONITORING_INTERVAL: int = 21600
    
    # Alternative interval presets
    MONITORING_INTERVAL_1H: int = 3600
    MONITORING_INTERVAL_6H: int = 21600
    MONITORING_INTERVAL_12H: int = 43200
    MONITORING_INTERVAL_24H: int = 86400
    MONITORING_INTERVAL_WEEKLY: int = 604800
    
    # History retention (days)
    HISTORY_RETENTION_DAYS: int = 30
    MAX_HISTORY_SCANS: int = 100
    
    # Change detection settings
    DETECT_NEW_SUBDOMAINS: bool = True
    DETECT_REMOVED_SUBDOMAINS: bool = True
    DETECT_TAKEOVER_VULNERABILITIES: bool = True
    DETECT_NEW_SECRETS: bool = True
    DETECT_NEW_CLOUD_BUCKETS: bool = True
    DETECT_NEW_OPEN_PORTS: bool = True
    DETECT_STATUS_CHANGES: bool = True
    DETECT_TECHNOLOGY_CHANGES: bool = True
    
    # Alert thresholds
    ALERT_ON_NEW_SUBDOMAINS: bool = True
    ALERT_ON_TAKEOVER: bool = True
    ALERT_ON_SECRETS: bool = True
    ALERT_ON_CRITICAL_FINDINGS: bool = True
    MIN_ALERT_SEVERITY: str = "medium"  # critical, high, medium, low, info
    
    # ═══════════════════════════════════════════════════════════════════════════
    # NOTIFICATION SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Webhook notifications
    SLACK_WEBHOOK_URL: str = ""
    DISCORD_WEBHOOK_URL: str = ""
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_CHAT_ID: str = ""
    CUSTOM_WEBHOOK_URL: str = ""
    
    # Email notifications (using standard SMTP - no external API)
    EMAIL_ENABLED: bool = False
    EMAIL_SMTP_SERVER: str = ""
    EMAIL_SMTP_PORT: int = 587
    EMAIL_USE_TLS: bool = True
    EMAIL_USERNAME: str = ""
    EMAIL_PASSWORD: str = ""
    EMAIL_FROM: str = ""
    EMAIL_RECIPIENTS: List[str] = field(default_factory=list)
    
    # Notification preferences
    NOTIFY_ON_NEW_SUBDOMAINS: bool = True
    NOTIFY_ON_VULNERABILITIES: bool = True
    NOTIFY_ON_SECRETS: bool = True
    NOTIFY_ON_ERRORS: bool = False
    NOTIFY_ON_SCAN_COMPLETE: bool = True
    
    # Rate limit notifications (don't spam)
    NOTIFICATION_COOLDOWN: int = 300  # 5 minutes between similar notifications
    MAX_NOTIFICATIONS_PER_HOUR: int = 20
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DIRECTORY FUZZING SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    DIR_FUZZ_ENABLED: bool = True
    DIR_FUZZ_TIMEOUT: int = 10
    DIR_FUZZ_MAX_CONCURRENT: int = 20
    DIR_FUZZ_SENSITIVE_FILES: bool = True
    DIR_FUZZ_DIRECTORIES: bool = True
    DIR_FUZZ_RECURSIVE: bool = False
    DIR_FUZZ_MAX_DEPTH: int = 2
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SECRET DETECTION SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    SECRET_DETECTION_ENABLED: bool = True
    SECRET_SCAN_JS_FILES: bool = True
    SECRET_SCAN_HTML: bool = True
    SECRET_MAX_JS_FILES: int = 30
    SECRET_MIN_CONFIDENCE: str = "medium"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PASSIVE RECON SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # All sources are FREE - no API keys required
    PASSIVE_SOURCES_ENABLED: List[str] = field(default_factory=lambda: [
        # Certificate sources
        'crt_sh',
        'certspotter',
        # DNS sources
        'dnsdumpster',
        'hackertarget',
        'threatcrowd',
        'alienvault',
        'urlscan',
        'rapiddns',
        # Search engines
        'wayback',
        'commoncrawl',
        'webcache',
        'archive_today',
        # Additional sources
        'bufferover',
        'sonarsearch',
        'jldc',
        'threatminer',
        'anubis',
        'fullhunt',
        'recondev',
        'riddler',
        'crobat',
        'entrope',
        'dnslytics',
        'viewdns',
        'iphistory',
        'subdomainfinderc99',
        'ipvoid',
        'urlvoid',
    ])
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOR/DARK WEB SETTINGS (Optional)
    # ═══════════════════════════════════════════════════════════════════════════
    
    TOR_ENABLED: bool = False
    TOR_PROXY: str = "socks5h://127.0.0.1:9050"
    DARK_WEB_MONITORING: bool = False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PERFORMANCE SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Async settings
    MAX_WORKERS: int = 10
    QUEUE_SIZE: int = 1000
    
    # Caching
    ENABLE_CACHE: bool = True
    CACHE_TTL: int = 3600  # 1 hour
    CACHE_MAX_SIZE: int = 10000
    
    # Memory limits
    MAX_RESULTS_IN_MEMORY: int = 100000
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LOGGING SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "recon_hunter.log"
    LOG_MAX_SIZE: int = 10 * 1024 * 1024  # 10 MB
    LOG_BACKUP_COUNT: int = 5
    LOG_FORMAT: str = "%(asctime)s - %(levelname)s - %(message)s"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # GUI SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    GUI_THEME: str = "dark"
    GUI_WINDOW_WIDTH: int = 1400
    GUI_WINDOW_HEIGHT: int = 900
    GUI_FONT_FAMILY: str = "Consolas"
    GUI_FONT_SIZE: int = 10
    
    # ═══════════════════════════════════════════════════════════════════════════
    # WORDLIST SETTINGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Built-in wordlist (comprehensive)
    USE_BUILTIN_WORDLIST: bool = True
    
    # Custom wordlist file
    CUSTOM_WORDLIST_PATH: str = ""
    
    # SecLists path (optional)
    SECLISTS_PATH: str = ""
    
    def __post_init__(self):
        """Post-initialization validation"""
        # Validate monitoring interval
        if self.MONITORING_INTERVAL < 300:  # Minimum 5 minutes
            self.MONITORING_INTERVAL = 300
        
        # Validate log level
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.LOG_LEVEL.upper() not in valid_levels:
            self.LOG_LEVEL = 'INFO'
        
        # Validate min alert severity
        valid_severities = ['critical', 'high', 'medium', 'low', 'info']
        if self.MIN_ALERT_SEVERITY.lower() not in valid_severities:
            self.MIN_ALERT_SEVERITY = 'medium'
    
    @classmethod
    def from_file(cls, filepath: str) -> 'Config':
        """
        Load configuration from a JSON file
        
        Args:
            filepath: Path to configuration file
        
        Returns:
            Config instance
        """
        import json
        
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        return cls(**data)
    
    def to_file(self, filepath: str):
        """
        Save configuration to a JSON file
        
        Args:
            filepath: Path to save configuration
        """
        import json
        from dataclasses import asdict
        
        with open(filepath, 'w') as f:
            json.dump(asdict(self), f, indent=2)
    
    def get_monitoring_interval_hours(self) -> float:
        """Get monitoring interval in hours"""
        return self.MONITORING_INTERVAL / 3600
    
    def set_monitoring_interval_hours(self, hours: float):
        """Set monitoring interval in hours"""
        self.MONITORING_INTERVAL = int(hours * 3600)
    
    def is_notification_enabled(self) -> bool:
        """Check if any notification method is configured"""
        return bool(
            self.SLACK_WEBHOOK_URL or
            self.DISCORD_WEBHOOK_URL or
            (self.TELEGRAM_BOT_TOKEN and self.TELEGRAM_CHAT_ID) or
            self.CUSTOM_WEBHOOK_URL or
            (self.EMAIL_ENABLED and self.EMAIL_SMTP_SERVER and self.EMAIL_RECIPIENTS)
        )


# Default configuration instance
DEFAULT_CONFIG = Config()


def get_config() -> Config:
    """Get default configuration"""
    return DEFAULT_CONFIG


def create_watchtower_config(
    monitoring_interval_hours: float = 6,
    email_recipients: List[str] = None,
    slack_webhook: str = "",
    discord_webhook: str = "",
    telegram_token: str = "",
    telegram_chat_id: str = ""
) -> Config:
    """
    Create a configuration optimized for Watch Tower monitoring
    
    Args:
        monitoring_interval_hours: Hours between scans
        email_recipients: List of email recipients
        slack_webhook: Slack webhook URL
        discord_webhook: Discord webhook URL
        telegram_token: Telegram bot token
        telegram_chat_id: Telegram chat ID
    
    Returns:
        Configured Config instance
    """
    config = Config(
        ENABLE_CONTINUOUS_MONITORING=True,
        MONITORING_INTERVAL=int(monitoring_interval_hours * 3600),
        DETECT_NEW_SUBDOMAINS=True,
        DETECT_TAKEOVER_VULNERABILITIES=True,
        DETECT_NEW_SECRETS=True,
        NOTIFY_ON_NEW_SUBDOMAINS=True,
        NOTIFY_ON_VULNERABILITIES=True,
        NOTIFY_ON_SECRETS=True,
        NOTIFY_ON_SCAN_COMPLETE=True,
    )
    
    if email_recipients:
        config.EMAIL_ENABLED = True
        config.EMAIL_RECIPIENTS = email_recipients
    
    if slack_webhook:
        config.SLACK_WEBHOOK_URL = slack_webhook
    
    if discord_webhook:
        config.DISCORD_WEBHOOK_URL = discord_webhook
    
    if telegram_token and telegram_chat_id:
        config.TELEGRAM_BOT_TOKEN = telegram_token
        config.TELEGRAM_CHAT_ID = telegram_chat_id
    
    return config