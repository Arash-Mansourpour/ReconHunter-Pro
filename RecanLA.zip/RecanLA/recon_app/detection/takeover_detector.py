#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Subdomain Takeover Detector for Recon Hunter Pro
"""

import asyncio
import aiohttp
import logging
from typing import Dict, List, Optional, Tuple
import re

logger = logging.getLogger(__name__)


class TakeoverDetector:
    """
    Subdomain takeover vulnerability detection
    """
    
    # Signatures for takeover detection
    TAKEOVER_SIGNATURES = {
        'GitHub Pages': {
            'cname': ['github.io', 'githubusercontent.com'],
            'text': ['There isn\'t a GitHub Pages site here', 'For root URLs (like http://example.com/)'],
            'status': [404]
        },
        'Heroku': {
            'cname': ['herokuapp.com'],
            'text': ['herokucdn.com/error-pages/no-such-app.html', 'No such app'],
            'status': [404]
        },
        'Netlify': {
            'cname': ['netlify.com', 'netlify.app'],
            'text': ['Not Found - Request ID:', 'The page you are looking for doesn\'t exist'],
            'status': [404]
        },
        'Vercel': {
            'cname': ['vercel.app', 'now.sh'],
            'text': ['The deployment could not be found', 'VERCEL_NOT_FOUND'],
            'status': [404]
        },
        'AWS S3': {
            'cname': ['s3.amazonaws.com', 's3-website', 's3-website-us', 's3-website-eu'],
            'text': ['NoSuchBucket', 'The specified bucket does not exist'],
            'status': [404]
        },
        'AWS CloudFront': {
            'cname': ['cloudfront.net'],
            'text': ['ERROR: The request could not be satisfied', 'Bad Request'],
            'status': [400, 403, 404]
        },
        'Shopify': {
            'cname': ['myshopify.com'],
            'text': ['Sorry, this shop is currently unavailable', 'Only one step left!'],
            'status': [404]
        },
        'Tumblr': {
            'cname': ['tumblr.com'],
            'text': ['Whatever you were looking for doesn\'t currently exist at this address'],
            'status': [404]
        },
        'WordPress.com': {
            'cname': ['wordpress.com', 'wp.com'],
            'text': ['Do you want to register', 'wordpress.com is no longer available'],
            'status': [200, 404]
        },
        'Ghost': {
            'cname': ['ghost.io'],
            'text': ['The thing you were looking for is no longer here'],
            'status': [404]
        },
        'Bitbucket': {
            'cname': ['bitbucket.io'],
            'text': ['Repository not found', 'This site is not currently available'],
            'status': [404]
        },
        'GitLab': {
            'cname': ['gitlab.io'],
            'text': ['The page you\'re looking for could not be found'],
            'status': [404]
        },
        'Surge': {
            'cname': ['surge.sh'],
            'text': ['project not found'],
            'status': [404]
        },
        'Render': {
            'cname': ['render.com', 'onrender.com'],
            'text': ['Not Found', 'render.com'],
            'status': [404]
        },
        'Fly.io': {
            'cname': ['fly.dev', 'fly.io'],
            'text': ['Not Found'],
            'status': [404]
        },
        'Firebase': {
            'cname': ['firebaseapp.com', 'web.app'],
            'text': ['Hosting Site Not Found', 'The site you requested could not be found'],
            'status': [404]
        },
        'Fastly': {
            'cname': ['fastly.net', 'fastly.com'],
            'text': ['Fastly error: unknown domain'],
            'status': [500, 503]
        },
        'Pantheon': {
            'cname': ['pantheonsite.io', 'pantheon.io'],
            'text': ['The pantheon.io site is no longer here'],
            'status': [404]
        },
        'Wix': {
            'cname': ['wix.com', 'wixsite.com', 'wixstatic.com'],
            'text': ['Error ConnectYourDomain', 'This page is not yet ready'],
            'status': [404]
        },
        'Weebly': {
            'cname': ['weebly.com'],
            'text': ['The site you were looking for couldn\'t be found'],
            'status': [404]
        },
        'Squarespace': {
            'cname': ['squarespace.com'],
            'text': ['This domain is already connected to a Squarespace website'],
            'status': [404]
        },
        'Tilda': {
            'cname': ['tilda.ws', 'tilda.cc'],
            'text': ['Domain is not linked to a project', 'This page doesn\'t exist'],
            'status': [404]
        },
        'Readme.io': {
            'cname': ['readme.io'],
            'text': ['Project doesnt exist... yet'],
            'status': [404]
        },
        'Strikingly': {
            'cname': ['strikingly.com', 'strikinglydns.com'],
            'text': ['The page you visited doesn\'t exist'],
            'status': [404]
        },
        'Uptime Robot': {
            'cname': ['uptimerobot.com'],
            'text': ['The page you are looking for doesn\'t exist'],
            'status': [404]
        },
        'Statuspage': {
            'cname': ['statuspage.io'],
            'text': ['The page you are looking for doesn\'t exist'],
            'status': [404]
        },
        'Help Scout': {
            'cname': ['helpscoutdocs.com'],
            'text': ['No settings were found for this company'],
            'status': [404]
        },
        'Freshdesk': {
            'cname': ['freshdesk.com'],
            'text': ['This portal does not exist'],
            'status': [404]
        },
        'Zendesk': {
            'cname': ['zendesk.com'],
            'text': ['Help Center Closed', 'This Help Center no longer exists'],
            'status': [404]
        },
        'Intercom': {
            'cname': ['intercom.help'],
            'text': ['This page doesn\'t exist'],
            'status': [404]
        },
        'Cargo': {
            'cname': ['cargo.site', 'cargocollective.com'],
            'text': ['This site is no longer active'],
            'status': [404]
        },
        'Smugmug': {
            'cname': ['smugmug.com'],
            'text': ['The site you were looking for couldn\'t be found'],
            'status': [404]
        },
        'Aerobatic': {
            'cname': ['aerobatic.com'],
            'text': ['The requested URL was not found on this server'],
            'status': [404]
        },
        'HatenaBlog': {
            'cname': ['hatenablog.com', 'hatenablog.jp'],
            'text': ['404 Not Found', 'hatena'],
            'status': [404]
        },
        'Kinsta': {
            'cname': ['kinsta.com', 'kinsta.cloud'],
            'text': ['No site found at this address'],
            'status': [404]
        },
        'LaunchRock': {
            'cname': ['launchrock.com'],
            'text': ['It looks like you may have taken a wrong turn somewhere'],
            'status': [404]
        },
        'Mashery': {
            'cname': ['mashery.com'],
            'text': ['Unrecognized domain'],
            'status': [404]
        },
        'Pagewiz': {
            'cname': ['pagewiz.com'],
            'text': ['Page Not Found'],
            'status': [404]
        },
        'Pingdom': {
            'cname': ['pingdom.net', 'stats.pingdom.com'],
            'text': ['This page is not available'],
            'status': [404]
        },
        'Quip': {
            'cname': ['quip.com'],
            'text': ['Sorry, we couldn\'t find that page'],
            'status': [404]
        },
        'SmartJobBoard': {
            'cname': ['smartjobboard.com'],
            'text': ['This job board website is either expired or its domain name is invalid'],
            'status': [404]
        },
        'TeamWork': {
            'cname': ['teamwork.com'],
            'text': ['Oops - We didn\'t find your site'],
            'status': [404]
        },
        'Tilda': {
            'cname': ['tilda.ws'],
            'text': ['Domain is not linked to a project'],
            'status': [404]
        },
        'Tumblr': {
            'cname': ['tumblr.com'],
            'text': ['Whatever you were looking for doesn\'t currently exist at this address'],
            'status': [404]
        },
        'Unbounce': {
            'cname': ['unbounce.com', 'ubpages.com'],
            'text': ['The requested URL was not found on this server'],
            'status': [404]
        },
        'UserVoice': {
            'cname': ['uservoice.com'],
            'text': ['This UserVoice subdomain is currently unavailable'],
            'status': [404]
        },
        'Webflow': {
            'cname': ['webflow.io', 'webflow.com'],
            'text': ['The page you are looking for doesn\'t exist'],
            'status': [404]
        },
        'Worksites': {
            'cname': ['worksites.net'],
            'text': ['This website is no longer in service'],
            'status': [404]
        },
        'Zenfolio': {
            'cname': ['zenfolio.com'],
            'text': ['The page you\'re looking for can\'t be found'],
            'status': [404]
        },
    }
    
    @classmethod
    async def check_takeover(
        cls,
        subdomain: str,
        cname: str = None,
        timeout: int = 10
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Check if subdomain is vulnerable to takeover
        
        Args:
            subdomain: Subdomain to check
            cname: CNAME record if known
            timeout: Request timeout
        
        Returns:
            Tuple of (is_vulnerable, takeover_type, evidence)
        """
        try:
            async with aiohttp.ClientSession() as session:
                for protocol in ['https', 'http']:
                    try:
                        url = f"{protocol}://{subdomain}"
                        async with session.get(url, timeout=timeout, ssl=False, allow_redirects=True) as response:
                            text = await response.text()
                            status = response.status
                            
                            for service, signatures in cls.TAKEOVER_SIGNATURES.items():
                                # Check CNAME match
                                if cname:
                                    for cname_pattern in signatures.get('cname', []):
                                        if cname_pattern in cname:
                                            # Check text patterns
                                            for text_pattern in signatures.get('text', []):
                                                if text_pattern.lower() in text.lower():
                                                    return True, service, f"CNAME: {cname}, Text: {text_pattern}"
                                            
                                            # Check status codes
                                            if status in signatures.get('status', []):
                                                return True, service, f"CNAME: {cname}, Status: {status}"
                                
                                # Check text patterns even without CNAME
                                for text_pattern in signatures.get('text', []):
                                    if text_pattern.lower() in text.lower():
                                        # Verify with status code
                                        if status in signatures.get('status', []):
                                            return True, service, f"Text: {text_pattern}, Status: {status}"
                    
                    except Exception:
                        continue
        
        except Exception as e:
            logger.debug(f"Takeover check error for {subdomain}: {e}")
        
        return False, None, None
    
    @classmethod
    async def check_cname_takeover(cls, cname: str) -> Tuple[bool, Optional[str]]:
        """
        Check if CNAME is potentially vulnerable to takeover
        
        Args:
            cname: CNAME record value
        
        Returns:
            Tuple of (is_potentially_vulnerable, service)
        """
        if not cname:
            return False, None
        
        cname_lower = cname.lower()
        
        for service, signatures in cls.TAKEOVER_SIGNATURES.items():
            for cname_pattern in signatures.get('cname', []):
                if cname_pattern.lower() in cname_lower:
                    return True, service
        
        return False, None
    
    @classmethod
    async def batch_check(cls, subdomains: List[Dict], timeout: int = 10) -> List[Dict]:
        """
        Batch check multiple subdomains for takeover
        
        Args:
            subdomains: List of subdomain dictionaries with 'domain' and 'cnames' keys
            timeout: Request timeout
        
        Returns:
            List of vulnerable subdomains
        """
        vulnerable = []
        
        for subdomain_info in subdomains:
            subdomain = subdomain_info.get('domain', '')
            cnames = subdomain_info.get('cnames', [])
            cname = cnames[0] if cnames else None
            
            is_vulnerable, takeover_type, evidence = await cls.check_takeover(
                subdomain, cname, timeout
            )
            
            if is_vulnerable:
                vulnerable.append({
                    'subdomain': subdomain,
                    'cname': cname,
                    'takeover_type': takeover_type,
                    'evidence': evidence
                })
        
        return vulnerable
    
    @classmethod
    def get_vulnerable_services(cls) -> List[str]:
        """
        Get list of services vulnerable to subdomain takeover
        
        Returns:
            List of service names
        """
        return list(cls.TAKEOVER_SIGNATURES.keys())
    
    @classmethod
    def get_service_info(cls, service: str) -> Dict:
        """
        Get information about a takeover service
        
        Args:
            service: Service name
        
        Returns:
            Dictionary with service information
        """
        if service in cls.TAKEOVER_SIGNATURES:
            return {
                'service': service,
                'cname_patterns': cls.TAKEOVER_SIGNATURES[service].get('cname', []),
                'text_patterns': cls.TAKEOVER_SIGNATURES[service].get('text', []),
                'status_codes': cls.TAKEOVER_SIGNATURES[service].get('status', [])
            }
        return {}