#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CDN Detector for Recon Hunter Pro
"""

import ipaddress
import subprocess
import logging
from typing import Tuple, Optional, Dict, List

logger = logging.getLogger(__name__)


class CDNDetector:
    """
    Advanced CDN detection with IP range matching
    """
    
    CDN_RANGES = {
        'Cloudflare': [
            '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
            '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
            '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
            '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22'
        ],
        'Akamai': [
            '23.0.0.0/8', '95.100.0.0/16', '96.6.0.0/15', '104.64.0.0/10',
            '184.24.0.0/13', '2.16.0.0/13'
        ],
        'CloudFront': [
            '13.32.0.0/15', '13.35.0.0/16', '13.224.0.0/14', '13.249.0.0/16',
            '18.64.0.0/14', '52.84.0.0/15', '52.222.128.0/17', '54.182.0.0/16',
            '54.192.0.0/16', '54.230.0.0/16', '54.239.128.0/18', '54.239.192.0/19',
            '99.84.0.0/16', '204.246.164.0/22', '204.246.168.0/22', '204.246.174.0/23',
            '204.246.176.0/20', '205.251.192.0/19', '205.251.249.0/24', '205.251.250.0/23',
            '205.251.252.0/23', '205.251.254.0/24'
        ],
        'Fastly': [
            '23.235.32.0/20', '43.249.72.0/22', '103.244.50.0/24', '103.245.222.0/23',
            '103.245.224.0/24', '104.156.80.0/20', '140.248.64.0/18', '140.248.128.0/17',
            '146.75.0.0/17', '151.101.0.0/16', '157.52.64.0/18', '167.82.0.0/17',
            '167.82.128.0/20', '167.82.160.0/20', '167.82.224.0/20', '172.111.64.0/18',
            '185.31.16.0/22', '199.27.72.0/21', '199.232.0.0/16'
        ],
        'AWS': [
            '3.0.0.0/8', '13.0.0.0/8', '18.0.0.0/8', '34.192.0.0/10',
            '35.0.0.0/8', '52.0.0.0/8', '54.0.0.0/8'
        ],
        'Incapsula': [
            '45.60.0.0/16', '45.64.64.0/18', '103.28.248.0/22', '185.11.124.0/22',
            '192.230.64.0/18', '198.143.32.0/19', '199.83.128.0/21'
        ],
        'Azure CDN': [
            '13.107.4.0/22', '13.107.8.0/22', '13.107.12.0/22', '13.107.16.0/22',
            '13.107.20.0/22', '13.107.24.0/22', '13.107.28.0/22', '13.107.32.0/22'
        ],
        'Google Cloud CDN': [
            '34.0.0.0/9', '35.184.0.0/13', '35.192.0.0/14', '35.196.0.0/15',
            '35.198.0.0/16', '35.199.0.0/17', '35.199.128.0/18', '35.200.0.0/13'
        ],
        'StackPath': [
            '151.139.0.0/16', '209.107.128.0/17', '64.125.0.0/16', '198.41.128.0/17'
        ],
        'CDN77': [
            '37.77.128.0/17', '89.187.128.0/17', '195.47.128.0/17'
        ],
        'KeyCDN': [
            '79.127.216.0/21', '178.255.152.0/21'
        ],
        'CacheFly': [
            '205.234.128.0/19'
        ],
        'Sucuri': [
            '192.88.134.0/23', '192.124.249.0/24', '185.93.228.0/22'
        ],
        'Limelight': [
            '208.111.128.0/17', '199.10.28.0/22', '199.10.32.0/20'
        ],
        'EdgeCast': [
            '68.232.32.0/19', '68.232.64.0/19', '68.232.96.0/19'
        ],
        'Highwinds': [
            '162.246.144.0/22', '162.246.148.0/22', '162.246.152.0/22'
        ],
        'Cotendo': [
            '216.137.32.0/19'
        ],
        'NetDNA': [
            '64.70.128.0/17', '72.46.128.0/17', '94.31.0.0/16'
        ],
        'MaxCDN': [
            '167.114.0.0/16', '198.27.64.0/18'
        ],
        'QUIC': [
            '162.159.0.0/16', '172.64.0.0/13'
        ],
        'OVH CDN': [
            '51.68.0.0/14', '51.72.0.0/14', '51.76.0.0/15', '51.78.0.0/16'
        ],
        'Leaseweb': [
            '37.48.64.0/18', '46.165.192.0/18', '62.212.64.0/19'
        ],
        'CDNetworks': [
            '202.6.244.0/22', '202.6.248.0/22', '210.105.192.0/19'
        ],
        'Imperva': [
            '45.60.32.0/18', '45.223.0.0/16'
        ]
    }
    
    ASN_CDNS = {
        'AS13335': 'Cloudflare',
        'AS16625': 'Akamai',
        'AS16509': 'Amazon/CloudFront',
        'AS54113': 'Fastly',
        'AS19551': 'Incapsula',
        'AS8075': 'Microsoft/Azure',
        'AS15169': 'Google',
        'AS20446': 'StackPath',
        'AS60068': 'CDN77',
        'AS32934': 'Facebook',
        'AS54113': 'Fastly',
        'AS14618': 'AWS',
        'AS395747': 'Facebook',
        'AS8068': 'Microsoft',
        'AS14061': 'DigitalOcean',
        'AS20473': 'Vultr',
        'AS63949': 'Linode',
        'AS24940': 'Hetzner',
        'AS60781': 'Leaseweb',
        'AS16265': 'Leaseweb',
    }
    
    CDN_HEADERS = {
        'Cloudflare': ['cf-ray', 'cf-cache-status', 'server: cloudflare'],
        'Akamai': ['akamai-origin-hop', 'akamai-x-cache', 'x-akamai-transformed'],
        'CloudFront': ['x-amz-cf-id', 'x-amz-cf-pop', 'via: CloudFront'],
        'Fastly': ['x-served-by', 'x-cache', 'x-fastly-request-id'],
        'AWS': ['x-amzn-requestid', 'x-amz-cf-id'],
        'Incapsula': ['x-iinfo', 'x-cdn: Incapsula'],
        'Azure': ['x-azure-ref', 'x-cache'],
        'Google': ['x-goog-', 'server: sffe', 'server: gse'],
        'StackPath': ['x-stackpath', 'x-sp'],
        'CDN77': ['x-77', 'server: CDN77'],
        'Sucuri': ['x-sucuri-id', 'x-sucuri-cache'],
        'CacheFly': ['server: CacheFly'],
        'KeyCDN': ['x-keycdn', 'server: KeyCDN'],
        'Limelight': ['x-llnw', 'server: llnw'],
        'EdgeCast': ['x-ec-custom-error', 'server: ECAcc'],
        'NetDNA': ['x-netdna', 'server: NetDNA'],
        'MaxCDN': ['x-maxcdn', 'server: MaxCDN'],
        'OVH': ['x-ovh', 'server: nginx'],
        'Imperva': ['x-iinfo', 'x-cdn'],
    }
    
    @classmethod
    def detect_cdn(cls, ip: str) -> Tuple[bool, Optional[str]]:
        """
        Detect if IP belongs to a CDN
        
        Args:
            ip: IP address to check
        
        Returns:
            Tuple of (is_cdn, provider_name)
        """
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            for provider, ranges in cls.CDN_RANGES.items():
                for cidr in ranges:
                    try:
                        if ip_obj in ipaddress.ip_network(cidr):
                            return True, provider
                    except:
                        continue
        except ValueError:
            pass
        
        return False, None
    
    @classmethod
    def detect_cdn_from_headers(cls, headers: Dict) -> Optional[str]:
        """
        Detect CDN from HTTP headers
        
        Args:
            headers: Dictionary of HTTP response headers
        
        Returns:
            CDN provider name or None
        """
        headers_lower = {k.lower(): v.lower() for k, v in headers.items()}
        
        for provider, patterns in cls.CDN_HEADERS.items():
            for pattern in patterns:
                pattern_lower = pattern.lower()
                if ':' in pattern_lower:
                    # Header with value check
                    header_name, header_value = pattern_lower.split(':', 1)
                    header_name = header_name.strip()
                    header_value = header_value.strip()
                    if header_name in headers_lower and header_value in headers_lower[header_name]:
                        return provider
                else:
                    # Just header name check
                    if pattern_lower in headers_lower:
                        return provider
        
        return None
    
    @classmethod
    def get_asn(cls, ip: str) -> Optional[str]:
        """
        Get ASN information for an IP
        
        Args:
            ip: IP address
        
        Returns:
            ASN information string or None
        """
        try:
            result = subprocess.run(
                ['whois', '-h', 'whois.cymru.com', f' -v {ip}'],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            lines = result.stdout.split('\n')
            for line in lines:
                if 'AS' in line:
                    return line.strip()
        except:
            pass
        return None
    
    @classmethod
    def get_cdn_from_asn(cls, asn: str) -> Optional[str]:
        """
        Get CDN provider from ASN
        
        Args:
            asn: ASN number (e.g., 'AS13335')
        
        Returns:
            CDN provider name or None
        """
        return cls.ASN_CDNS.get(asn)
    
    @classmethod
    def detect(cls, ip: str = None, headers: Dict = None) -> Dict:
        """
        Comprehensive CDN detection
        
        Args:
            ip: IP address to check
            headers: HTTP response headers
        
        Returns:
            Dictionary with detection results
        """
        result = {
            'is_cdn': False,
            'provider': None,
            'detection_method': None,
            'asn': None
        }
        
        # Check headers first
        if headers:
            provider = cls.detect_cdn_from_headers(headers)
            if provider:
                result['is_cdn'] = True
                result['provider'] = provider
                result['detection_method'] = 'header'
                return result
        
        # Check IP ranges
        if ip:
            is_cdn, provider = cls.detect_cdn(ip)
            if is_cdn:
                result['is_cdn'] = True
                result['provider'] = provider
                result['detection_method'] = 'ip_range'
                
                # Try to get ASN
                asn = cls.get_asn(ip)
                if asn:
                    result['asn'] = asn
                    asn_provider = cls.get_cdn_from_asn(asn)
                    if asn_provider and not provider:
                        result['provider'] = asn_provider
                        result['detection_method'] = 'asn'
        
        return result
    
    @classmethod
    def get_all_cdn_ips(cls, provider: str) -> List[str]:
        """
        Get all IP addresses for a CDN provider
        
        Args:
            provider: CDN provider name
        
        Returns:
            List of IP addresses
        """
        ips = []
        if provider in cls.CDN_RANGES:
            for cidr in cls.CDN_RANGES[provider]:
                try:
                    network = ipaddress.ip_network(cidr)
                    for ip in network.hosts():
                        ips.append(str(ip))
                except:
                    pass
        return ips