#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Technology Detector for Recon Hunter Pro
"""

import re
import logging
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class TechnologyDetector:
    """
    Advanced technology stack detection
    Based on Wappalyzer signatures
    """
    
    SIGNATURES = {
        # CMS
        'WordPress': {
            'html': ['wp-content', 'wp-includes', '/wp-json/', 'wp-emoji', 'wp-block'],
            'headers': {'x-powered-by': 'wordpress', 'x-pingback': 'xmlrpc.php'},
            'meta': {'generator': 'wordpress'},
            'cookies': ['wordpress_', 'wp-settings-']
        },
        'Joomla': {
            'html': ['/media/jui/', 'joomla', 'option=com_', '/administrator/'],
            'headers': {'x-content-encoded-by': 'joomla'},
            'meta': {'generator': 'joomla'}
        },
        'Drupal': {
            'html': ['drupal', '/sites/default/', 'drupal.settings', '/misc/drupal.js'],
            'headers': {'x-drupal-cache': '', 'x-generator': 'drupal'},
            'meta': {'generator': 'drupal'},
            'cookies': ['sess', 'drupal']
        },
        'Magento': {
            'html': ['magento', '/skin/frontend/', '/js/mage/', 'mage/cookies.js'],
            'meta': {'generator': 'magento'},
            'cookies': ['frontend', 'mage-']
        },
        'Shopify': {
            'html': ['shopify', 'cdn.shopify.com', 'myshopify.com'],
            'cookies': ['_shopify']
        },
        'Wix': {
            'html': ['wix.com', 'wixstatic.com', 'wix-code'],
            'meta': {'generator': 'wix'}
        },
        'Squarespace': {
            'html': ['squarespace', 'static.squarespace.com'],
            'cookies': ['squarespace']
        },
        'Webflow': {
            'html': ['webflow', 'assets.website-files.com'],
            'meta': {'generator': 'webflow'}
        },
        
        # Frameworks
        'Laravel': {
            'html': ['laravel', 'laravel_session'],
            'cookies': ['laravel_session', 'XSRF-TOKEN']
        },
        'Django': {
            'html': ['csrfmiddlewaretoken', '__admin/', 'django'],
            'cookies': ['csrftoken', 'sessionid'],
            'headers': {'x-frame-options': 'deny'}
        },
        'Flask': {
            'cookies': ['session'],
            'headers': {'server': 'werkzeug'}
        },
        'Ruby on Rails': {
            'html': ['rails', 'csrf-token', 'authenticity_token'],
            'cookies': ['_session', 'rails'],
            'headers': {'x-runtime': ''}
        },
        'Express.js': {
            'headers': {'x-powered-by': 'express'}
        },
        'Next.js': {
            'html': ['__next', '/_next/', 'next/dist'],
            'headers': {'x-powered-by': 'next.js'}
        },
        'Nuxt.js': {
            'html': ['__nuxt', '/_nuxt/', 'nuxt'],
            'headers': {'x-powered-by': 'nuxt'}
        },
        'Spring': {
            'html': ['spring', 'springframework'],
            'headers': {'x-powered-by': 'spring'}
        },
        'ASP.NET': {
            'html': ['__viewstate', '__eventvalidation', '__doPostBack'],
            'headers': {'x-aspnet-version': '', 'x-powered-by': 'asp.net'},
            'cookies': ['asp.net_sessionid', 'aspnetsessionid']
        },
        'CodeIgniter': {
            'cookies': ['ci_session', 'csrf_token']
        },
        'Symfony': {
            'html': ['symfony', 'sf-toolbar'],
            'cookies': ['symfony', 'sf2']
        },
        'Yii': {
            'html': ['yii', 'yii2'],
            'cookies': ['_csrf', 'yii']
        },
        'CakePHP': {
            'cookies': ['cakephp', 'cake']
        },
        
        # Frontend Frameworks
        'React': {
            'html': ['react', 'react-dom', 'data-reactroot', 'data-reactid', '_reactRootContainer']
        },
        'Vue.js': {
            'html': ['vue', 'vue.js', 'data-v-', '__vue__', 'v-cloak']
        },
        'Angular': {
            'html': ['ng-app', 'ng-controller', 'angular', 'ng-version', 'ng-binding']
        },
        'AngularJS': {
            'html': ['ng-app', 'ng-controller', 'angularjs', 'ng-bind']
        },
        'Svelte': {
            'html': ['svelte', 'svelte-component']
        },
        'Ember.js': {
            'html': ['ember', 'ember.js'],
            'cookies': ['ember']
        },
        'Backbone.js': {
            'html': ['backbone', 'backbone.js']
        },
        'jQuery': {
            'html': ['jquery', 'jquery.min.js', 'jquery.js', 'jquery-']
        },
        'Bootstrap': {
            'html': ['bootstrap', 'bootstrap.min.css', 'bootstrap.js', 'btn-primary']
        },
        'Tailwind CSS': {
            'html': ['tailwind', 'tw-', 'bg-', 'text-', 'flex-']
        },
        'Material UI': {
            'html': ['mui', 'material-ui', 'jss']
        },
        
        # Server Technologies
        'Nginx': {
            'headers': {'server': 'nginx'}
        },
        'Apache': {
            'headers': {'server': 'apache'}
        },
        'IIS': {
            'headers': {'server': 'microsoft-iis', 'server': 'iis'}
        },
        'LiteSpeed': {
            'headers': {'server': 'litespeed'}
        },
        'OpenResty': {
            'headers': {'server': 'openresty'}
        },
        'Caddy': {
            'headers': {'server': 'caddy'}
        },
        'Node.js': {
            'headers': {'x-powered-by': 'express', 'x-powered-by': 'node'}
        },
        'PHP': {
            'headers': {'x-powered-by': 'php', 'set-cookie': 'phpsessid'},
            'cookies': ['phpsessid', 'phpsessid']
        },
        'Java': {
            'headers': {'x-powered-by': 'jsp', 'server': 'tomcat'}
        },
        'Python': {
            'headers': {'server': 'gunicorn', 'server': 'uwsgi'}
        },
        
        # Cloud & CDN
        'Cloudflare': {
            'headers': {'cf-ray': '', 'server': 'cloudflare', 'cf-cache-status': ''},
            'cookies': ['__cfduid', '__cflb']
        },
        'AWS': {
            'headers': {'x-amzn-requestid': '', 'x-amz-cf-id': ''},
            'html': ['amazonaws.com', 's3.amazonaws.com']
        },
        'Google Cloud': {
            'html': ['storage.googleapis.com', 'cloud.google.com']
        },
        'Azure': {
            'headers': {'x-azure-ref': ''},
            'html': ['azurewebsites.net', 'blob.core.windows.net']
        },
        'Vercel': {
            'headers': {'x-vercel-id': '', 'x-vercel-cache': ''},
            'html': ['vercel.app']
        },
        'Netlify': {
            'headers': {'x-nf-request-id': ''},
            'html': ['netlify.app', 'netlify.com']
        },
        'Heroku': {
            'html': ['herokuapp.com'],
            'headers': {'server': 'heroku'}
        },
        
        # Analytics & Tracking
        'Google Analytics': {
            'html': ['google-analytics.com/analytics.js', 'ga.js', 'gtag.js', 'googletagmanager.com', 'UA-']
        },
        'Google Tag Manager': {
            'html': ['googletagmanager.com', 'gtm.js', 'GTM-']
        },
        'Facebook Pixel': {
            'html': ['connect.facebook.net', 'fbq(', 'facebook.com/tr']
        },
        'Hotjar': {
            'html': ['hotjar.com', 'hj.js']
        },
        'Mixpanel': {
            'html': ['mixpanel.com', 'mixpanel']
        },
        'Segment': {
            'html': ['segment.com', 'analytics.js']
        },
        
        # Databases (detected via error messages or headers)
        'MySQL': {
            'html': ['mysql', 'mysqli', 'mysql_connect']
        },
        'PostgreSQL': {
            'html': ['postgresql', 'pgsql', 'pg_connect']
        },
        'MongoDB': {
            'html': ['mongodb', 'mongo.connect', 'mongoose']
        },
        'Redis': {
            'html': ['redis', 'redis-cli']
        },
        'Elasticsearch': {
            'html': ['elasticsearch', 'elastic.co']
        },
        
        # Other Technologies
        'GraphQL': {
            'html': ['graphql', '/graphql'],
            'headers': {'content-type': 'application/graphql'}
        },
        'REST API': {
            'html': ['/api/', '/api/v1', '/api/v2']
        },
        'Swagger': {
            'html': ['swagger', 'swagger-ui', 'openapi']
        },
        'WebSocket': {
            'html': ['websocket', 'ws://', 'wss://']
        },
        'Service Worker': {
            'html': ['service-worker', 'serviceworker']
        },
        'PWA': {
            'html': ['manifest.json', 'service-worker', 'apple-mobile-web-app']
        },
        'AMP': {
            'html': ['amp-', 'amphtml', 'ampproject.org']
        },
        'Webpack': {
            'html': ['webpack', 'webpackChunk', '__webpack']
        },
        'TypeScript': {
            'html': ['.ts"', '.tsx"']
        },
        'Sass': {
            'html': ['.scss', '.sass']
        },
        'Less': {
            'html': ['.less']
        },
    }
    
    @classmethod
    def detect(cls, html: str, headers: Dict, cookies: Dict) -> List[str]:
        """
        Detect technologies from response
        
        Args:
            html: HTML content
            headers: Response headers
            cookies: Response cookies
        
        Returns:
            List of detected technologies
        """
        detected = set()
        html_lower = html.lower() if html else ''
        headers_lower = {k.lower(): v.lower() for k, v in headers.items()} if headers else {}
        cookies_lower = {k.lower(): v for k, v in cookies.items()} if cookies else {}
        
        for tech, signatures in cls.SIGNATURES.items():
            # Check HTML content
            for pattern in signatures.get('html', []):
                if pattern.lower() in html_lower:
                    detected.add(tech)
                    break
            
            if tech in detected:
                continue
            
            # Check headers
            for header, value in signatures.get('headers', {}).items():
                header_lower = header.lower()
                if header_lower in headers_lower:
                    if value:
                        if value.lower() in headers_lower[header_lower]:
                            detected.add(tech)
                            break
                    else:
                        detected.add(tech)
                        break
            
            if tech in detected:
                continue
            
            # Check cookies
            for cookie in signatures.get('cookies', []):
                cookie_lower = cookie.lower()
                for cookie_name in cookies_lower.keys():
                    if cookie_lower in cookie_name:
                        detected.add(tech)
                        break
                if tech in detected:
                    break
            
            if tech in detected:
                continue
            
            # Check meta tags
            for meta_name, meta_value in signatures.get('meta', {}).items():
                # Look for meta tags in HTML
                meta_pattern = f'<meta[^>]+name=["\']?{meta_name}["\']?[^>]+content=["\']?([^"\'>]+)'
                matches = re.findall(meta_pattern, html_lower, re.IGNORECASE)
                for match in matches:
                    if meta_value.lower() in match.lower():
                        detected.add(tech)
                        break
        
        return sorted(list(detected))
    
    @classmethod
    def detect_with_versions(cls, html: str, headers: Dict, cookies: Dict) -> Dict[str, Optional[str]]:
        """
        Detect technologies with version information
        
        Args:
            html: HTML content
            headers: Response headers
            cookies: Response cookies
        
        Returns:
            Dictionary of detected technologies with versions
        """
        detected = {}
        html_lower = html.lower() if html else ''
        headers_lower = {k.lower(): v.lower() for k, v in headers.items()} if headers else {}
        
        # Check for version in x-powered-by header
        powered_by = headers_lower.get('x-powered-by', '')
        if powered_by:
            version_match = re.search(r'(\d+\.[\d.]+)', powered_by)
            if 'php' in powered_by:
                detected['PHP'] = version_match.group(1) if version_match else None
            elif 'express' in powered_by:
                detected['Express.js'] = version_match.group(1) if version_match else None
            elif 'asp' in powered_by:
                detected['ASP.NET'] = version_match.group(1) if version_match else None
        
        # Check for version in server header
        server = headers_lower.get('server', '')
        if server:
            version_match = re.search(r'(\d+\.[\d.]+)', server)
            if 'nginx' in server:
                detected['Nginx'] = version_match.group(1) if version_match else None
            elif 'apache' in server:
                detected['Apache'] = version_match.group(1) if version_match else None
        
        # Check for WordPress version
        wp_version = re.search(r'wordpress\s*(\d+\.[\d.]+)', html_lower)
        if wp_version:
            detected['WordPress'] = wp_version.group(1)
        
        # Check for jQuery version
        jquery_version = re.search(r'jquery[/-](\d+\.[\d.]+)', html_lower)
        if jquery_version:
            detected['jQuery'] = jquery_version.group(1)
        
        # Check for Bootstrap version
        bootstrap_version = re.search(r'bootstrap[/-](\d+\.[\d.]+)', html_lower)
        if bootstrap_version:
            detected['Bootstrap'] = bootstrap_version.group(1)
        
        # Get other technologies without versions
        all_detected = cls.detect(html, headers, cookies)
        for tech in all_detected:
            if tech not in detected:
                detected[tech] = None
        
        return detected
    
    @classmethod
    def get_categories(cls) -> Dict[str, List[str]]:
        """
        Get technology categories
        
        Returns:
            Dictionary of categories and their technologies
        """
        return {
            'CMS': ['WordPress', 'Joomla', 'Drupal', 'Magento', 'Shopify', 'Wix', 'Squarespace', 'Webflow'],
            'Frameworks': ['Laravel', 'Django', 'Flask', 'Ruby on Rails', 'Express.js', 'Next.js', 'Nuxt.js', 'Spring', 'ASP.NET', 'CodeIgniter', 'Symfony', 'Yii', 'CakePHP'],
            'Frontend': ['React', 'Vue.js', 'Angular', 'AngularJS', 'Svelte', 'Ember.js', 'Backbone.js', 'jQuery', 'Bootstrap', 'Tailwind CSS', 'Material UI'],
            'Server': ['Nginx', 'Apache', 'IIS', 'LiteSpeed', 'OpenResty', 'Caddy', 'Node.js', 'PHP', 'Java', 'Python'],
            'Cloud': ['Cloudflare', 'AWS', 'Google Cloud', 'Azure', 'Vercel', 'Netlify', 'Heroku'],
            'Analytics': ['Google Analytics', 'Google Tag Manager', 'Facebook Pixel', 'Hotjar', 'Mixpanel', 'Segment'],
            'Database': ['MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch'],
            'API': ['GraphQL', 'REST API', 'Swagger', 'WebSocket'],
            'Other': ['Service Worker', 'PWA', 'AMP', 'Webpack', 'TypeScript', 'Sass', 'Less']
        }