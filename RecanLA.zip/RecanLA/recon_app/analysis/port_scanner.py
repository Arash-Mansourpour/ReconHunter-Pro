#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Port Scanner for Recon Hunter Pro
"""

import asyncio
import socket
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class PortResult:
    """Port scan result"""
    port: int
    is_open: bool
    service: str
    banner: Optional[str] = None
    version: Optional[str] = None


class PortScanner:
    """
    Fast port scanner with service detection
    """
    
    COMMON_PORTS = {
        21: 'FTP',
        22: 'SSH',
        23: 'Telnet',
        25: 'SMTP',
        53: 'DNS',
        80: 'HTTP',
        110: 'POP3',
        143: 'IMAP',
        443: 'HTTPS',
        445: 'SMB',
        993: 'IMAPS',
        995: 'POP3S',
        1433: 'MSSQL',
        1521: 'Oracle',
        3306: 'MySQL',
        3389: 'RDP',
        5432: 'PostgreSQL',
        5900: 'VNC',
        6379: 'Redis',
        8080: 'HTTP-Proxy',
        8443: 'HTTPS-Alt',
        9000: 'PHP-FPM',
        9200: 'Elasticsearch',
        11211: 'Memcached',
        27017: 'MongoDB',
    }
    
    TOP_PORTS = [
        21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995,
        1433, 1521, 1723, 3306, 3389, 5432, 5900, 6379, 8000, 8080, 8443,
        8888, 9000, 9200, 11211, 27017
    ]
    
    @staticmethod
    async def scan_port(ip: str, port: int, timeout: float = 2.0) -> bool:
        """
        Scan a single port
        
        Args:
            ip: Target IP address
            port: Port number to scan
            timeout: Connection timeout
        
        Returns:
            True if port is open, False otherwise
        """
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port),
                timeout=timeout
            )
            writer.close()
            await writer.wait_closed()
            return True
        except:
            return False
    
    @staticmethod
    async def grab_banner(ip: str, port: int, timeout: float = 3.0) -> Optional[str]:
        """
        Grab banner from service
        
        Args:
            ip: Target IP address
            port: Port number
            timeout: Connection timeout
        
        Returns:
            Banner string or None
        """
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port),
                timeout=timeout
            )
            
            # Try to receive banner
            try:
                banner = await asyncio.wait_for(
                    reader.read(1024),
                    timeout=timeout
                )
                writer.close()
                await writer.wait_closed()
                return banner.decode('utf-8', errors='ignore').strip()
            except:
                pass
            
            writer.close()
            await writer.wait_closed()
            
        except:
            pass
        
        return None
    
    @classmethod
    async def scan(
        cls,
        ip: str,
        ports: List[int] = None,
        timeout: float = 2.0,
        grab_banners: bool = False
    ) -> List[PortResult]:
        """
        Scan multiple ports on a target
        
        Args:
            ip: Target IP address
            ports: List of ports to scan (default: TOP_PORTS)
            timeout: Connection timeout
            grab_banners: Whether to grab service banners
        
        Returns:
            List of PortResult objects
        """
        if ports is None:
            ports = cls.TOP_PORTS
        
        results = []
        
        # Scan ports concurrently
        tasks = [cls.scan_port(ip, port, timeout) for port in ports]
        scan_results = await asyncio.gather(*tasks)
        
        for port, is_open in zip(ports, scan_results):
            if is_open:
                service = cls.COMMON_PORTS.get(port, 'Unknown')
                banner = None
                
                if grab_banners:
                    banner = await cls.grab_banner(ip, port, timeout)
                
                results.append(PortResult(
                    port=port,
                    is_open=True,
                    service=service,
                    banner=banner
                ))
        
        return results
    
    @classmethod
    async def scan_range(
        cls,
        ip: str,
        start_port: int,
        end_port: int,
        timeout: float = 1.0,
        batch_size: int = 100
    ) -> List[PortResult]:
        """
        Scan a range of ports
        
        Args:
            ip: Target IP address
            start_port: Starting port number
            end_port: Ending port number
            timeout: Connection timeout
            batch_size: Number of ports to scan concurrently
        
        Returns:
            List of PortResult objects
        """
        results = []
        ports = list(range(start_port, end_port + 1))
        
        for i in range(0, len(ports), batch_size):
            batch = ports[i:i + batch_size]
            tasks = [cls.scan_port(ip, port, timeout) for port in batch]
            scan_results = await asyncio.gather(*tasks)
            
            for port, is_open in zip(batch, scan_results):
                if is_open:
                    service = cls.COMMON_PORTS.get(port, 'Unknown')
                    results.append(PortResult(
                        port=port,
                        is_open=True,
                        service=service
                    ))
        
        return results
    
    @classmethod
    def get_service_name(cls, port: int) -> str:
        """
        Get service name for a port
        
        Args:
            port: Port number
        
        Returns:
            Service name
        """
        return cls.COMMON_PORTS.get(port, 'Unknown')
    
    @classmethod
    def get_common_ports(cls) -> Dict[int, str]:
        """
        Get dictionary of common ports
        
        Returns:
            Dictionary mapping port numbers to service names
        """
        return cls.COMMON_PORTS.copy()