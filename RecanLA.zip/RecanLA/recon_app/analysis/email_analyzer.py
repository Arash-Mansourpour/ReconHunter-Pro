#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Email Analyzer for Recon Hunter Pro
"""

import re
import logging
from typing import Dict, List, Set, Tuple
from collections import defaultdict

logger = logging.getLogger(__name__)


class EmailAnalyzer:
    """
    Email enumeration and pattern discovery
    """
    
    # Email patterns
    EMAIL_PATTERNS = [
        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s*@\s*[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s*\[at\]\s*[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s*\(at\)\s*[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    ]
    
    # Common email patterns
    EMAIL_PATTERNS_COMMON = [
        '{first}@{domain}',
        '{last}@{domain}',
        '{first}.{last}@{domain}',
        '{first}_{last}@{domain}',
        '{first}-{last}@{domain}',
        '{f}{last}@{domain}',
        '{first}{l}@{domain}',
        '{first}.{last_initial}@{domain}',
        '{first_initial}.{last}@{domain}',
        '{first_initial}{last}@{domain}',
        '{first_initial}_{last}@{domain}',
        '{first_initial}-{last}@{domain}',
        '{last}.{first}@{domain}',
        '{last}_{first}@{domain}',
        '{last}-{first}@{domain}',
        '{last}{first_initial}@{domain}',
        '{last}.{first_initial}@{domain}',
        'info@{domain}',
        'contact@{domain}',
        'support@{domain}',
        'admin@{domain}',
        'sales@{domain}',
        'marketing@{domain}',
        'hr@{domain}',
        'jobs@{domain}',
        'careers@{domain}',
        'help@{domain}',
        'webmaster@{domain}',
        'hostmaster@{domain}',
        'postmaster@{domain}',
        'abuse@{domain}',
        'security@{domain}',
        'legal@{domain}',
        'finance@{domain}',
        'billing@{domain}',
        'noreply@{domain}',
        'no-reply@{domain}',
        'newsletter@{domain}',
        'notifications@{domain}',
        'alerts@{domain}',
        'hello@{domain}',
        'hi@{domain}',
        'team@{domain}',
        'office@{domain}',
        'mail@{domain}',
        'email@{domain}',
        'enquiry@{domain}',
        'inquiries@{domain}',
        'press@{domain}',
        'media@{domain}',
        'pr@{domain}',
        'partners@{domain}',
        'investors@{domain}',
        'ir@{domain}',
        'ceo@{domain}',
        'cto@{domain}',
        'cfo@{domain}',
        'coo@{domain}',
        'cio@{domain}',
        'dev@{domain}',
        'development@{domain}',
        'engineering@{domain}',
        'it@{domain}',
        'tech@{domain}',
        'api@{domain}',
        'service@{domain}',
        'services@{domain}',
        'customer@{domain}',
        'customers@{domain}',
        'client@{domain}',
        'clients@{domain}',
    ]
    
    @classmethod
    def extract_emails(cls, content: str) -> Set[str]:
        """
        Extract email addresses from content
        
        Args:
            content: Text content to search
        
        Returns:
            Set of email addresses
        """
        emails = set()
        
        for pattern in cls.EMAIL_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                # Clean up the email
                email = match.lower().strip()
                email = email.replace('[at]', '@').replace('(at)', '@')
                email = email.replace(' ', '')
                if cls._is_valid_email(email):
                    emails.add(email)
        
        return emails
    
    @classmethod
    def _is_valid_email(cls, email: str) -> bool:
        """
        Validate email format
        
        Args:
            email: Email address to validate
        
        Returns:
            True if valid, False otherwise
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @classmethod
    def generate_email_patterns(cls, first_name: str, last_name: str, domain: str) -> List[str]:
        """
        Generate possible email patterns for a person
        
        Args:
            first_name: First name
            last_name: Last name
            domain: Email domain
        
        Returns:
            List of possible email addresses
        """
        emails = []
        first = first_name.lower().strip()
        last = last_name.lower().strip()
        f = first[0] if first else ''
        l = last[0] if last else ''
        
        for pattern in cls.EMAIL_PATTERNS_COMMON:
            email = pattern.format(
                first=first,
                last=last,
                f=f,
                l=l,
                first_initial=f,
                last_initial=l,
                domain=domain
            )
            if cls._is_valid_email(email):
                emails.append(email)
        
        return emails
    
    @classmethod
    def analyze_email_patterns(cls, emails: Set[str]) -> Dict:
        """
        Analyze email patterns in a set of emails
        
        Args:
            emails: Set of email addresses
        
        Returns:
            Dictionary with pattern analysis
        """
        analysis = {
            'total_emails': len(emails),
            'domains': defaultdict(int),
            'usernames': defaultdict(int),
            'patterns': defaultdict(int),
            'common_prefixes': defaultdict(int),
            'common_suffixes': defaultdict(int)
        }
        
        for email in emails:
            try:
                username, domain = email.split('@')
                analysis['domains'][domain] += 1
                analysis['usernames'][username] += 1
                
                # Analyze username patterns
                if '.' in username:
                    analysis['patterns']['firstname.lastname'] += 1
                elif '_' in username:
                    analysis['patterns']['firstname_lastname'] += 1
                elif '-' in username:
                    analysis['patterns']['firstname-lastname'] += 1
                elif username.isalpha():
                    if len(username) <= 3:
                        analysis['patterns']['short'] += 1
                    else:
                        analysis['patterns']['single_name'] += 1
                elif any(c.isdigit() for c in username):
                    analysis['patterns']['contains_numbers'] += 1
                
                # Common prefixes
                prefix = username[:3] if len(username) >= 3 else username
                analysis['common_prefixes'][prefix] += 1
                
                # Common suffixes
                suffix = username[-3:] if len(username) >= 3 else username
                analysis['common_suffixes'][suffix] += 1
                
            except Exception:
                pass
        
        # Convert defaultdicts to regular dicts for JSON serialization
        analysis['domains'] = dict(analysis['domains'])
        analysis['usernames'] = dict(analysis['usernames'])
        analysis['patterns'] = dict(analysis['patterns'])
        analysis['common_prefixes'] = dict(analysis['common_prefixes'])
        analysis['common_suffixes'] = dict(analysis['common_suffixes'])
        
        return analysis
    
    @classmethod
    def categorize_emails(cls, emails: Set[str]) -> Dict[str, List[str]]:
        """
        Categorize emails by type
        
        Args:
            emails: Set of email addresses
        
        Returns:
            Dictionary with categorized emails
        """
        categories = {
            'personal': [],
            'role_based': [],
            'department': [],
            'generic': [],
            'other': []
        }
        
        role_based = [
            'info', 'contact', 'support', 'admin', 'sales', 'marketing',
            'hr', 'jobs', 'careers', 'help', 'webmaster', 'hostmaster',
            'postmaster', 'abuse', 'security', 'legal', 'finance', 'billing',
            'noreply', 'no-reply', 'newsletter', 'notifications', 'alerts',
            'hello', 'hi', 'team', 'office', 'mail', 'email', 'enquiry',
            'inquiries', 'press', 'media', 'pr', 'partners', 'investors',
            'ir', 'ceo', 'cto', 'cfo', 'coo', 'cio', 'dev', 'development',
            'engineering', 'it', 'tech', 'api', 'service', 'services',
            'customer', 'customers', 'client', 'clients'
        ]
        
        departments = [
            'sales', 'marketing', 'hr', 'finance', 'legal', 'engineering',
            'development', 'support', 'customer', 'it', 'tech', 'security'
        ]
        
        for email in emails:
            try:
                username = email.split('@')[0].lower()
                
                if username in role_based:
                    categories['role_based'].append(email)
                    if username in departments:
                        categories['department'].append(email)
                elif '.' in username or '_' in username or '-' in username:
                    categories['personal'].append(email)
                else:
                    categories['other'].append(email)
                    
            except Exception:
                categories['other'].append(email)
        
        return categories
    
    @classmethod
    def find_email_leaks(cls, emails: Set[str], domain: str) -> List[Dict]:
        """
        Find potential email leaks for a domain
        
        Args:
            emails: Set of discovered emails
            domain: Target domain
        
        Returns:
            List of potential leaks
        """
        leaks = []
        domain_emails = [e for e in emails if domain.lower() in e.lower()]
        
        for email in domain_emails:
            username = email.split('@')[0]
            leaks.append({
                'email': email,
                'username': username,
                'domain': domain,
                'type': 'discovered'
            })
        
        return leaks
    
    @classmethod
    def get_email_variations(cls, email: str) -> List[str]:
        """
        Generate variations of an email address
        
        Args:
            email: Original email address
        
        Returns:
            List of email variations
        """
        variations = []
        try:
            username, domain = email.split('@')
            
            # Add numbers
            for i in range(1, 10):
                variations.append(f"{username}{i}@{domain}")
            
            # Add common suffixes
            for suffix in ['dev', 'test', 'prod', 'staging', 'admin']:
                variations.append(f"{username}.{suffix}@{domain}")
                variations.append(f"{suffix}.{username}@{domain}")
            
            # Case variations
            variations.append(email.upper())
            variations.append(email.lower())
            variations.append(email.capitalize())
            
        except Exception:
            pass
        
        return variations