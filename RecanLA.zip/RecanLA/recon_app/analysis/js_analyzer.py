#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JavaScript Analyzer for Recon Hunter Pro
Enhanced with 100+ secret detection patterns
"""

import asyncio
import aiohttp
import re
import logging
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import urljoin
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class SecretFinding:
    """Secret finding data class"""
    type: str
    value: str
    source: str
    line_number: int = 0
    severity: str = "medium"
    confidence: str = "high"
    description: str = ""


class SecretPatterns:
    """
    Comprehensive secret patterns collection
    100+ patterns for detecting various types of secrets
    """
    
    # Cloud Provider Keys
    CLOUD_PATTERNS = {
        'AWS Access Key ID': {
            'pattern': r'AKIA[0-9A-Z]{16}',
            'severity': 'critical',
            'description': 'AWS Access Key ID - provides access to AWS resources'
        },
        'AWS Secret Access Key': {
            'pattern': r'(?i)aws(.{0,20})?[\'\"][0-9a-zA-Z/+=]{40}[\'\"]',
            'severity': 'critical',
            'description': 'AWS Secret Access Key'
        },
        'AWS Session Token': {
            'pattern': r'(?i)aws(.{0,20})?session(.{0,20})?[\'\"][0-9a-zA-Z/+=]{16,}[\'\"]',
            'severity': 'critical',
            'description': 'AWS Session Token'
        },
        'Google Cloud API Key': {
            'pattern': r'AIza[0-9A-Za-z\-_]{35}',
            'severity': 'high',
            'description': 'Google Cloud API Key'
        },
        'Google OAuth Access Token': {
            'pattern': r'ya29\.[0-9A-Za-z\-_]+',
            'severity': 'high',
            'description': 'Google OAuth Access Token'
        },
        'Google OAuth Client ID': {
            'pattern': r'[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com',
            'severity': 'medium',
            'description': 'Google OAuth Client ID'
        },
        'Google Service Account': {
            'pattern': r'[a-z0-9-]+@[a-z0-9-]+\.iam\.gserviceaccount\.com',
            'severity': 'high',
            'description': 'Google Service Account email'
        },
        'Azure Tenant ID': {
            'pattern': r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
            'severity': 'medium',
            'description': 'Azure Tenant ID (also matches other UUIDs)'
        },
        'Azure Client Secret': {
            'pattern': r'(?i)azure(.{0,20})?[\'\"][a-zA-Z0-9_\-]{34,42}[\'\"]',
            'severity': 'high',
            'description': 'Azure Client Secret'
        },
        'Azure Connection String': {
            'pattern': r'DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;]+;EndpointSuffix=core\.windows\.net',
            'severity': 'critical',
            'description': 'Azure Storage Connection String'
        },
        'Azure SAS Token': {
            'pattern': r'\?sv=[0-9]{4}-[0-9]{2}-[0-9]{2}&[a-zA-Z0-9=&%\-_]+',
            'severity': 'high',
            'description': 'Azure SAS Token'
        },
        'DigitalOcean Token': {
            'pattern': r'dop_v1_[a-f0-9]{64}',
            'severity': 'critical',
            'description': 'DigitalOcean Personal Access Token'
        },
        'Heroku API Key': {
            'pattern': r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
            'severity': 'high',
            'description': 'Heroku API Key (UUID format)'
        },
        'Linode API Key': {
            'pattern': r'[a-f0-9]{64}',
            'severity': 'high',
            'description': 'Linode API Key'
        },
        'Vultr API Key': {
            'pattern': r'[A-Z0-9]{36}',
            'severity': 'high',
            'description': 'Vultr API Key'
        },
        'Cloudflare API Key': {
            'pattern': r'[a-f0-9]{37}',
            'severity': 'high',
            'description': 'Cloudflare API Key'
        },
        'Cloudflare Origin CA Key': {
            'pattern': r'v1\.0-[a-f0-9]{64}',
            'severity': 'high',
            'description': 'Cloudflare Origin CA Key'
        },
    }
    
    # Version Control & CI/CD
    VCS_PATTERNS = {
        'GitHub Personal Access Token': {
            'pattern': r'ghp_[0-9a-zA-Z]{36}',
            'severity': 'critical',
            'description': 'GitHub Personal Access Token'
        },
        'GitHub OAuth Access Token': {
            'pattern': r'gho_[0-9a-zA-Z]{36}',
            'severity': 'critical',
            'description': 'GitHub OAuth Access Token'
        },
        'GitHub App Token': {
            'pattern': r'(ghu|ghs)_[0-9a-zA-Z]{36}',
            'severity': 'critical',
            'description': 'GitHub App Token'
        },
        'GitHub Refresh Token': {
            'pattern': r'ghr_[0-9a-zA-Z]{36}',
            'severity': 'critical',
            'description': 'GitHub Refresh Token'
        },
        'GitLab Personal Access Token': {
            'pattern': r'glpat-[0-9a-zA-Z\-_]{20}',
            'severity': 'critical',
            'description': 'GitLab Personal Access Token'
        },
        'GitLab Pipeline Trigger Token': {
            'pattern': r'glptt-[0-9a-f]{40}',
            'severity': 'high',
            'description': 'GitLab Pipeline Trigger Token'
        },
        'GitLab Runner Token': {
            'pattern': r'GR1348941[0-9a-zA-Z]{20}',
            'severity': 'critical',
            'description': 'GitLab Runner Token'
        },
        'Bitbucket App Password': {
            'pattern': r'ATBB[A-Za-z0-9]{24}',
            'severity': 'high',
            'description': 'Bitbucket App Password'
        },
        'Bitbucket OAuth Token': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'medium',
            'description': 'Bitbucket OAuth Token'
        },
        'Jenkins API Token': {
            'pattern': r'[0-9a-f]{32}',
            'severity': 'high',
            'description': 'Jenkins API Token'
        },
        'Travis CI Token': {
            'pattern': r'[a-zA-Z0-9]{22}',
            'severity': 'high',
            'description': 'Travis CI Token'
        },
        'CircleCI Token': {
            'pattern': r'[a-f0-9]{40}',
            'severity': 'high',
            'description': 'CircleCI Token'
        },
        'TeamCity Token': {
            'pattern': r'[a-zA-Z0-9]{32}',
            'severity': 'high',
            'description': 'TeamCity Token'
        },
    }
    
    # Communication & Collaboration
    COMMUNICATION_PATTERNS = {
        'Slack Bot Token': {
            'pattern': r'xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}',
            'severity': 'critical',
            'description': 'Slack Bot Token'
        },
        'Slack User Token': {
            'pattern': r'xoxp-[0-9]{10,13}-[0-9]{10,13}-[0-9]{10,13}-[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Slack User Token'
        },
        'Slack App Token': {
            'pattern': r'xoxa-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}',
            'severity': 'critical',
            'description': 'Slack App Token'
        },
        'Slack Webhook URL': {
            'pattern': r'https://hooks\.slack\.com/services/T[0-9A-Z]{8,}/B[0-9A-Z]{8,}/[a-zA-Z0-9]{24}',
            'severity': 'high',
            'description': 'Slack Webhook URL'
        },
        'Discord Bot Token': {
            'pattern': r'[MN][a-zA-Z\d]{23}\.[\w-]{6}\.[\w-]{27}',
            'severity': 'critical',
            'description': 'Discord Bot Token'
        },
        'Discord Webhook URL': {
            'pattern': r'https://discord\.com/api/webhooks/\d+/[a-zA-Z0-9_-]+',
            'severity': 'high',
            'description': 'Discord Webhook URL'
        },
        'Telegram Bot Token': {
            'pattern': r'[0-9]{8,10}:[a-zA-Z0-9_-]{35}',
            'severity': 'critical',
            'description': 'Telegram Bot Token'
        },
        'Microsoft Teams Webhook': {
            'pattern': r'https://outlook\.office\.com/webhook/[a-f0-9-]+@[a-f0-9-]+/IncomingWebhook/[a-f0-9]+/[a-f0-9-]+',
            'severity': 'high',
            'description': 'Microsoft Teams Webhook'
        },
        'Twilio Account SID': {
            'pattern': r'AC[a-f0-9]{32}',
            'severity': 'high',
            'description': 'Twilio Account SID'
        },
        'Twilio Auth Token': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Twilio Auth Token'
        },
        'Twilio API Key': {
            'pattern': r'SK[a-f0-9]{32}',
            'severity': 'high',
            'description': 'Twilio API Key'
        },
        'SendGrid API Key': {
            'pattern': r'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}',
            'severity': 'critical',
            'description': 'SendGrid API Key'
        },
        'Mailgun API Key': {
            'pattern': r'key-[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Mailgun API Key'
        },
        'Mailgun Domain Verification Key': {
            'pattern': r'k=pubkey-[a-f0-9]{32}',
            'severity': 'medium',
            'description': 'Mailgun Domain Verification Key'
        },
        'Mailchimp API Key': {
            'pattern': r'[a-f0-9]{32}-us[0-9]{1,2}',
            'severity': 'critical',
            'description': 'Mailchimp API Key'
        },
        'Mandrill API Key': {
            'pattern': r'[a-f0-9]{32}-us[0-9]{1,2}',
            'severity': 'high',
            'description': 'Mandrill API Key'
        },
        'SparkPost API Key': {
            'pattern': r'[a-f0-9]{40}',
            'severity': 'high',
            'description': 'SparkPost API Key'
        },
        'Postmark API Token': {
            'pattern': r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',
            'severity': 'high',
            'description': 'Postmark API Token'
        },
    }
    
    # Payment & E-commerce
    PAYMENT_PATTERNS = {
        'Stripe Secret Key': {
            'pattern': r'sk_live_[0-9a-zA-Z]{24}',
            'severity': 'critical',
            'description': 'Stripe Secret Key - LIVE'
        },
        'Stripe Test Secret Key': {
            'pattern': r'sk_test_[0-9a-zA-Z]{24}',
            'severity': 'high',
            'description': 'Stripe Test Secret Key'
        },
        'Stripe Publishable Key': {
            'pattern': r'pk_live_[0-9a-zA-Z]{24}',
            'severity': 'medium',
            'description': 'Stripe Publishable Key - LIVE'
        },
        'Stripe Test Publishable Key': {
            'pattern': r'pk_test_[0-9a-zA-Z]{24}',
            'severity': 'low',
            'description': 'Stripe Test Publishable Key'
        },
        'Stripe Restricted Key': {
            'pattern': r'rk_live_[0-9a-zA-Z]{24}',
            'severity': 'critical',
            'description': 'Stripe Restricted Key - LIVE'
        },
        'Square Access Token': {
            'pattern': r'sq0atp-[0-9A-Za-z\-_]{22}',
            'severity': 'critical',
            'description': 'Square Access Token'
        },
        'Square Production Secret': {
            'pattern': r'sq0csp-[0-9A-Za-z\-_]{43}',
            'severity': 'critical',
            'description': 'Square Production Secret'
        },
        'PayPal Client ID': {
            'pattern': r'A[a-zA-Z0-9_-]{80}',
            'severity': 'high',
            'description': 'PayPal Client ID'
        },
        'PayPal Client Secret': {
            'pattern': r'[A-Za-z0-9_-]{80}',
            'severity': 'critical',
            'description': 'PayPal Client Secret'
        },
        'Braintree Access Token': {
            'pattern': r'access_token\$production\$[a-z0-9]{16}\$[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Braintree Access Token'
        },
        'Plaid Client ID': {
            'pattern': r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',
            'severity': 'medium',
            'description': 'Plaid Client ID'
        },
        'Plaid Secret Key': {
            'pattern': r'[a-f0-9]{30}',
            'severity': 'critical',
            'description': 'Plaid Secret Key'
        },
        'Shopify Access Token': {
            'pattern': r'shpua_[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Shopify Access Token'
        },
        'Shopify Private App Password': {
            'pattern': r'shpss_[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Shopify Private App Password'
        },
    }
    
    # Database & Storage
    DATABASE_PATTERNS = {
        'MongoDB Connection String': {
            'pattern': r'mongodb(\+srv)?://[^:]+:[^@]+@[^\s]+',
            'severity': 'critical',
            'description': 'MongoDB Connection String with credentials'
        },
        'MySQL Connection String': {
            'pattern': r'mysql://[^:]+:[^@]+@[^\s]+',
            'severity': 'critical',
            'description': 'MySQL Connection String with credentials'
        },
        'PostgreSQL Connection String': {
            'pattern': r'postgres(ql)?://[^:]+:[^@]+@[^\s]+',
            'severity': 'critical',
            'description': 'PostgreSQL Connection String with credentials'
        },
        'Redis Connection String': {
            'pattern': r'redis://[^:]*:[^@]+@[^\s]+',
            'severity': 'critical',
            'description': 'Redis Connection String with credentials'
        },
        'Elasticsearch URL with Auth': {
            'pattern': r'https?://[^:]+:[^@]+@[^\s]*\.elasticsearch\.[^\s]+',
            'severity': 'critical',
            'description': 'Elasticsearch URL with authentication'
        },
        'Firebase Database URL': {
            'pattern': r'https://[a-z0-9-]+\.firebaseio\.com',
            'severity': 'medium',
            'description': 'Firebase Database URL'
        },
        'Firebase API Key': {
            'pattern': r'AIza[0-9A-Za-z\-_]{35}',
            'severity': 'high',
            'description': 'Firebase API Key'
        },
        'Supabase URL': {
            'pattern': r'https://[a-z0-9]+\.supabase\.co',
            'severity': 'medium',
            'description': 'Supabase URL'
        },
        'Supabase Anon Key': {
            'pattern': r'eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*',
            'severity': 'medium',
            'description': 'Supabase/JWT Token'
        },
    }
    
    # Authentication & Security
    AUTH_PATTERNS = {
        'JWT Token': {
            'pattern': r'eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*',
            'severity': 'high',
            'description': 'JWT Token'
        },
        'Private Key (RSA/DSA/EC)': {
            'pattern': r'-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----',
            'severity': 'critical',
            'description': 'Private Key detected'
        },
        'Private Key (PKCS8)': {
            'pattern': r'-----BEGIN PRIVATE KEY-----',
            'severity': 'critical',
            'description': 'PKCS8 Private Key'
        },
        'Encrypted Private Key': {
            'pattern': r'-----BEGIN ENCRYPTED PRIVATE KEY-----',
            'severity': 'critical',
            'description': 'Encrypted Private Key'
        },
        'PGP Private Key': {
            'pattern': r'-----BEGIN PGP PRIVATE KEY BLOCK-----',
            'severity': 'critical',
            'description': 'PGP Private Key'
        },
        'SSH Private Key': {
            'pattern': r'-----BEGIN OPENSSH PRIVATE KEY-----',
            'severity': 'critical',
            'description': 'OpenSSH Private Key'
        },
        'Public Key': {
            'pattern': r'-----BEGIN (?:RSA |DSA |EC )?PUBLIC KEY-----',
            'severity': 'low',
            'description': 'Public Key'
        },
        'Certificate': {
            'pattern': r'-----BEGIN CERTIFICATE-----',
            'severity': 'low',
            'description': 'SSL/TLS Certificate'
        },
        'Basic Auth Header': {
            'pattern': r'Authorization:\s*Basic\s+[A-Za-z0-9+/=]+',
            'severity': 'high',
            'description': 'Basic Authentication Header'
        },
        'Bearer Token': {
            'pattern': r'Authorization:\s*Bearer\s+[A-Za-z0-9_\-\.]+',
            'severity': 'high',
            'description': 'Bearer Token'
        },
        'OAuth Token': {
            'pattern': r'access_token=[a-zA-Z0-9_\-]+',
            'severity': 'high',
            'description': 'OAuth Access Token in URL'
        },
    }
    
    # Social Media & APIs
    SOCIAL_PATTERNS = {
        'Facebook Access Token': {
            'pattern': r'EAACEdEose0cBA[0-9A-Za-z]+',
            'severity': 'critical',
            'description': 'Facebook Access Token'
        },
        'Facebook App Secret': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'critical',
            'description': 'Facebook App Secret'
        },
        'Twitter API Key': {
            'pattern': r'[a-zA-Z0-9]{25}',
            'severity': 'high',
            'description': 'Twitter API Key'
        },
        'Twitter API Secret': {
            'pattern': r'[a-zA-Z0-9]{50}',
            'severity': 'critical',
            'description': 'Twitter API Secret'
        },
        'Twitter Bearer Token': {
            'pattern': r'AAAAAAAAAAAAAAAAAAAA[a-zA-Z0-9%\-_]+',
            'severity': 'critical',
            'description': 'Twitter Bearer Token'
        },
        'Twitter Access Token': {
            'pattern': r'[0-9]+-[a-zA-Z0-9]{40}',
            'severity': 'high',
            'description': 'Twitter Access Token'
        },
        'LinkedIn Client ID': {
            'pattern': r'[a-z0-9]{14}',
            'severity': 'medium',
            'description': 'LinkedIn Client ID'
        },
        'LinkedIn Client Secret': {
            'pattern': r'[a-zA-Z0-9]{16}',
            'severity': 'high',
            'description': 'LinkedIn Client Secret'
        },
        'Instagram Access Token': {
            'pattern': r'IGQVJ[a-zA-Z0-9_\-]+',
            'severity': 'high',
            'description': 'Instagram Access Token'
        },
        'Reddit Client ID': {
            'pattern': r'[a-zA-Z0-9]{14}',
            'severity': 'medium',
            'description': 'Reddit Client ID'
        },
        'Reddit Client Secret': {
            'pattern': r'[a-zA-Z0-9]{27}',
            'severity': 'high',
            'description': 'Reddit Client Secret'
        },
        'Pinterest Access Token': {
            'pattern': r'pina_[a-zA-Z0-9]{32}',
            'severity': 'high',
            'description': 'Pinterest Access Token'
        },
    }
    
    # AI/ML Services
    AI_PATTERNS = {
        'OpenAI API Key': {
            'pattern': r'sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}',
            'severity': 'critical',
            'description': 'OpenAI API Key'
        },
        'OpenAI Organization ID': {
            'pattern': r'org-[a-zA-Z0-9]{24}',
            'severity': 'medium',
            'description': 'OpenAI Organization ID'
        },
        'Anthropic API Key': {
            'pattern': r'sk-ant-[a-zA-Z0-9]{32}',
            'severity': 'critical',
            'description': 'Anthropic API Key'
        },
        'Hugging Face Token': {
            'pattern': r'hf_[a-zA-Z0-9]{34}',
            'severity': 'high',
            'description': 'Hugging Face Token'
        },
        'Replicate API Token': {
            'pattern': r'r8_[a-zA-Z0-9]{24}',
            'severity': 'high',
            'description': 'Replicate API Token'
        },
        'Cohere API Key': {
            'pattern': r'[a-zA-Z0-9]{40}',
            'severity': 'high',
            'description': 'Cohere API Key'
        },
        'Stability AI API Key': {
            'pattern': r'sk-[a-zA-Z0-9]{32}',
            'severity': 'high',
            'description': 'Stability AI API Key'
        },
    }
    
    # Monitoring & Analytics
    MONITORING_PATTERNS = {
        'Datadog API Key': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'high',
            'description': 'Datadog API Key'
        },
        'Datadog Application Key': {
            'pattern': r'[a-f0-9]{40}',
            'severity': 'high',
            'description': 'Datadog Application Key'
        },
        'New Relic API Key': {
            'pattern': r'[A-Za-z0-9]{40}',
            'severity': 'high',
            'description': 'New Relic API Key'
        },
        'New Relic Insights Key': {
            'pattern': r'[A-Za-z0-9]{32}',
            'severity': 'high',
            'description': 'New Relic Insights Key'
        },
        'Sentry DSN': {
            'pattern': r'https://[a-f0-9]+@[a-z0-9]+\.ingest\.sentry\.io/[0-9]+',
            'severity': 'high',
            'description': 'Sentry DSN with credentials'
        },
        'Sentry Auth Token': {
            'pattern': r'sntrys_[a-zA-Z0-9]{32}',
            'severity': 'high',
            'description': 'Sentry Auth Token'
        },
        'PagerDuty API Key': {
            'pattern': r'[a-zA-Z0-9]{20}',
            'severity': 'high',
            'description': 'PagerDuty API Key'
        },
        'Splunk HEC Token': {
            'pattern': r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',
            'severity': 'high',
            'description': 'Splunk HEC Token'
        },
        'LogDNA Ingestion Key': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'high',
            'description': 'LogDNA Ingestion Key'
        },
        'Amplitude API Key': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'medium',
            'description': 'Amplitude API Key'
        },
        'Mixpanel API Secret': {
            'pattern': r'[a-f0-9]{32}',
            'severity': 'high',
            'description': 'Mixpanel API Secret'
        },
        'Segment API Key': {
            'pattern': r'[a-zA-Z0-9]{24}',
            'severity': 'high',
            'description': 'Segment API Key'
        },
    }
    
    # Generic Patterns
    GENERIC_PATTERNS = {
        'Generic API Key': {
            'pattern': r'(?i)(api[_-]?key|apikey|api[_-]?secret|secret[_-]?key)[\s]*[=:]\s*[\'\"][a-zA-Z0-9_\-]{20,}[\'\"]',
            'severity': 'high',
            'description': 'Generic API Key pattern'
        },
        'Generic Secret': {
            'pattern': r'(?i)(secret|password|passwd|pwd|token|auth)[\s]*[=:]\s*[\'\"][a-zA-Z0-9_\-!@#$%^&*()]{8,}[\'\"]',
            'severity': 'high',
            'description': 'Generic secret pattern'
        },
        'URL with Credentials': {
            'pattern': r'https?://[^:]+:[^@]+@[^\s]+',
            'severity': 'critical',
            'description': 'URL with embedded credentials'
        },
        'Generic Password in Config': {
            'pattern': r'(?i)(password|passwd|pwd)\s*[=:]\s*[\'\"][^\'\"]{4,}[\'\"]',
            'severity': 'high',
            'description': 'Password in configuration'
        },
        'Generic Token': {
            'pattern': r'(?i)(token|bearer|jwt)[\s]*[=:]\s*[\'\"][a-zA-Z0-9_\-\.]{20,}[\'\"]',
            'severity': 'high',
            'description': 'Generic token pattern'
        },
    }
    
    @classmethod
    def get_all_patterns(cls) -> Dict[str, Dict]:
        """Get all secret patterns combined"""
        all_patterns = {}
        for category in [
            cls.CLOUD_PATTERNS,
            cls.VCS_PATTERNS,
            cls.COMMUNICATION_PATTERNS,
            cls.PAYMENT_PATTERNS,
            cls.DATABASE_PATTERNS,
            cls.AUTH_PATTERNS,
            cls.SOCIAL_PATTERNS,
            cls.AI_PATTERNS,
            cls.MONITORING_PATTERNS,
            cls.GENERIC_PATTERNS,
        ]:
            all_patterns.update(category)
        return all_patterns


class JavaScriptAnalyzer:
    """
    JavaScript analysis for secret detection and API endpoint discovery
    Enhanced with 100+ secret patterns
    """
    
    def __init__(self, timeout: int = 30):
        """
        Initialize JavaScript analyzer
        
        Args:
            timeout: Request timeout in seconds
        """
        self.timeout = timeout
        self.session: Optional[aiohttp.ClientSession] = None
        self.secret_patterns = SecretPatterns.get_all_patterns()
    
    async def init_session(self):
        """Initialize aiohttp session"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self.session = aiohttp.ClientSession(timeout=timeout)
    
    async def close_session(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def fetch_js_file(self, url: str) -> Optional[str]:
        """
        Fetch JavaScript file content
        
        Args:
            url: URL to JavaScript file
        
        Returns:
            JavaScript content or None
        """
        try:
            await self.init_session()
            async with self.session.get(url, ssl=False) as response:
                if response.status == 200:
                    return await response.text()
        except Exception as e:
            logger.debug(f"Error fetching JS file {url}: {e}")
        return None
    
    def extract_js_files(self, html: str, base_url: str) -> List[str]:
        """
        Extract JavaScript file URLs from HTML
        
        Args:
            html: HTML content
            base_url: Base URL for resolving relative paths
        
        Returns:
            List of JavaScript file URLs
        """
        js_files = set()
        
        # Pattern for script src
        patterns = [
            r'<script[^>]+src=[\'\"]([^\'\"]+\.js[^\'\"]*)[\'\"]',
            r'<script[^>]+src=([^\s>]+\.js[^\s>]*)',
            r'src=[\'\"]([^\'\"]+\.js[^\'\"]*)[\'\"]',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, html, re.IGNORECASE)
            for match in matches:
                full_url = urljoin(base_url, match)
                js_files.add(full_url)
        
        return list(js_files)
    
    def find_secrets(self, content: str, source: str = "") -> List[Dict]:
        """
        Find secrets in JavaScript content
        
        Args:
            content: JavaScript content
            source: Source URL for reference
        
        Returns:
            List of found secrets
        """
        secrets = []
        
        for secret_type, config in self.secret_patterns.items():
            try:
                pattern = config['pattern']
                severity = config.get('severity', 'medium')
                description = config.get('description', '')
                
                matches = re.findall(pattern, content)
                for match in matches:
                    # Handle tuple matches
                    if isinstance(match, tuple):
                        match = match[0] if match[0] else match[1] if len(match) > 1 else None
                    
                    if match and len(str(match)) > 5:
                        secrets.append({
                            'type': secret_type,
                            'value': str(match)[:100],  # Truncate for safety
                            'source': source,
                            'severity': severity,
                            'description': description,
                            'confidence': 'high' if severity in ['critical', 'high'] else 'medium'
                        })
            except Exception as e:
                logger.debug(f"Error finding {secret_type}: {e}")
        
        return secrets
    
    def find_api_endpoints(self, content: str, base_url: str) -> List[str]:
        """
        Find API endpoints in JavaScript content
        
        Args:
            content: JavaScript content
            base_url: Base URL for resolving relative paths
        
        Returns:
            List of API endpoints
        """
        endpoints = set()
        
        api_patterns = [
            r'[\'\"]/(api|v[0-9])/[a-zA-Z0-9_\-/]+[\'\"]',
            r'[\'\"]https?://[^\'\"]+/api/[^\'\"]+[\'\"]',
            r'[\'\"]https?://api\.[^\'\"]+[\'\"]',
            r'fetch\([\'\"]([^\'\"]+)[\'\"]',
            r'axios\.[a-z]+\([\'\"]([^\'\"]+)[\'\"]',
            r'\.ajax\(\s*\{[^}]*url\s*:\s*[\'\"]([^\'\"]+)[\'\"]',
            r'XMLHttpRequest.*open\([\'\"]GET[\'\"],[\'\"]([^\'\"]+)[\'\"]',
            r'[\'\"]/(graphql|gql)[\'\"]',
            r'[\'\"]https?://[^\'\"]*/graphql[\'\"]',
        ]
        
        for pattern in api_patterns:
            try:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    if isinstance(match, tuple):
                        match = match[0] if match[0] else None
                    if match:
                        # Resolve relative URLs
                        full_url = urljoin(base_url, match)
                        endpoints.add(full_url)
            except Exception as e:
                logger.debug(f"Error finding API endpoints: {e}")
        
        return list(endpoints)
    
    def find_interesting_strings(self, content: str) -> Dict[str, List[str]]:
        """
        Find interesting strings in JavaScript content
        
        Args:
            content: JavaScript content
        
        Returns:
            Dictionary of interesting string categories
        """
        results = {
            'urls': [],
            'domains': [],
            'ips': [],
            'internal_ips': [],
            'emails': [],
            'paths': [],
            'comments': [],
            'potential_endpoints': [],
            'base64_strings': [],
        }
        
        # URLs
        url_pattern = r'https?://[^\s\'\"<>]+'
        results['urls'] = list(set(re.findall(url_pattern, content)))[:50]
        
        # Domains
        domain_pattern = r'[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+'
        results['domains'] = list(set(re.findall(domain_pattern, content)))[:50]
        
        # IP addresses
        ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
        results['ips'] = list(set(re.findall(ip_pattern, content)))[:30]
        
        # Internal IPs
        internal_ip_pattern = r'\b(?:10|127|172\.(?:1[6-9]|2[0-9]|3[01])|192\.168)\.[0-9]{1,3}\.[0-9]{1,3}\b'
        results['internal_ips'] = list(set(re.findall(internal_ip_pattern, content)))[:20]
        
        # Emails
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        results['emails'] = list(set(re.findall(email_pattern, content)))[:30]
        
        # Paths
        path_pattern = r'[\'\"](/[a-zA-Z0-9_\-./]+)[\'\"]'
        results['paths'] = list(set(re.findall(path_pattern, content)))[:50]
        
        # Comments
        comment_pattern = r'//.*$|/\*[\s\S]*?\*/'
        results['comments'] = re.findall(comment_pattern, content, re.MULTILINE)[:20]
        
        # Potential API endpoints
        endpoint_pattern = r'[\'\"](/[a-zA-Z0-9_\-]{3,})[\'\"]'
        results['potential_endpoints'] = list(set(re.findall(endpoint_pattern, content)))[:30]
        
        # Base64 strings
        base64_pattern = r'[\'\"]([A-Za-z0-9+/]{20,}={0,2})[\'\"]'
        results['base64_strings'] = list(set(re.findall(base64_pattern, content)))[:20]
        
        return results
    
    def find_cloud_buckets(self, content: str) -> List[Dict]:
        """
        Find cloud storage bucket references
        
        Args:
            content: JavaScript content
        
        Returns:
            List of cloud bucket references
        """
        buckets = []
        
        bucket_patterns = [
            (r'https?://([a-z0-9-]+)\.s3[.-]([a-z0-9-]*)\.amazonaws\.com', 'AWS S3'),
            (r'https?://s3[.-]([a-z0-9-]*)\.amazonaws\.com/([a-z0-9-]+)', 'AWS S3'),
            (r'https?://([a-z0-9-]+)\.blob\.core\.windows\.net', 'Azure Blob'),
            (r'https?://([a-z0-9-]+)\.storage\.googleapis\.com', 'GCS'),
            (r'https?://storage\.googleapis\.com/([a-z0-9-]+)', 'GCS'),
            (r'https?://([a-z0-9-]+)\.digitaloceanspaces\.com', 'DigitalOcean Spaces'),
            (r'https?://([a-z0-9-]+)\.r2\.cloudflarestorage\.com', 'Cloudflare R2'),
        ]
        
        for pattern, provider in bucket_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                bucket_name = match[0] if isinstance(match, tuple) else match
                buckets.append({
                    'provider': provider,
                    'bucket': bucket_name,
                    'pattern': pattern
                })
        
        return buckets
    
    async def analyze_url(self, url: str) -> Dict:
        """
        Analyze a URL for JavaScript files and secrets
        
        Args:
            url: URL to analyze
        
        Returns:
            Analysis results
        """
        results = {
            'url': url,
            'js_files': [],
            'secrets': [],
            'api_endpoints': [],
            'interesting_strings': {},
            'cloud_buckets': [],
        }
        
        try:
            await self.init_session()
            
            # Fetch main page
            async with self.session.get(url, ssl=False) as response:
                if response.status == 200:
                    html = await response.text()
                    
                    # Extract JS files
                    js_files = self.extract_js_files(html, url)
                    results['js_files'] = js_files
                    
                    # Analyze each JS file
                    for js_url in js_files[:30]:  # Limit to 30 files
                        js_content = await self.fetch_js_file(js_url)
                        if js_content:
                            # Find secrets
                            secrets = self.find_secrets(js_content, js_url)
                            results['secrets'].extend(secrets)
                            
                            # Find API endpoints
                            endpoints = self.find_api_endpoints(js_content, url)
                            results['api_endpoints'].extend(endpoints)
                            
                            # Find cloud buckets
                            buckets = self.find_cloud_buckets(js_content)
                            results['cloud_buckets'].extend(buckets)
                            
                            # Find interesting strings
                            interesting = self.find_interesting_strings(js_content)
                            if not results['interesting_strings']:
                                results['interesting_strings'] = interesting
                            else:
                                for key, values in interesting.items():
                                    results['interesting_strings'][key].extend(values)
                    
                    # Also check HTML for secrets
                    html_secrets = self.find_secrets(html, url)
                    results['secrets'].extend(html_secrets)
                    
                    # Check HTML for cloud buckets
                    html_buckets = self.find_cloud_buckets(html)
                    results['cloud_buckets'].extend(html_buckets)
        
        except Exception as e:
            logger.error(f"Error analyzing {url}: {e}")
        
        # Deduplicate
        results['api_endpoints'] = list(set(results['api_endpoints']))
        
        # Deduplicate secrets by type and value
        seen_secrets = set()
        unique_secrets = []
        for secret in results['secrets']:
            key = (secret['type'], secret['value'])
            if key not in seen_secrets:
                seen_secrets.add(key)
                unique_secrets.append(secret)
        results['secrets'] = unique_secrets
        
        return results
    
    async def analyze_multiple_urls(self, urls: List[str]) -> Dict:
        """
        Analyze multiple URLs
        
        Args:
            urls: List of URLs to analyze
        
        Returns:
            Combined analysis results
        """
        results = {
            'total_urls': len(urls),
            'total_js_files': 0,
            'all_secrets': [],
            'all_api_endpoints': set(),
            'all_interesting_strings': {},
            'all_cloud_buckets': [],
        }
        
        for url in urls:
            analysis = await self.analyze_url(url)
            results['total_js_files'] += len(analysis['js_files'])
            results['all_secrets'].extend(analysis['secrets'])
            results['all_api_endpoints'].update(analysis['api_endpoints'])
            results['all_cloud_buckets'].extend(analysis['cloud_buckets'])
        
        results['all_api_endpoints'] = list(results['all_api_endpoints'])
        
        await self.close_session()
        
        return results


async def scan_for_secrets(url: str, timeout: int = 30) -> Dict:
    """
    Convenience function to scan a URL for secrets
    
    Args:
        url: URL to scan
        timeout: Request timeout
    
    Returns:
        Scan results
    """
    analyzer = JavaScriptAnalyzer(timeout=timeout)
    return await analyzer.analyze_url(url)