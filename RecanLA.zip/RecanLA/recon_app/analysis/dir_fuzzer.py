#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Directory/Path Fuzzing Module for Recon Hunter Pro
Simple directory fuzzing using aiohttp - no external tools required
"""

import asyncio
import aiohttp
import logging
import re
from typing import List, Dict, Set, Optional, Tuple
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse
import random

logger = logging.getLogger(__name__)


@dataclass
class FuzzResult:
    """Result of a directory fuzz operation"""
    url: str
    path: str
    status_code: int
    content_length: int
    content_type: str = ""
    title: str = ""
    redirect: str = ""
    is_interesting: bool = False
    reason: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'url': self.url,
            'path': self.path,
            'status_code': self.status_code,
            'content_length': self.content_length,
            'content_type': self.content_type,
            'title': self.title,
            'redirect': self.redirect,
            'is_interesting': self.is_interesting,
            'reason': self.reason
        }


class DirectoryFuzzer:
    """
    Simple directory/path fuzzer using aiohttp
    No external tools required - pure Python implementation
    """
    
    # Common sensitive files and directories
    SENSITIVE_PATHS = [
        # Configuration files
        '.env', '.env.local', '.env.production', '.env.development',
        '.env.backup', '.env.old', '.env.save', '.env.bak',
        'config.php', 'config.inc', 'config.inc.php', 'config.yml',
        'config.yaml', 'config.json', 'config.xml', 'config.ini',
        'configuration.php', 'configuration.xml', 'configuration.json',
        'settings.php', 'settings.py', 'settings.json', 'settings.yml',
        'app.config', 'web.config', 'application.conf',
        
        # Backup files
        'backup', 'backup.zip', 'backup.tar', 'backup.tar.gz',
        'backup.sql', 'backup.db', 'backup.json',
        'backups', 'backups.zip', 'backups.tar.gz',
        'db_backup', 'db_backup.sql', 'database_backup.sql',
        '.backup', '.backup.zip', '.backup.tar.gz',
        
        # Database files
        'database.sql', 'database.db', 'database.sqlite',
        'db.sql', 'db.sqlite', 'db.sqlite3',
        'data.sql', 'data.db', 'data.sqlite',
        'dump.sql', 'mysql.sql', 'mysql_backup.sql',
        
        # Git/SVN
        '.git', '.git/config', '.git/HEAD', '.gitignore',
        '.gitattributes', '.gitmodules',
        '.svn', '.svn/entries', '.svnignore',
        '.hg', '.hg/store',
        
        # Credentials and secrets
        'credentials', 'credentials.json', 'credentials.yml',
        'secrets', 'secrets.json', 'secrets.yml', 'secrets.xml',
        'keys', 'keys.json', 'keys.xml',
        'passwords', 'passwords.txt', 'passwords.json',
        '.htpasswd', '.htaccess',
        'id_rsa', 'id_rsa.pub', 'id_dsa', 'id_dsa.pub',
        '.ssh', '.ssh/id_rsa', '.ssh/authorized_keys',
        'private.key', 'private_key', 'private_key.pem',
        'public.key', 'public_key', 'public_key.pem',
        
        # Admin panels
        'admin', 'admin/', 'admin.php', 'admin.html',
        'administrator', 'administrator/', 'administrator.php',
        'adminpanel', 'adminpanel/', 'admin-panel',
        'admincp', 'admincp/', 'admin-cp',
        'cpanel', 'cpanel/', 'cp/',
        'manage', 'manage/', 'management',
        'backend', 'backend/', 'backend.php',
        'dashboard', 'dashboard/', 'dashboard.php',
        'control', 'control/', 'control-panel',
        'console', 'console/', 'console.php',
        
        # Login pages
        'login', 'login/', 'login.php', 'login.html',
        'signin', 'signin/', 'signin.php',
        'sign-in', 'sign-in/', 'sign-in.php',
        'auth', 'auth/', 'auth.php',
        'authenticate', 'authenticate/',
        
        # API endpoints
        'api', 'api/', 'api/v1', 'api/v2', 'api/v3',
        'api/v1/', 'api/v2/', 'api/v3/',
        'api/graphql', 'api/rest', 'api/json',
        'graphql', 'graphql/', 'graphql.php',
        'rest', 'rest/', 'rest-api',
        
        # Upload areas
        'upload', 'upload/', 'uploads', 'uploads/',
        'upload.php', 'upload.html', 'uploader.php',
        'files', 'files/', 'file', 'file/',
        
        # Documentation
        'docs', 'docs/', 'documentation', 'documentation/',
        'readme', 'readme.md', 'readme.txt', 'README.md',
        'changelog', 'changelog.md', 'CHANGELOG.md',
        'api-docs', 'api-docs/', 'api-docs.html',
        
        # Logs
        'logs', 'logs/', 'log', 'log/',
        'error.log', 'access.log', 'debug.log',
        'error_log', 'access_log', 'debug_log',
        'server.log', 'app.log', 'application.log',
        
        # Temp/Debug
        'temp', 'temp/', 'tmp', 'tmp/',
        'test', 'test/', 'tests', 'tests/',
        'debug', 'debug/', 'debug.php',
        'phpinfo.php', 'info.php', 'test.php',
        'status', 'status/', 'status.php', 'health',
        'server-status', 'server-info',
        
        # CMS specific
        'wp-admin', 'wp-admin/', 'wp-login.php', 'wp-content',
        'wp-includes', 'wp-config.php', 'wp-config.bak',
        'xmlrpc.php', 'wp-cron.php',
        'administrator/', 'administrator/index.php',
        'joomla', 'joomla/', 'drupal', 'drupal/',
        'sites/default', 'sites/default/settings.php',
        
        # Framework specific
        '.env.example', '.env.sample', '.env.template',
        'composer.json', 'composer.lock', 'package.json', 'package-lock.json',
        'requirements.txt', 'Pipfile', 'Pipfile.lock',
        'Gemfile', 'Gemfile.lock', 'Cargo.toml',
        'go.mod', 'go.sum',
        
        # Cloud/DevOps
        '.aws', '.aws/credentials', '.aws/config',
        '.gcp', '.azure', '.docker',
        'Dockerfile', 'docker-compose.yml', 'docker-compose.yaml',
        'kubernetes', 'k8s', 'helm', 'terraform',
        '.terraform', 'terraform.tfstate', 'terraform.tfvars',
        'ansible', 'ansible.cfg', 'playbook.yml',
        
        # CI/CD
        '.github', '.github/workflows', '.gitlab-ci.yml',
        '.travis.yml', '.circleci', 'Jenkinsfile',
        'azure-pipelines.yml', 'bitbucket-pipelines.yml',
        
        # Misc sensitive
        'robots.txt', 'sitemap.xml', 'crossdomain.xml',
        '.well-known', '.well-known/security.txt',
        'security.txt', 'security', 'security/',
        'humans.txt', 'robots.txt',
        'cross-origin', 'cors', 'cors.php',
    ]
    
    # Common directory wordlist
    DIRECTORY_WORDLIST = [
        'admin', 'api', 'app', 'assets', 'backup', 'bin', 'cache',
        'cgi-bin', 'client', 'config', 'console', 'content', 'css',
        'data', 'db', 'demo', 'dev', 'dist', 'doc', 'docs', 'download',
        'downloads', 'error', 'etc', 'files', 'forum', 'ftp', 'home',
        'images', 'img', 'inc', 'include', 'includes', 'install', 'js',
        'lib', 'library', 'libs', 'logs', 'mail', 'media', 'member',
        'members', 'migrate', 'migrations', 'modules', 'new', 'old',
        'pages', 'photos', 'phpmyadmin', 'pics', 'plugins', 'private',
        'public', 'reports', 'resources', 'scripts', 'search', 'server',
        'services', 'sessions', 'share', 'shell', 'site', 'sites',
        'sql', 'src', 'ssh', 'static', 'stats', 'status', 'storage',
        'store', 'subdomains', 'support', 'system', 'temp', 'template',
        'templates', 'test', 'tests', 'tmp', 'tools', 'upload',
        'uploads', 'user', 'users', 'var', 'vendor', 'video', 'videos',
        'web', 'webmail', 'wiki', 'wp-content', 'wp-includes', 'xml',
    ]
    
    # Interesting status codes
    INTERESTING_STATUS_CODES = [200, 201, 202, 204, 301, 302, 303, 307, 308, 401, 403, 405, 500, 501, 502, 503]
    
    # Interesting content patterns
    INTERESTING_PATTERNS = [
        (r'password', 'Password field detected'),
        (r'api[_-]?key', 'API key reference'),
        (r'secret[_-]?key', 'Secret key reference'),
        (r'access[_-]?token', 'Access token reference'),
        (r'private[_-]?key', 'Private key reference'),
        (r'aws[_-]?access', 'AWS credentials reference'),
        (r'database', 'Database configuration'),
        (r'mysql[_-]?host', 'MySQL configuration'),
        (r'postgres[_-]?host', 'PostgreSQL configuration'),
        (r'mongodb[_-]?uri', 'MongoDB configuration'),
        (r'redis[_-]?host', 'Redis configuration'),
        (r'smtp[_-]?host', 'SMTP configuration'),
        (r'<form', 'Form detected'),
        (r'<input[^>]*type=["\']?password', 'Password input field'),
        (r'<input[^>]*type=["\']?file', 'File upload field'),
        (r'phpinfo\(\)', 'PHP info detected'),
        (r'eval\(', 'Eval function detected'),
        (r'shell_exec', 'Shell exec detected'),
        (r'system\(', 'System call detected'),
        (r'Debug.*mode', 'Debug mode detected'),
        (r'stack[_-]?trace', 'Stack trace detected'),
        (r'exception', 'Exception detected'),
        (r'error[_-]?log', 'Error log detected'),
    ]
    
    def __init__(
        self,
        timeout: int = 10,
        max_concurrent: int = 20,
        user_agent: str = None
    ):
        """
        Initialize directory fuzzer
        
        Args:
            timeout: Request timeout in seconds
            max_concurrent: Maximum concurrent requests
            user_agent: Custom user agent string
        """
        self.timeout = timeout
        self.max_concurrent = max_concurrent
        self.user_agent = user_agent or random.choice([
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ])
        self.session: Optional[aiohttp.ClientSession] = None
        self.semaphore: Optional[asyncio.Semaphore] = None
    
    async def init_session(self):
        """Initialize aiohttp session"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            connector = aiohttp.TCPConnector(ssl=False, limit=self.max_concurrent)
            headers = {
                'User-Agent': self.user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            }
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                headers=headers
            )
            self.semaphore = asyncio.Semaphore(self.max_concurrent)
    
    async def close_session(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def fuzz_path(self, base_url: str, path: str) -> Optional[FuzzResult]:
        """
        Fuzz a single path
        
        Args:
            base_url: Base URL
            path: Path to fuzz
        
        Returns:
            FuzzResult or None
        """
        async with self.semaphore:
            try:
                url = urljoin(base_url.rstrip('/') + '/', path.lstrip('/'))
                
                async with self.session.get(url, allow_redirects=False, ssl=False) as response:
                    status = response.status
                    content_length = int(response.headers.get('Content-Length', 0))
                    content_type = response.headers.get('Content-Type', '')
                    redirect = response.headers.get('Location', '')
                    
                    # Get content for analysis
                    content = ""
                    title = ""
                    
                    if status == 200 and 'text' in content_type:
                        try:
                            content = await response.text()
                            # Extract title
                            match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
                            if match:
                                title = match.group(1).strip()[:100]
                        except:
                            pass
                    
                    # Check if interesting
                    is_interesting, reason = self._check_interesting(
                        status, content_length, content_type, content, redirect
                    )
                    
                    return FuzzResult(
                        url=url,
                        path=path,
                        status_code=status,
                        content_length=content_length,
                        content_type=content_type.split(';')[0].strip(),
                        title=title,
                        redirect=redirect,
                        is_interesting=is_interesting,
                        reason=reason
                    )
            
            except asyncio.TimeoutError:
                logger.debug(f"Timeout fuzzing {path}")
            except Exception as e:
                logger.debug(f"Error fuzzing {path}: {e}")
        
        return None
    
    def _check_interesting(
        self,
        status: int,
        content_length: int,
        content_type: str,
        content: str,
        redirect: str
    ) -> Tuple[bool, str]:
        """
        Check if response is interesting
        
        Args:
            status: HTTP status code
            content_length: Response content length
            content_type: Content-Type header
            content: Response content
            redirect: Redirect location
        
        Returns:
            Tuple of (is_interesting, reason)
        """
        reasons = []
        
        # Check status code
        if status in [401, 403]:
            reasons.append(f"Protected resource ({status})")
        elif status in [500, 501, 502, 503]:
            reasons.append(f"Server error ({status})")
        elif status == 200:
            # Check content patterns
            for pattern, desc in self.INTERESTING_PATTERNS:
                if re.search(pattern, content, re.IGNORECASE):
                    reasons.append(desc)
        
        # Check for redirects to interesting places
        if redirect:
            if any(x in redirect.lower() for x in ['admin', 'login', 'auth', 'sso']):
                reasons.append(f"Redirects to: {redirect}")
        
        # Check content type
        if 'application/json' in content_type and status == 200:
            reasons.append("JSON endpoint")
        
        is_interesting = len(reasons) > 0
        reason = "; ".join(reasons) if reasons else ""
        
        return is_interesting, reason
    
    async def fuzz_sensitive_files(self, base_url: str) -> List[FuzzResult]:
        """
        Fuzz for sensitive files
        
        Args:
            base_url: Base URL to fuzz
        
        Returns:
            List of FuzzResult objects
        """
        await self.init_session()
        
        logger.info(f"[DirFuzzer] Scanning for sensitive files on {base_url}")
        
        tasks = [self.fuzz_path(base_url, path) for path in self.SENSITIVE_PATHS]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        found = []
        for result in results:
            if isinstance(result, FuzzResult):
                if result.status_code in self.INTERESTING_STATUS_CODES:
                    found.append(result)
                    if result.is_interesting:
                        logger.info(f"[DirFuzzer] Interesting: {result.path} ({result.status_code}) - {result.reason}")
        
        await self.close_session()
        
        logger.info(f"[DirFuzzer] Found {len(found)} paths")
        return found
    
    async def fuzz_directories(self, base_url: str, wordlist: List[str] = None) -> List[FuzzResult]:
        """
        Fuzz for directories
        
        Args:
            base_url: Base URL to fuzz
            wordlist: Custom wordlist (optional)
        
        Returns:
            List of FuzzResult objects
        """
        await self.init_session()
        
        words = wordlist or self.DIRECTORY_WORDLIST
        paths = [f"{w}/" for w in words]  # Add trailing slash for directories
        
        logger.info(f"[DirFuzzer] Scanning for directories on {base_url}")
        
        tasks = [self.fuzz_path(base_url, path) for path in paths]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        found = []
        for result in results:
            if isinstance(result, FuzzResult):
                if result.status_code in [200, 301, 302, 401, 403]:
                    found.append(result)
                    logger.info(f"[DirFuzzer] Directory: {result.path} ({result.status_code})")
        
        await self.close_session()
        
        logger.info(f"[DirFuzzer] Found {len(found)} directories")
        return found
    
    async def comprehensive_fuzz(self, base_url: str) -> Dict[str, List[Dict]]:
        """
        Run comprehensive fuzzing
        
        Args:
            base_url: Base URL to fuzz
        
        Returns:
            Dictionary with categorized results
        """
        logger.info(f"[DirFuzzer] Starting comprehensive fuzzing on {base_url}")
        
        # Run both scans
        sensitive_results = await self.fuzz_sensitive_files(base_url)
        directory_results = await self.fuzz_directories(base_url)
        
        # Categorize results
        results = {
            'sensitive_files': [r.to_dict() for r in sensitive_results if r.status_code == 200],
            'protected_paths': [r.to_dict() for r in sensitive_results if r.status_code in [401, 403]],
            'directories': [r.to_dict() for r in directory_results if r.status_code == 200],
            'redirects': [r.to_dict() for r in sensitive_results + directory_results if r.status_code in [301, 302, 307, 308]],
            'interesting': [r.to_dict() for r in sensitive_results + directory_results if r.is_interesting],
            'all_results': [r.to_dict() for r in sensitive_results + directory_results]
        }
        
        logger.info(f"[DirFuzzer] Comprehensive scan complete:")
        logger.info(f"  - Sensitive files: {len(results['sensitive_files'])}")
        logger.info(f"  - Protected paths: {len(results['protected_paths'])}")
        logger.info(f"  - Directories: {len(results['directories'])}")
        logger.info(f"  - Interesting findings: {len(results['interesting'])}")
        
        return results
    
    async def check_exposed_files(self, base_url: str) -> List[Dict]:
        """
        Check for commonly exposed sensitive files
        
        Args:
            base_url: Base URL to check
        
        Returns:
            List of exposed file information
        """
        exposed = []
        
        # High priority files to check
        high_priority = [
            '.env', '.git/config', '.svn/entries', '.htaccess',
            'wp-config.php', 'config.php', 'database.sql',
            'backup.zip', 'backup.sql', 'id_rsa',
            'credentials.json', 'secrets.yml', 'private.key',
            'phpinfo.php', 'info.php', 'server-status',
        ]
        
        await self.init_session()
        
        for path in high_priority:
            result = await self.fuzz_path(base_url, path)
            if result and result.status_code == 200:
                exposed.append({
                    'path': path,
                    'url': result.url,
                    'content_length': result.content_length,
                    'content_type': result.content_type,
                    'severity': 'high' if any(x in path for x in ['.env', 'config', 'secret', 'key', 'password', 'backup']) else 'medium'
                })
                logger.warning(f"[DirFuzzer] EXPOSED: {path} - {result.content_length} bytes")
        
        await self.close_session()
        
        return exposed


async def simple_directory_fuzz(
    url: str,
    wordlist: List[str] = None,
    timeout: int = 10
) -> List[Dict]:
    """
    Simple directory fuzzing function
    
    Args:
        url: URL to fuzz
        wordlist: Optional custom wordlist
        timeout: Request timeout
    
    Returns:
        List of found paths
    """
    fuzzer = DirectoryFuzzer(timeout=timeout)
    results = await fuzzer.fuzz_sensitive_files(url)
    return [r.to_dict() for r in results if r.status_code in [200, 301, 302, 401, 403]]